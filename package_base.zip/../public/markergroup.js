// Copyright (c) 2023, CISEI

// A class to handle groups of markers, specific to our application needs


class MarkerGroup {
    constructor(map, layerControl, group_color = ["rgba(255, 0, 255, 1.0)", "white"], layer_name = "UNDEFINED_LAYER_NAME", custom_icon_file = null) {
        this.map = map
        this.markers = [];

        this.cust_icon = null; // default
        if (custom_icon_file) {
            this.cust_icon = L.icon({
                iconUrl: custom_icon_file,
                iconSize: [38, 38],
                iconAnchor: [19, 19],
                popupAnchor: [0, -10]
            });
        }

        if (!layerControl) {
            throw new Error('Layer control is required.');
        }

        var cluster_custom_div_open = '<div style="background-color: ' + group_color[0] + '; display: flex; justify-content: center; align-items: center; height: 80%; width: 80%; font-weight: bold; color: ' + group_color[1] + ';">'

        let markers = L.markerClusterGroup(
            {
                spiderfyOnMaxZoom: true,
                showCoverageOnHover: false,
                zoomToBoundsOnClick: true,
                iconCreateFunction: function (cluster) {
                    return L.divIcon({
                        html: cluster_custom_div_open + cluster.getChildCount() + '</div>',
                        className: 'leaflet-marker-icon marker-cluster',
                        iconSize: L.point(40, 40)
                    });
                }
            });

        var polygon;
        // add event handlers
        markers.on('clustermouseover', function (a) {
            if (polygon) {
                map.removeLayer(polygon);
            }
            polygon = L.polygon(a.layer.getConvexHull());
            map.addLayer(polygon);
        });
        markers.on('clustermouseout', function (a) {
            if (polygon) {
                map.removeLayer(polygon);
                polygon = null;
            }
        });
        map.on('zoomend', function () {
            if (polygon) {
                map.removeLayer(polygon);
                polygon = null;
            }
        });
        this.group_markers = markers;

        // layer group and layer control
        const markerLayer = L.layerGroup([this.group_markers]);
        layerControl.addOverlay(this.group_markers, layer_name);
    }
    addMarker(lat, long, some_title = "Added via class", some_info = "A marker for clustering") {


        var mar = L.marker([parseFloat(lat), parseFloat(long)], this.cust_icon ? { icon: this.cust_icon } : null);
        mar.bindPopup('<h1>' + some_title + '</h1>' + some_info);
        this.markers.push(mar);
        this.group_markers.addLayer(mar);
    }

    addLayer() {
        this.map.addLayer(this.group_markers);
    }

    clear() {
        this.group_markers.clearLayers();
        this.markers = [];
    }
}