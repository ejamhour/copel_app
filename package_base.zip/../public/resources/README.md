# **cisei22comm**

P&D-02866-0478/2017 FERRAMENTA DE PLANEJAMENTO ÓTIMO DE COMUNICAÇÃO

## Development

```sudo apt install git python3-pip python3-tk```
```pip3 install utm pandas folium flask watchdog waitress geopy plyer```

## Wolfram Engine

Download Worlfram engine: https://www.wolfram.com/engine/
Create account there: https://account.wolfram.com/

