import sys
import os
sys.path.insert(0,'cisei_lib')
sys.path.insert(1,'cisei_lib/cli')
sys.path.insert(2,'cisei_lib/cli/planner')
sys.path.insert(3,'cisei_lib/gui')
sys.path.insert(4,'cisei_lib/gui/widgets')
sys.path.insert(5,'cisei_lib/gui/tools')
