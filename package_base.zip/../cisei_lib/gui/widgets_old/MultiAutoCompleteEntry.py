import tkinter as tk


class MultiAutoCompleteEntry(tk.Frame):
    def __init__(self, parent, tags, tags_vals, string_var=None, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)

        self.tags = tags
        self.tags_vals = tags_vals
        self.input_var = tk.StringVar()
        if string_var is not None:
            self.input_var = string_var
        self.input_field = tk.Entry(self, textvariable=self.input_var)
        self.input_field.pack()
        self.input_field.bind("<Down>", self.focus_next)

        self.suggestions_list = tk.Listbox(self, height=4)
        self.suggestions_list.bind("<Double-Button-1>", self.insert_suggestion)
        self.suggestions_list.bind("<Return>", self.insert_suggestion)
        self.suggestions_list.bind("<Up>", self.focus_prev)

        self.input_var.trace("w", self.suggest_completion)

    def get_string_var(self):
        return self.input_var

    def suggest_completion(self, *args):
        # QOL - check empty, disappear the box
        input_value = self.input_var.get()
        if not input_value:
            self.suggestions_list.pack_forget()
            return
        # QOL 2 - no match, return
        words = input_value.split()
        if len(words) <= 0:
            return

        last_word = input_value.split()[-1]
        suggestions = [word for word in self.tags if word.lower(
        ).startswith(last_word.lower())]
        self.suggestions_list.delete(0, tk.END)
        for word in suggestions:
            self.suggestions_list.insert(tk.END, word)
        if suggestions:
            self.suggestions_list.pack()
        else:
            self.suggestions_list.pack_forget()

    def insert_suggestion(self, event):
        self.input_field.icursor(tk.END)
        # Get the selected suggestion
        suggestion = self.suggestions_list.get(self.suggestions_list.curselection())
        input_value = self.input_var.get()
        # Check if the selected suggestion is in the main `tags` list
        if suggestion in self.tags:
            # Get the index of the selected tag in the main `tags` list
            selected_index = self.tags.index(suggestion)
            new_suggestions = self.tags_vals[selected_index]
            self.input_field.icursor(tk.END)
            last_word = input_value.split()[-1]
            # Append the new syntax after inserting the selected suggestion
            self.input_var.set(input_value.rstrip(last_word) +
                            "\"" + suggestion + "\":\"\"")
            self.suggestions_list.delete(0, tk.END)
            for word in new_suggestions:
                self.suggestions_list.insert(tk.END, word)
            self.suggestions_list.pack()
            last_quote_index = self.input_var.get().rfind("\"")
            self.input_field.icursor(last_quote_index)
        else:
            # If the selected suggestion is not in the main `tags` list, it must be in a sublist
            last_quote_index = input_value.rfind("\"")
            self.input_var.set(input_value[:last_quote_index] + suggestion + "\" ")
            self.suggestions_list.delete(0, tk.END)
            self.input_field.icursor(tk.END)
            self.suggestions_list.pack_forget()
        self.input_field.focus_set()


    def focus_next(self, event):
        self.suggestions_list.activate(0)
        self.suggestions_list.select_set(0)
        self.suggestions_list.focus_set()

    def focus_prev(self, event):
        self.input_field.focus_set()


if __name__ == "__main__":
    print("testing")
    root = tk.Tk()
    higher=["fruits", "car brands"]
    
    fruits = ["apple", "banana", "blue-berry",
                   "cherry", "date", "elderberry", "fig", "grape"]
    
    # the order will bind to the higher list, so it matters
    sub_lists=[fruits,["VW", "Lamborghini"]]
    
    auto_complete_entry = MultiAutoCompleteEntry(root, higher, sub_lists)
    auto_complete_entry.pack()
    root.mainloop()
