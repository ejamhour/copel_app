import tkinter as tk


class SuggestEntry(tk.Frame):
    def __init__(self, parent, valid_words, textvariable=None, use_quotes=False, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)

        self.use_quotes = use_quotes
        self.valid_words = valid_words
        self.input_var = tk.StringVar()
        if textvariable is not None:
            self.input_var = textvariable
        self.input_field = tk.Entry(self, textvariable=self.input_var)
        self.input_field.pack()
        self.input_field.bind("<Down>", self.focus_next)

        self.suggestions_list = tk.Listbox(self, height=4)
        self.suggestions_list.bind("<Double-Button-1>", self.insert_suggestion)
        self.suggestions_list.bind("<Return>", self.insert_suggestion)
        self.suggestions_list.bind("<Up>", self.focus_prev)

        self.input_var.trace("w", self.suggest_completion)

    def get(self):
        """Get the input value as string"""
        return self.input_var

    def suggest_completion(self, *args):
        # QOL - check empty, disappear the box
        input_value = self.input_var.get()
        if not input_value:
            self.suggestions_list.pack_forget()
            return
        # QOL 2 - no match, return
        words = input_value.split()
        if len(words) <= 0:
            return

        last_word = input_value.split()[-1]
        suggestions = [word for word in self.valid_words if word.lower(
        ).startswith(last_word.lower())]
        self.suggestions_list.delete(0, tk.END)
        for word in suggestions:
            self.suggestions_list.insert(tk.END, word)
        if suggestions:
            self.suggestions_list.pack()
        else:
            self.suggestions_list.pack_forget()

    def insert_suggestion(self, event):
        self.input_field.icursor(tk.END)
        suggestion = self.suggestions_list.get(
            self.suggestions_list.curselection())
        input_value = self.input_var.get()
        last_word = input_value.split()[-1]
        if self.use_quotes:
            self.input_var.set(input_value.rstrip(last_word) +
                            "\"" + suggestion + "\" ")  # NOTE: the space at the end
        else:
            self.input_var.set(input_value.rstrip(last_word) +
                            suggestion + " ")  # NOTE: the space at the end

        self.suggestions_list.pack_forget()  # remove the list
        self.input_field.focus_set()
        self.input_field.icursor(tk.END)

    def focus_next(self, event):
        self.suggestions_list.activate(0)
        self.suggestions_list.select_set(0)
        self.suggestions_list.focus_set()

    def focus_prev(self, event):
        self.input_field.focus_set()


if __name__ == "__main__":
    print("testing")
    root = tk.Tk()
    valid_words = ["apple", "banana", "blue-berry",
                   "cherry", "date", "elderberry", "fig", "grape"]
    auto_complete_entry = SuggestEntry(root, valid_words)
    auto_complete_entry.pack()
    root.mainloop()
