import os
import http.server
import socketserver
from tkinter import messagebox

class StaticServer:
    def __init__(self, asset_folder="public", port=8037):
        self.port = port
        self.folder = asset_folder

    def start(self):
        # web_dir = os.path.join(os.path.dirname(__file__), self.folder)
        # os.chdir(web_dir)
        try:
            Handler = http.server.SimpleHTTPRequestHandler

            httpd = socketserver.TCPServer(("", self.port), Handler)

            print(f"Serving at http://localhost:{self.port}")
            httpd.serve_forever()
        except Exception as ee:
            messagebox.showinfo(f"Livemap Problem", "Failed to start static file server, you will be unable to work with regions.\n\nThis might happen because you left the live map open in a browser. Try closing all browser's livemap tabs, an re-run this program.\n\n{ee}")
            print("Failed to start livemap")