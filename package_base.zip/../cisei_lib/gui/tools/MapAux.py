from folium.plugins import FastMarkerCluster
import folium
from PIL import Image
import os
import cisei_lib.globals as g

# Styling and templates that Map.py uses

def get_icon(name, ext=True):
    if ext:
        return os.path.join(g.g_mapres, name + '.png')
    else:
        return os.path.join(g.g_mapres, name )


# Define the styles for the label floating over the marker icon
def label_styles(iconsize, r=255, g=255, b=0):
    return f"""
        position: absolute;
        top: 0;
        left: -50%;
        transform: translate(0%, -100%);
        margin-left: {iconsize}px;
        font-size: 16px;
        color: rgb({r},{g},{b});
        font-weight: bold;
        white-space:nowrap;
        text-shadow: -1px -1px 0 #000,
        1px -1px 0 #000,
        -1px 1px 0 #000,img
        1px 1px 0 #000;
    """


def node_html_icon(icon_size, icon_path, top_text, lower_text, rgb_top=(255, 255, 0)):
    # Combine the strings to create the label/icon
    return f"""
        <div style='position: relative;'>
            <img src='{icon_path}' style='width:{icon_size}px; height:{icon_size}px;' />
            <div style='{label_styles(icon_size/4, r=rgb_top[0], g=rgb_top[1], b=rgb_top[2])}'>
                {top_text}
            </div>
            <p style='font-size: 12px;color: #00FFFF; white-space:nowrap;text-shadow: -1px -1px 0 #000;'>{lower_text}</p>
        </div>
    """


def gen_marker_cluster(data, top_text, bottom_text, cluster_color=(255,0,255), iconsize=27, iconpath=get_icon('marker'), popup_html=None, general_variables=None, cluster_text_color=(255,255,255)):
    """A very abstract function to create markers that can form clusters, and also have labels"""
    # this defines the representation when clustered
    icon_clust_looks = '''
        function(cluster) {
            return L.divIcon({
                html: '<div style="background-color: CLUSTER_COL; color: CLUSTER_TEXT_COL; display: flex; justify-content: center; align-items: center; height: 80%; width: 80%; font-weight: bold;"><b>' + cluster.getChildCount() + '</b></div>',
                className:'leaflet-marker-icon marker-cluster leaflet-zoom-animated leaflet-interactive',
                iconSize: new L.Point(40,40)
            });
        }'''
    ccol = cluster_color
    icon_clust_looks = icon_clust_looks.replace(
        "CLUSTER_COL", f"rgba({ccol[0]}, {ccol[1]}, {ccol[2]}, 0.75)")
    ctcol = cluster_text_color
    icon_clust_looks = icon_clust_looks.replace(
        "CLUSTER_TEXT_COL", f"rgba({ctcol[0]}, {ctcol[1]}, {ctcol[2]}, 1.0)")


    # this defines representation of individual markers
    if general_variables is None:
        general_variables = """
        var variable = "UNDEFINED TODO:";
        var var2 = row[1]
        """
    if popup_html is None:
        popup_html = """
        <h3>MISSING - ${variable} ${row[0]} - ${var2}</h3>
        <div>
            <p>MISSING_TODO</p>
        </div>
        """
    marker_cb = """
        function (row) {
            var marker = L.marker(new L.LatLng(row[0], row[1]));
            __GENERAL_VARIABLES__
            var icon = L.divIcon({
                html: `CUSTOM_DIV_ICON`,
                className:'leaflet-marker-icon marker-cluster leaflet-zoom-animated leaflet-interactive',
                iconSize: new L.Point(40,40)
            });
            marker.setIcon(icon);
            var metername = "Meternamehere TODO:";
            var popup = L.popup({maxWidth: '300'});


            var mytext = `__POPUP_HTML__`;
            popup.setContent(mytext);
            marker.bindPopup(popup);
            return marker
        }
    """
    marker_cb = marker_cb.replace("__GENERAL_VARIABLES__", general_variables)
    marker_cb = marker_cb.replace("__POPUP_HTML__", popup_html)
    divicon = node_html_icon(iconsize, iconpath,
                             top_text, bottom_text, cluster_color)
    divicon = divicon.replace('\n', ' ')
    divicon = divicon.replace('\'', '"')
    marker_cb = marker_cb.replace("CUSTOM_DIV_ICON", divicon)

    marker_cluster = FastMarkerCluster(
        data, icon_create_function=icon_clust_looks, callback=marker_cb)

    return marker_cluster

# ==========================================================================================
# Specific to planned AMI generation


def htmltable(data):
    html = "<table style='border: 1px solid black; background-color: lightgray;'>\n"
    for item in data:
        html += "  <tr>\n"
        html += f"    <td>{item}</td>\n"
        html += "  </tr>\n"
    html += "</table>"
    return html


def gen_meters_markers(meters, clustercolor, custom_icon=get_icon('marker')):
    """ Add the FastMarkerCluster representing the ami nodes"""

    met_popupval = """
        var label = row[2];
        var meters = row[3];
        var radio = row[4];
        """
    met_popuphtml = """
        <h3><b>${label}</b></h3>
        <div>
            <table>
                <tr>
                    <th><b>meters: </b></th>
                    <td>${meters}</td>
                </tr>
                <tr>
                    <th><b>radio: </b></th>
                    <td>${radio}</td>
                </tr>
            </table>
        </div>
        """
    mark_clus_meters = gen_marker_cluster(
        meters, "${label}", "", clustercolor, general_variables=met_popupval, popup_html=met_popuphtml, iconpath=custom_icon, cluster_text_color=(0,0,0))
    return mark_clus_meters


def gen_extensors_or_gw_markers(extensors, clustercolor, custom_icon=get_icon('marker')):
    vals = """
        var label = row[2];
        var pole_uid = row[3];
        var radio = row[4];
        """
    html = """
        <h3><b>${label}</b></h3>
        <div>
            <table>
                <tr>
                    <th><b>pole_uid: </b></th>
                    <td>${pole_uid}</td>
                </tr>
                <tr>
                    <th><b>radio: </b></th>
                    <td>${radio}</td>
                </tr>
            </table>
        </div>
        """
    cluster = gen_marker_cluster(
        extensors, "${label}", "", clustercolor, general_variables=vals, popup_html=html, iconpath=custom_icon, cluster_text_color=(0,0,0))
    return cluster


def gen_gateway_featuregroup(gateway, ami, color, map=None, custom_icon=get_icon('marker'), feature_group=None, granular_grouping=False):
    """Granular grouping regards on making a layer for extensors and another for meters, per gateway"""

    # build ami data array, and generate the leaflet marker cluster elements
    meters = []
    extensors = []
    gws = []
    for i, node in enumerate(ami):
        if node['type'] == 'ami_me':
            meters.append([node['lat'], node['lon'],
                           node['label'], htmltable(node['meters']), node['radio']])
        elif node['type'] == 'ami_ex':
            extensors.append([node['lat'], node['lon'],
                              node['label'], node['pole_uid'], node['radio']])
        elif node['type'] == 'ami_gw':
            # uses same function as extensor, because same params
            gws.append([node['lat'], node['lon'],
                              node['label'], node['pole_uid'], node['radio']])


    meter_markers = gen_meters_markers(meters, color, custom_icon=custom_icon)
    extensor_markers = gen_extensors_or_gw_markers(
        extensors, color, custom_icon=custom_icon)
    gw_markers = gen_extensors_or_gw_markers(
        gws, color, custom_icon=custom_icon)
    
    if map is None and feature_group is None:
        print("either give a map or a feature group to add the elements")
        return
    
    if feature_group is None:
        m_group = folium.FeatureGroup(name=f'{gateway} Meters')
        e_group = folium.FeatureGroup(name=f'{gateway} Gateway & Extensors')
        m_group.add_child(meter_markers)
        e_group.add_child(extensor_markers)
        e_group.add_child(gw_markers)
        m_group.add_to(map)
        e_group.add_to(map)
    else:
        if isinstance(feature_group, list):
            if len(feature_group) < 3:
                raise Exception("Expected an array of 3 feature group (fg's), [fg Gateways, fg Extensors, fg Meters]")
            # notice the order, this effectivelly dictates what is
            # expected in the list, when programmer passes as list
            feature_group[0].add_child(gw_markers)
            feature_group[1].add_child(extensor_markers)
            feature_group[2].add_child(meter_markers)
        else:
            feature_group.add_child(meter_markers)
            feature_group.add_child(extensor_markers)
            feature_group.add_child(gw_markers)


def _gen_colored_marker(input_marker_filepath, color, output_path):
    original_image = Image.open(input_marker_filepath)

    colorized_image = Image.new("RGBA", original_image.size, (0, 0, 0, 0))
    for x in range(original_image.width):
        for y in range(original_image.height):
            pixel = original_image.getpixel((x, y))
            if pixel[:3] == (255, 255, 255):
                colorized_image.putpixel((x, y), color + (pixel[3],))
            else:
                colorized_image.putpixel((x, y), pixel)
    colorized_image.save(output_path)


def gen_colored_markers(orig_marker_filepath, hex_color_list, out_folder= get_icon('amicolor', ext=False), force_gen=False):
    colored_ami_markers = []
    if not os.path.exists(out_folder):
        os.makedirs(out_folder)
    total = len(hex_color_list)
    for i, c in enumerate(hex_color_list):
        colored_ami_markers.append(f"{out_folder}/ami_{i}.png")

        # if icon exists, ignore, but if use force to generate regardless
        if os.path.isfile(colored_ami_markers[i]) is False or force_gen is True:
            print(f"generating colored icons, standby ({i+1}/{total})")
            _gen_colored_marker(orig_marker_filepath,
                                c, f"{colored_ami_markers[i]}")

    return colored_ami_markers



# ==========================================================================================
# Specific to pre-plan map