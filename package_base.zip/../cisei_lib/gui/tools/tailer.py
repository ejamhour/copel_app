import os
import sys
import threading
import queue
import time
from pathlib import Path

# sometimes a file is deleted, right after we check if exists.
# then, midway, we attempt open it, a an error occurs
g_delay_until_attempt_open = 1.5

if sys.platform == 'win32':
    import win32file
    import win32con
    import win32api

import subprocess

class LogFileTailer(threading.Thread):
    def __init__(self, file_path):
        threading.Thread.__init__(self)
        self.file_path = file_path
        self.log_queue = queue.Queue(maxsize=100)
        self.is_running = True

    def run(self):
        def safe_line_size(line):
            if len(line) > 4000: # 4KB size max 
                linesizemb = f"{(len(line)/(1024 * 1024)):.2f} MB"
                print(f"Skipping line exceeding maximum size: {linesizemb} ({len(line)} bytes)")
                return False
            return True

        self.wait_for_file()
        if sys.platform == 'win32':
            cat_command = ['powershell', '-Command', 'Get-Content', self.file_path]
            cat_process = subprocess.Popen(cat_command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            existing_lines = cat_process.stdout.read().decode().splitlines()
            for line in existing_lines:
                self.log_queue.put(line)

            tail_command = ['powershell', '-Command', 'Get-Content', self.file_path, '-Wait']
            tail_process = subprocess.Popen(tail_command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            try:
                for line in tail_process.stdout:
                    if not safe_line_size(line):
                        continue
                    if not self.is_running:
                        break
                    self.log_queue.put(line.decode().rstrip())
            except KeyboardInterrupt:
                tail_process.terminate()
        else:
            tail_command = ['tail', '-f', self.file_path]
            process = subprocess.Popen(tail_command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            for line in process.stdout:
                if not safe_line_size(line):
                    continue
                if not self.is_running:
                    break
                entry = line.decode().rstrip()
                # print(entry)
                self.log_queue.put(entry)
        print("Tail proc exit")

    def stop(self):
        self.is_running = False

    def wait_for_file(self, timeout=60):
        try:
            start_time = time.time()
            file_path = Path(self.file_path)
            time.sleep(g_delay_until_attempt_open)
            while not file_path.exists():
                if time.time() - start_time > timeout:
                    raise TimeoutError(f"Timed out waiting for file: {file_path}")

                time.sleep(1)  # Adjust the sleep interval as needed
            print("Found file to tail")
        except Exception as ex:
                print(f"FAILED TO READ FILE< MAYBE RACE-CONDITION AND DELETED AS ATTEMPT READING!\nMore info: {ex}")
    # def __call__(self):
    #     pass
        # self.stop()



if __name__ == '__main__':
    # Example usage
    log_file_path = './somefiletailtest.txt'
    tailer = LogFileTailer(log_file_path)
    tailer.start()

    # Stop the tailer by calling the object
    # tailer()
    while True: 
        v = tailer.log_queue.get()
        print(v)
        if v == 'stop':
            print("Bye!")
            tailer.stop()
            break
    print("tailer stopped successfully!")

    tailer.join()