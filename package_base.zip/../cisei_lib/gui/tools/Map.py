# Copyright (c) 2021-2023, COPEL DIS.
#  Feb 2023

import pandas as pd
import folium
import os
import json
# for prototypes in-file
import tkinter as tk
from tkinter import ttk
import webbrowser
from tkinter import messagebox
import shutil
import MapAux as maux
import cisei_lib.globals as g


# this is the prefix used to identify dynamic link quality aprameters
g_dynamic_pa_prefix = "lq_"

""" Possible colors for FA markers """
""" {'beige', 'black', 'blue', 'cadetblue', 'darkblue', 'darkgreen',
       'darkpurple', 'darkred', 'gray', 'green', 'lightblue', 'lightgray',
       'lightgreen', 'lightred', 'orange', 'pink', 'purple', 'red', 'white'} """


class Map(object):
    def __init__(self):
        # Receives the nodes element from PlanLib.py
        data = None  # stub

    def get_icon(self, name, ext=True):
        if ext:
            return os.path.join(g.g_mapres, name + '.png')
        else:
            return os.path.join(g.g_mapres, name )

    def split_coords(self, df, xcol, ycol, extra_cols=None, *vars):
        """ Split df into 2 lists of coords, which are somethimes used
        for the leaflet plugin. Also allows user to add extrac params
        to extract
        the cols is now fetched by name, rather than index. makes easier to locate and harder to fail"""

        if extra_cols is None:  # allow for no extra cols cases
            extra_cols = []
        else:  # check if the desired extra col is on df
            for ci, col in enumerate(extra_cols):
                if col not in df.columns:
                    raise ValueError(
                        f"Column {col} not in the dataframe, failed to split")

        # extract coordinates
        xs = df[xcol].values
        ys = df[ycol].values
        for i, column in enumerate(extra_cols):
            extracted_values = df[column].values
            vars[i][:] = extracted_values
        return xs, ys

    def add_nodes_style1(self, dict, map, cols=[],  dicon ='', color=(255, 0, 255), header="", layer_name=""):
        """
        Multi purpose function to add clusters of nodes
        First two entries on cols must be the coords e.g. ['lat', 'long', 'uid', 'type']
        """

        icon = self.get_icon('marker') if dicon == '' else dicon

        
        if cols == [] or len(cols) < 2:
            raise Exception("preplan_add_nodes> Invalid column data")

        rows = []
        for row in dict:  # build array with selected dict's cols
            tempr = []
            for c in cols:
                tempr.append(row[c])
            rows.append(tempr)

        vals = ""  # build javascript vars
        for i, c in enumerate(cols):
            vals = f"{vals}var {c} = row[{i}];\n"

        popuphtml = ""
        for i, c in enumerate(cols):
            if i < 2:
                continue # ignore the lat long
            popuphtml = f"""{popuphtml}
            <tr>
                <th><b>{c}: </b></th>
                <td>${{{c}}}</td>
            </tr>"""

        html = f"""
            <h3><b>{header}</b></h3>
            <div>
                <table>
                    @@@TABLE_DATA@@@
                    <tr>
                        <td>Google Maps:</td>
                        <td><a href='https://www.google.com/maps/search/?api=1&query=${{lat}},${{long}}'>Open maps</a></td>
                    </tr>
                </table>
            </div>
            """
        html = html.replace("@@@TABLE_DATA@@@", popuphtml)

        cluster = maux.gen_marker_cluster(
            rows, "", "", color, general_variables=vals, popup_html=html, iconpath=icon)
        m_group = folium.FeatureGroup(name=f'{layer_name}')
        m_group.add_child(cluster)
        m_group.add_to(map)


    def plot_preplan(self, nodes, pid, db_conn):

        project_df = pd.DataFrame(pd.read_sql(
            f"select * from projects where id = {pid}", db_conn))
        print(project_df)

        if len(project_df) == 0:
            print(f"No porject found for ID {pid}")
            return
        proj = project_df.iloc[0]  # shorten it

        poles_df = nodes['poles']
        # print(f"poles {poles_df.columns}")
        meters_df = nodes['meters']
        # print(f"meters {meters_df.columns}")
        dads_df = nodes['dads']
        # print(f"dads {dads_df.columns}")
        pops_df = nodes['pops']
        # print(f"pops {pops_df.columns}")

        towers_df = nodes['towers']

        poles_coordxs, poles_coordys = self.split_coords(
            poles_df, "lat", "long")

        google_default = "http://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}"
        google_topography = "http://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}"
        opentoposrc = "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
        tiless = 'http://tile.stamen.com/toner/{z}/{x}/{y}.png '
        tile_layer = folium.TileLayer(
            tiles=google_topography,
            attr='&copy; <a href="https://www.google.org/">Google</a> contributors &copy; <a href="#">Corporate copyright</a>',
            max_zoom=19,
            name='Topografia Google',
            control=True,
            opacity=0.7
        )
        osm_layer = folium.TileLayer(
            tiles="OpenStreetMap",
            attr='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
            max_zoom=19,
            name='OpenStreetMap',
            control=True,
            opacity=0.9,
            overlay=True
        )
        otm_layer = folium.TileLayer(
            tiles=opentoposrc,
            attr='&copy; <a href="https://www.opentopomap.org/">OpenTopoMap</a>',
            max_zoom=19,
            name='OpenTopoMap',
            control=True,
            opacity=0.9,
            overlay=True
        )

        m = folium.Map(tiles=google_default,
                       name='Google Maps',
                       attr='Google Maps',
                       location=[poles_coordxs[0],
                                 poles_coordys[0]], zoom_start=13
                       )
        tile_layer.add_to(m)
        osm_layer.add_to(m)
        otm_layer.add_to(m)
        # -------------------------------------------------------------


        # POLES
        poles_dict = poles_df.to_dict(orient='records')
        self.add_nodes_style1(
            poles_dict, m, ["lat", "long", "uid", "pole_uid", "height", "pop", "city_name", "tags"],
            self.get_icon('pole-marker'), (0, 63, 226), "Pole (${uid})", "Poles")

        # METERS
        if meters_df is not None:
            meters_dict = meters_df.to_dict(orient='records')
            self.add_nodes_style1(
                meters_dict, m, ["lat", "long", "uid", "type", "pop", "city_name", "tags"],
                self.get_icon('meter-marker'), (0, 164, 114), "Meter (${uid})", "Meters")
        else:
            print(f"NO METERS FOR project {proj.id} !")
        
        # DADS
        if dads_df is not None:
            dads_dict = dads_df.to_dict(orient='records')
            self.add_nodes_style1(
                dads_dict, m, ["lat", "long", "uid", "type", "pop", "city_name", "pole_uid", "tags"],
                self.get_icon('automation-marker'), (200, 0, 0), "DAD (${uid})", "DADs")
        else:
            print(f"NO DADs FOR project {proj.id} !")

        # TOWERS
        if towers_df is not None:
            towers_dict = towers_df.to_dict(orient='records')
            self.add_nodes_style1(
                towers_dict, m, ["lat", "long", "uid", "height", "pop", "city_name", "fiber", "tags"],
                self.get_icon('tower-marker'), (135, 138, 0), "TOWER (${uid})", "TOWERS")
        else:
            print(f"NO TOWERS FOR project {proj.id} !")
        
        # POPS
        pops_dict = pops_df.to_dict(orient='records')
        self.add_nodes_style1(
            pops_dict, m, ["lat", "long", "uid", "pop_name", "type", "city_name", "has_tower", "tags"],
            self.get_icon('fiber-marker'), (236, 60, 144), "POP (${uid})", "POPs")

        # Finish -----------------------------
        folium.LayerControl().add_to(m)

        # Save output file -------------------------------

        out_file_name = f"PREPLAN_MAP_PROJ_{proj.id}.html"
        out_folder = g.g_abs_path_maps
        out_file_name = os.path.join(out_folder, out_file_name)

        # Create the directory if it doesn't exist
        if not os.path.exists(out_folder):
            os.makedirs(out_folder)

        m.save(out_file_name)
        abs_path_name = os.path.normpath(out_file_name)
        print(f"HTML saved to ... '{abs_path_name}'")

        final_file_path = self.copy_to_proj_folder(abs_path_name, proj.id, "PREPLAN_MAP_PROJECT_")

        return final_file_path

    # ================================== for json plot ==================================

    def add_planned_bh_element_from_json(self, nodes, links, coords, map):
        dynampars = get_dynamic_params(links, g_dynamic_pa_prefix)

        marker_group = folium.FeatureGroup(name='BH Nodes')
        # FIXME: make propper color for MI (ami gateway)
        lbl2marker = {
            "AM": "gateway-marker.png",
            "RE": "repeater-marker.png",
            "TO": "tower-marker.png",
            "SU": "fiber-marker.png",
            "AU": "automation-marker.png",
            "MI": "gateway-marker.png",
            "?": "marker.png"
        }
        lbl2name = {
            "AM": "Gateway",
            "RE": "Repeater",
            "TO": "Tower",
            "SU": "Point Of Presence (POP)",  # Substation/POP/Fiber
            "AU": "Automation device",
            "MI": "Mixed (Multiple equipaments)",  # TODO_NEW_FEATURE - AMI gateways
            "?": "Unknown"
        }
        antenna2name = {
            "o": "Omni (both)",
            "d": "Directional (parent), Omni (child)",
            "dd": "Directional (both)"
        }

        feature_groups = {}
        fg_elm_counts = {} # side counting, so we dont rely too much on external libs
        for k, v in lbl2name.items():
            fg_elm_counts[k] = 0 # initially empty
            feature_groups[k] = folium.FeatureGroup(name=f"BHN {v}")
        
        for i, node in enumerate(nodes):
            ktype_2c = node['type'][0:2]

            first_lan_device = '' if ('uid' not in node or len(
                node['uid']) == 0) else node['uid'][0]
            poleuid = node['pole_uid']
            lat = coords[poleuid][0]
            long = coords[poleuid][1]
            icon_path = './mapres/' # HTML PATH
            lbl = node['label']
            lbl_first_ltr = node['type'][0:2]
            mkr_img = lbl2marker[lbl_first_ltr]
            icon_path += mkr_img
            icon_size = 27

            print(f"Label: {lbl}")

            # info of connection from parent to child
            children_link = [
                child_link for child_link in links if child_link['snode'] == node['label']]

            iconhtml = maux.node_html_icon(
                icon_size, icon_path, lbl, first_lan_device)
            icon = folium.features.DivIcon(
                html=iconhtml,
                icon_anchor=(icon_size/2, icon_size)
            )
            popup_min_wid = "300px"
            popup_html = f"<h4><b>{lbl2name[lbl_first_ltr]}</b> ({lbl})</h4>"
            latlongconcat = f"lat: {lat} / long: {long}"

            popup_html += f"""
                <div style="max-height: 450px;">
                    <table style="background-color: #e9ccff;
                                min-width: {popup_min_wid};
                                border: 1px solid black;
                                font-size: 1.2em;">
                        <tr>
                            <td>UID (pole_uid):</td>
                            <td title='click to copy: {latlongconcat}'>
                                <a href="#" onclick="navigator.clipboard.writeText('{latlongconcat}'); return false;">{poleuid}</a>
                            </td>
                        </tr>
                        <tr>
                            <td>path:</td>
                            <td>{node['path']}</td>
                        </tr>
                        <tr>
                            <td>DEVICES:</td>
                            <td>{'' if first_lan_device == '' else node['uid']}</td>
                        </tr>
                        <tr>
                            <td>Google Maps:</td>
                            <td><a href='https://www.google.com/maps/search/?api=1&query={lat},{long}'>Open maps</a></td>
                        </tr>
                    </table>
                </div>
                """

            if len(children_link):
                popup_html += f"""
                <div style="max-height: 450px; overflow-y: scroll;">
                    <table style="background-color: #ffffcc;
                                min-width: {popup_min_wid};
                                border: 1px solid black;
                                font-size: 1.2em;">
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>Child node</td>
                            <td>Metrics</td>
                        </tr>
                        @@@
                    </table>
                </div>
                """
                # compose html of elements connected to this parent
                additional_html = ""
                for eindx, child in enumerate(children_link):
                    # print("stub")
                    uid_child_noext = child['dnode']
                    additional_html += f"""
                    <tr>
                        <td><b>{uid_child_noext}</b></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td style="text-align: right;"><b>Distance=</b></td>
                        <td style="text-align: left;">{round(child['distance'],2)} m</td>
                    </tr>
                    <tr>
                        <td style="text-align: right;"><b>rssi=</b></td>
                        <td style="text-align: left;">{child['rssi']} dBm</td>
                    </tr>
                    <tr>
                        <td style="text-align: right;"><b>Clearance=</b></td>
                        <td style="text-align: left;">{round(child['los'],2)} m</td>
                    </tr>
                    <tr>
                        <td style="text-align: right;"><b>Antenna=</b></td>
                        <td style="text-align: left;">{antenna2name[child['ant']]}</td>
                    </tr>
                    """
                    if "zabbix" in child:
                        additional_html += f"""
                            <tr>
                            <td style="text-align: right;"><b>Zabbix=</b></td>
                            <td style="text-align: left;">{child['zabbix']}</td>
                            </tr>
                        """
                    for dypa in dynampars:  # extra dynamic params
                        if dypa in child:
                            additional_html += f"""
                            <tr>
                            <td style="text-align: right;"><b>{dypa}=</b></td>
                            <td style="text-align: left;">{child[dypa]}</td>
                            </tr>
                        """

                popup_html = popup_html.replace('@@@', additional_html)

            else:
                popup_html += "<p style='color: red;'><b>Leaf node. No child connected.</b></p>"

            folium.Marker(
                location=[lat, long],
                popup=popup_html,
                icon=icon
            ).add_to(feature_groups[ktype_2c])
            fg_elm_counts[ktype_2c] += 1


        for k, v in fg_elm_counts.items():
            if v > 0:
                feature_groups[k].layer_name += f" ({v})" # add num of elements
                feature_groups[k].add_to(map)
        # add the feature group to the map
        # marker_group.add_to(map)

    def add_dynamic_param_links(self, nodes, links, coords, param_name, layer_alias, map):
        """ user speicifies dynamic params in the bhlinks 
        these can be used to generate new layers
        specify the param name fully, with its prefi
        this code is duplicated from old one that plots links TODO: review"""

        line_group = folium.FeatureGroup(name=layer_alias, show=True)
        map.add_child(line_group)

        for index, node in enumerate(nodes):
            if node['label'] != None:
                if node['next_hop'] == 'none':
                    print(f"{node['label']} is root element")
                    continue

                elem_connected_to = {}
                try:
                    elem_connected_to = [
                        ec for ec in nodes if ec['label'] == node['next_hop']][0]
                except Exception as e:
                    print(f"[ISSUE] {node['next_hop']} not fould! {e}")
                    return

                # get the current link information
                link_info = {}
                try:
                    link_info = [linfo for linfo in links if linfo['dnode'] ==
                                 node['label'] and linfo['snode'] == elem_connected_to['label']][0]
                except Exception as e:
                    print(
                        f"NO LINK INFO, CANT COLOR LINK!!!\nException thown too, furtehr info:{e}")

                link_color = ""
                try:
                    has_param = link_info[param_name]
                except Exception as e:
                    print(
                        f"element {node['label']} has no dynamic param {param_name}")
                    continue
                try:
                    link_color = get_link_quality_color(
                        float(has_param), 0.0, 1.0)
                except Exception as e:
                    print(f"Parameter color claulation faul. Dtails: {e}")
                    continue

                # note 0, 2 means first row, <colums>
                elem2 = elem_connected_to
                latlon_a, latlon_b = coords[node['pole_uid']
                                            ], coords[elem2['pole_uid']]
                line = [(latlon_a[0], latlon_a[1]),
                        (latlon_b[0], latlon_b[1])]
                # print(line)
                # get color for line
                root_label = node['path'][0]
                line_color = link_color
                folium.PolyLine(line, color=line_color).add_to(line_group)

            else:
                print(f"[ISSUE]: element {index} of has no label.")
        print("[OK] - Added Planned links")

    def add_planned_bh_links_from_json(self, nodes, links, coords, map):

        line_group = folium.FeatureGroup(name='Links', show=True)
        map.add_child(line_group)

        # line color by root node ===================
        # build a dictionary, that has a color for each root label
        colors = ['#9b59b6', '#3498db',
                  '#95a5a6', '#e74c3c',
                  '#34495e', '#2ecc71',
                  '#f1c40f', '#1abc9c']
        root_nodes = [node for node in nodes if node['path']
                      == []]  # get roots
        color_root = {}
        for index, row in enumerate(root_nodes):
            color_root[row['label']] = colors[index % len(colors)]
        # =================== ===================

        for index, node in enumerate(nodes):
            if node['label'] != None:
                if node['next_hop'] == 'none':
                    print(f"{node['label']} is root element")
                    continue
                else:
                    print(f"{node['label']}---conected--->{node['next_hop']}")
                elem_connected_to = [
                    ec for ec in nodes if ec['label'] == node['next_hop']]
                if len(elem_connected_to) > 0:
                    # note 0, 2 means first row, <colums>
                    elem2 = elem_connected_to[0]
                    latlon_a, latlon_b = coords[node['pole_uid']
                                                ], coords[elem2['pole_uid']]
                    line = [(latlon_a[0], latlon_a[1]),
                            (latlon_b[0], latlon_b[1])]
                    # print(line)
                    # get color for line
                    root_label = node['path'][0]
                    line_color = color_root[root_label]
                    folium.PolyLine(line, color=line_color).add_to(line_group)
                    print('stub bhlink')
                else:
                    print(f"[ISSUE] {node['next_hop']} not fould!")

            else:
                print(f"[ISSUE]: element {index} of df has no label.")
        print("[OK] - Added Planned links")

    def add_planned_ami_from_json(self, amis, map, evident_group=[]):
        """evident group refers to adding AMI gateways separately on the layer selection control"""
        # could be added on a config file TODO:
        colors = ['#ff75b3', '#ffb575',
                  '#e1ff75', '#75ff85',
                  '#75ffe8', '#75bcff',
                  '#9175ff', '#d375ff']

        color_list_tuple = [self.hex_to_rgb(col) for col in colors]
        colored_ami_markers = maux.gen_colored_markers(
            self.get_icon('marker'), color_list_tuple, self.get_icon('amicolor', ext=False), force_gen=False) #HERE

        def get_ami_gateways(amis):
            ret = {}
            i = 0
            if amis is not None and len(amis) > 0:
                for entry in amis:
                    if entry['type'] == 'ami_gw':
                        ret[entry['label']] = i
                        i += 1
            return ret

        def amis_gateway_dict(amis, gws):
            amisorted = {}  # sort elements by gateway
            for gk, gv in gws.items():
                amisorted[gk] = []
            for i, node in enumerate(amis):
                gw = node['gateway']
                if gw == "":
                    gw = node['label']  # its gateway itself
                amisorted[gw].append(node)
            return amisorted

        gws = get_ami_gateways(amis)
        num_gws = len(gws)
        amisorted = amis_gateway_dict(amis, gws)

        # allami = folium.FeatureGroup(name=f'AMI planning')
        gateways = folium.FeatureGroup(name=f'AMI Gateways')
        extensors = folium.FeatureGroup(name=f'AMI Extensors')
        meters = folium.FeatureGroup(name=f'AMI Meters')
        allami = [gateways, extensors, meters]

        evident_featgroup = {}
        for e in evident_group:
            evident_featgroup[e] = folium.FeatureGroup(name=f'{e}')

        ami_gateway_colors_len = len(colors)
        for gw_label, gw_elements in amisorted.items():
            dest_featgroup = allami
            if gw_label in evident_group:
                dest_featgroup = evident_featgroup[gw_label]

            gwindex = gws[gw_label]
            gw_color = self.hex_to_rgb(colors[gwindex % (ami_gateway_colors_len)])
            c_icon = colored_ami_markers[gwindex % (ami_gateway_colors_len)]
            maux.gen_gateway_featuregroup(
                gw_label, gw_elements, gw_color, map, custom_icon=c_icon, feature_group=dest_featgroup)
            
        if isinstance(allami, list):
            for fg in allami:
                fg.add_to(map)
        else:
            allami.add_to(map)

        if len(evident_featgroup) > 0:  # add separated fgs
            for _, v in evident_featgroup.items():
                v.add_to(map)

    # NOTE: Need refactoring, make better constructs to generatlize this entire class

    def copy_to_proj_folder(self, orig_filepath, proj_num, text="MAP_PROJECT_"):
        dest_folder = os.path.join(g.g_abs_path_projects, f'PROJECT_{proj_num}', 'MAP')
        dest_filepath = os.path.join(dest_folder, f'{text}{proj_num}.html')
        if not os.path.exists(dest_folder):
            os.makedirs(dest_folder)
        shutil.copy(orig_filepath, dest_filepath)  # Move the file
        try:
            shutil.copytree(g.g_mapres, os.path.join(dest_folder, 'mapres')) 
        except Exception as e:
            print(f"error copying folder (details: error msg: {e})")
        return dest_filepath

    def plot_json_plan(self, proj_num, open_after_generated=True, ami_evident_group=[]):
        projs_dir = g.g_abs_path_projects

        projs_folders = [f.path for f in os.scandir(projs_dir) if f.is_dir()]

        proj_folder_name = f"PROJECT_{proj_num}"
        has_it = [string for string in projs_folders if proj_folder_name in string]
        if len(has_it) == 0:
            errmsg = f'NO PROJECT FOLDER NUMBER {proj_num} FOUND'
            messagebox.showerror("Error gen map", errmsg)
            print(errmsg)
            return
        
        # normalize path to target os
        targ_proj_path = os.path.join(has_it[0])

        # get data from bh nodes & links from JSONs
        bhnodes_js = {}
        bhlinks_js = {}
        aminodes_js = {}
        bhnpath = f'{targ_proj_path}/JSON/bhnodes.json'
        bhlpath = f'{targ_proj_path}/JSON/bhlinks.json'
        aminodesjsonfile = f'{targ_proj_path}/JSON/aminodes.json'


        has_bhn_plan = (os.path.exists(bhnpath) and os.path.exists(bhlpath))
        has_ami_plan =  os.path.exists(aminodesjsonfile)
        if not has_bhn_plan and not has_ami_plan:
            raise Exception(
                "It looks like you have not ran any planning for this project yet. You must fully execute the planning at least once to generate the 'planned map'.")

        if has_bhn_plan:
            with open(bhnpath, 'r') as f:
                bhnodes_js = json.load(f)
            with open(bhlpath, 'r') as f:
                bhlinks_js = json.load(f)

        if has_ami_plan:
            with open(aminodesjsonfile, 'r') as f:
                aminodes_js = json.load(f)

        if (len(aminodes_js) == 0) and (len(bhnodes_js) == 0):
            raise Exception("Nothing to plot. No planned BHN or AMI data found.")
        

        # extract the coords from seqgeo from polesnearsub csv
        seqgeo2coords = {}
        polesnearsub_csv = pd.read_csv(
            f'{targ_proj_path}/Latlong/polesnearsub.csv',  sep=';', decimal='.')
        for index, row in polesnearsub_csv.iterrows():
            seqgeo2coords[row["NUM_SEQ_GEO"]] = [
                row["LAT"], row["LON"]]

        # get a initial position, for settingup map, say, first substation
        init_pos = [0.0,0.0]
        if has_bhn_plan:
            first_subs = [ss for ss in bhnodes_js if ss['type'] == 'SUB'][0]
            init_pos = seqgeo2coords[first_subs['pole_uid']]
        else:
            first_node_ami = aminodes_js[0]
            init_pos = [first_node_ami['lat'], first_node_ami['lon']]

        # ==================================================
        # Create MAP
        # ==================================================
        google_default = "http://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}"
        google_topography = "http://mt1.google.com/vt/lyrs=p&x={x}&y={y}&z={z}"
        tlurl_toner = 'http://tile.stamen.com/toner/{z}/{x}/{y}.png '

        # new tile servers
        # opentopo
        opentoposrc = "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png"
        satellite2src = "'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"

        tile_layer = folium.TileLayer(
            tiles=google_topography,
            attr='&copy; <a href="https://www.google.org/">Google</a> contributors &copy; <a href="#">Corporate copyright</a>',
            max_zoom=19,
            name='Topografia Google',
            control=True,
            opacity=0.7
        )
        osm_layer = folium.TileLayer(
            tiles="OpenStreetMap",
            attr='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
            max_zoom=19,
            name='OpenStreetMap',
            control=True,
            opacity=0.9,
            overlay=True
        )
        OpenTOPO = folium.TileLayer(
            tiles=opentoposrc,
            attr='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
            max_zoom=19,
            name='OpenTopo',
            control=True,
            opacity=0.9,
            overlay=True
        )
        tlayer_toner = folium.TileLayer(
            tiles=tlurl_toner,
            attr='&copy; <a href="http://maps.stamen.com/">Stamen</a> contributors &copy; <a href="#">Corporate copyright</a>',
            max_zoom=19,
            name='Toner',
            control=True,
            opacity=0.7,
            overlay=True
        )

        m = folium.Map(tiles=google_default,
                       name='Google Maps',
                       attr='Google Maps',
                       location=[init_pos[0],
                                 init_pos[1]], zoom_start=13
                       )
        tile_layer.add_to(m)
        osm_layer.add_to(m)
        OpenTOPO.add_to(m)
        # tlayer_toner.add_to(m)

        # ==================================================
        # Add elements
        # ==================================================
        if has_bhn_plan:
            self.add_planned_bh_element_from_json(
                bhnodes_js, bhlinks_js, seqgeo2coords, m)
            self.add_planned_bh_links_from_json(
                bhnodes_js, bhlinks_js, seqgeo2coords, m)

        if len(aminodes_js) > 0:
            self.add_planned_ami_from_json(aminodes_js, m, ami_evident_group)
        
        if has_bhn_plan:
            # extra params (dynamic defined by user)
            dynamic_params = get_dynamic_params(bhlinks_js, g_dynamic_pa_prefix)
            for dypa in dynamic_params:
                # FIXME: alias same as param name, should there be a way to give name to them on a config file
                self.add_dynamic_param_links(
                    bhnodes_js, bhlinks_js, seqgeo2coords, dypa, dypa, m)

            # experimental, link quality
            add_planned_bh_links_quality_from_json(
                self, bhnodes_js, bhlinks_js, seqgeo2coords, m)

        # ==================================================
        # Wrap up the map
        # ==================================================
        folium.LayerControl().add_to(m)

        # ==================================================
        # Save file
        # ==================================================
        def save_root_folder():
            out_file_name = f"MAP_JSON_SPARE_PROJ_{proj_num}_PLANNED_BH_.html"
            out_folder = g.g_abs_path_maps

            # Create the directory if it doesn't exist
            if not os.path.exists(out_folder):
                os.makedirs(out_folder)

            out_file_name = os.path.join(out_folder, out_file_name)
            m.save(out_file_name)

            print(f"HTML generated, output: '{out_file_name}'")
            return out_file_name


        generated_file = save_root_folder()

        map_on_proj_folder = self.copy_to_proj_folder(generated_file, proj_num, text="PLANNED_MAP_PROJECT_")

        if open_after_generated is True:
            webbrowser.open("file://" + map_on_proj_folder)

        return map_on_proj_folder

    def hex_to_rgb(self, hex_color):
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return (r, g, b)


def rgb_to_hex(rgb_tuple):
    """Convert the RGB color values to hexadecimal and concatenate them"""
    return "#{:02x}{:02x}{:02x}".format(rgb_tuple[0], rgb_tuple[1], rgb_tuple[2])


def get_link_quality_color(value, min_value, max_value):
    """Ranges linearly from red(worst) to grenn (best)"""
    # Calculate the range of the input values
    value_range = max_value - min_value

    # Calculate the value's position within the range as a percentage
    value_percent = (value - min_value) / value_range

    # Calculate the values of the red, green, and blue channels based on the percentage
    red = 255 * (1 - value_percent)
    green = 255 * value_percent
    blue = 0

    # Construct the RGB color value as a tuple and return it
    color = (int(red), int(green), int(blue))
    return rgb_to_hex(color)


def add_planned_bh_links_quality_from_json(self, nodes, links, coords, map):
    line_group = folium.FeatureGroup(name='Links Quality', show=True)
    map.add_child(line_group)
    print(links)
    print(nodes)

    # get lowest and highest values for los
    low = links[0]["los"]
    high = links[0]["los"]
    for link in links:
        if link["los"] < low:
            low = link["los"]
        if link["los"] > high:
            high = link["los"]

    # =================== ===================

    for index, node in enumerate(nodes):
        if node['label'] != None:
            if node['next_hop'] == 'none':
                print(f"{node['label']} is root element")
                continue
            else:
                print(f"{node['label']}---conected--->{node['next_hop']}")

            elem_connected_to = {}
            try:
                elem_connected_to = [
                    ec for ec in nodes if ec['label'] == node['next_hop']][0]
            except Exception as e:
                print(f"[ISSUE] {node['next_hop']} not fould! {e}")
                return
            # get the current link information
            link_info = {}
            try:
                link_info = [linfo for linfo in links if linfo['dnode'] ==
                             node['label'] and linfo['snode'] == elem_connected_to['label']][0]
            except Exception as e:
                print(
                    f"NO LINK INFO, CANT COLOR LINK!!!\nException thown too, furtehr info:{e}")
            link_color = get_link_quality_color(link_info['los'], low, high)

            # note 0, 2 means first row, <colums>
            elem2 = elem_connected_to
            latlon_a, latlon_b = coords[node['pole_uid']
                                        ], coords[elem2['pole_uid']]
            line = [(latlon_a[0], latlon_a[1]),
                    (latlon_b[0], latlon_b[1])]
            # print(line)
            # get color for line
            root_label = node['path'][0]
            line_color = link_color
            folium.PolyLine(line, color=line_color).add_to(line_group)

        else:
            print(f"[ISSUE]: element {index} of df has no label.")
    print("[OK] - Added Planned links")


def get_project_folders(directory_path):
    project_folders = {}
    for folder_name in os.listdir(directory_path):
        if folder_name.startswith("PROJECT_"):
            project_number = folder_name.split("_")[1]
            project_folders[project_number] = folder_name
    return project_folders


def get_dynamic_params(links, prefix):
    """
    Gather parameters that user can define, they vary from .0f to 1.f 
    These can be added by user at their liking,
    for ache of them create a new layer and color accordingly to the normal val
    This will just return a list of tags that have been found on the bhlinks json

    you must pass the links json object to check them"""

    unique_tags = set()
    for link in links:
        for key in link.keys():
            if key.startswith(prefix):
                unique_tags.add(key)
    return unique_tags


if __name__ == "__main__":
    root = tk.Tk()
    about = "Plot BH planning from it's JSONs"
    root.title(about)

    # Create a label for the dropdown
    ttk.Label(root, text=about).pack(pady=10, padx=10)
    ttk.Label(root, text="Select the project number:").pack(pady=10)

    project_folders = get_project_folders(g.g_abs_path_projects)
    dropdown = ttk.Combobox(root, values=list(project_folders.keys()))
    dropdown.pack(padx=10, pady=10)

    ttk.Label(root, text="(optional) Display AMI netwroks separately (by gateway)\ne.g. \"g1 G2 g3\"\nLeave blank to group all into single layer").pack(pady=10, padx=10)
    sv_groups = tk.StringVar()
    # TODO: add suggestion later
    sepg_entry = ttk.Entry(root, textvariable=sv_groups)
    sepg_entry.pack(pady=10)

    def gen_the_map():
        mapinst = Map()
        try:
            selected_num = int(dropdown.get())
            sepamis = sv_groups.get()
            sep_gws = []
            if sepamis != "":
                sep_gws = sepamis.upper().replace(",", "").split()
            mapinst.plot_json_plan(selected_num, True, sep_gws)

        except Exception as e:
            print(f"ERROR: {e}")
            messagebox.showerror("ERROR", f"AN ERROR>\nf{e}")
        print("finish")

    # Create the OK button
    ok_button = ttk.Button(root, text="OK", command=gen_the_map)
    ok_button.pack(pady=10, padx=5)

    root.mainloop()
