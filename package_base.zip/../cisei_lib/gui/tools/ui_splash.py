import tkinter as tk
import time
import globals as g
import qol as q
g_splash_size = "300x200"
class SplashScreen():
    def __init__(self, timer_ms=300):
        self.splash = tk.Tk()
        q.set_window_icon(self.splash, g.g_app_icon) # whoever appears first got to set the icon
        self.splash.overrideredirect(True)
        
        sz = g_splash_size.split("x")
        self.splash_width, self.splash_height = int(sz[0]), int(sz[1]) 
        self.screen_width = self.splash.winfo_screenwidth()
        self.screen_height = self.splash.winfo_screenheight()
        x = (self.screen_width - self.splash_width) // 2
        y = (self.screen_height - self.splash_height) // 2
        self.splash.geometry('{}x{}+{}+{}'.format(self.splash_width, self.splash_height, x, y))
        
        # Create a label and add an image to it
        self.image = tk.PhotoImage(file=f"{g.g_resources_folder}/splash.png")
        self.label = tk.Label(self.splash, image=self.image)
        self.label.pack()
        
        # Update the window and delay the program for a few seconds to display the splash screen
        self.splash.update()

        self.splash.after(timer_ms, self.splash.destroy)


if __name__ == "__main__":
    # Create an instance of the SplashScreen class
    splash_screen = SplashScreen()

    # Create the main window
    root = tk.Tk()
    root.title("My App")
    root.geometry("400x300")

    # Add some widgets to the main window
    label = tk.Label(root, text="Welcome to my app!")
    label.pack()

    button = tk.Button(root, text="Click me!")
    button.pack()

    # Start the main loop
    root.mainloop()
