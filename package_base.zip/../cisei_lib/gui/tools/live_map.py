from queue import Queue
import threading
import time
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from flask import Flask, request, jsonify
from markupsafe import escape
from waitress import serve
import json
from tkinter import messagebox
import cisei_lib.gui.tools.qol as q
import cisei_lib.globals as g
import pandas as pd
import ast  # convert tags from str to dict
import numpy as np  # split batches for executemany
import cisei_lib.cli.planner.PlanLib as pl
import cisei_lib.cli.planner.DBWrapper as dbw
import cisei_lib.gui.widgets.wd_pinpoint_tag as ppoint
import cisei_lib.gui.widgets.wd_project as wdp
import cisei_lib.gui.widgets.wg_progressbar as wpb

import live_map_writter as lmw

g_map_mem = {}  # clobal dictionary with current planning loaded from memory
g_serial = 0  # serial to indicate changing on the map
g_map_mem_lock = threading.Lock()
g_running = False # this is to control 1 action per time, user might click multiple times, and we need to ignore

class MyFileHandler(FileSystemEventHandler):
    def __init__(self, state_queue):
        super().__init__()
        self.state_queue = state_queue

    def on_modified(self, event):
        if not event.is_directory:
            filename = os.path.basename(event.src_path)
            # print(f"File modified: {filename}")
            self.state_queue.put({"file": filename, "state": "modified"})
            if filename == "memory.json":
                with g.g_memory_is_writing_lock:
                    with g_map_mem_lock:
                        print("(on_modified - Lock) reloading memory")
                        global g_map_mem
                        global g_serial
                        g_map_mem = load_json()
                        g_serial += 1
                        # notice how the .json serial doesn't matter, we always overwrite it.
                        g_map_mem["serial"] = g_serial
                        print("(on_modified - Released) memory")

    def on_created(self, event):
        if not event.is_directory:
            print(f"File created: {event.src_path}")


def watch_files(queue):
    event_handler = MyFileHandler(queue)
    observer = Observer()
    observer.schedule(event_handler, path='./', recursive=True)
    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


app = Flask(__name__)
# app.debug = True


@app.after_request
def after_request(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    return response


@app.route('/')
def hello():
    name = request.args.get("name", "World")
    return f'Hello, {escape(name)}!'


@app.route('/cur_plan')
def cur_plan():
    global g_map_mem
    if g_map_mem != {}:
        return jsonify(g_map_mem)  # TODO: FIXME: make return only index to save bw
    return jsonify({"status": "NO_MAP"})

def save_regions():
    print("waiting g_map_mem")
    with g_map_mem_lock:
        regs_json_string = json.dumps(g_map_mem["regions"], indent=4)
        regs_file = f"{g.g_workdir}/{g.g_projects_folder}/{g_map_mem['proj_folder']}/JSON/LIVEMAP/regions.json"
        q.save_file_to_nested_folder(regs_file, regs_json_string)
        print("releasing g_map_mem lock")


@app.route('/add_rect/<lat1>/<lng1>/<lat2>/<lng2>')
def add_rect(lat1, lng1, lat2, lng2):
    random_id = q.generate_uid()

    g_map_mem["regions"].append({
        "p1": [(float)(lat1), (float)(lng1)],
        "p2": [(float)(lat2), (float)(lng2)],
        "name": "Added by user via WebGUI",
        "reg_uid": random_id
    })
    try:
        save_regions()
    except Exception as e:
        messagebox.showerror("An error occurred",
                             f"Failed to save regions .json file\n !, {e}")
        print(f"Failed to save regions json\n !, {e}")

    return jsonify({
        "reg_uid": random_id
    })


@app.route('/edit_rect/<ref>/<lat1>/<lng1>/<lat2>/<lng2>')
def edit_rect(ref, lat1, lng1, lat2, lng2):
    # print(f"edit rect id {ref}")
    # print(f"{lat1} {lng1} {lat2} {lng2}")
    updt_ok = False
    if g_map_mem["regions"] is not None and len(g_map_mem["regions"]) > 0:
        for reg in g_map_mem["regions"]:
            if reg["reg_uid"] == ref:
                reg["p1"] = [float(lat1), float(lng1)]
                reg["p2"] = [float(lat2), float(lng2)]
                updt_ok = True
                break
        if updt_ok:
            jstr = json.dumps(g_map_mem, indent=4)
            save_regions()  # save this first, so we dont race against the file_watch that rewrites global
            with g_map_mem_lock:
                q.save_file_to_nested_folder(g.g_abs_path_map_memory, jstr)
    return jsonify({"resp": updt_ok})


@app.route('/remove_rect/<ref>')
def remove_rect(ref):
    updt_ok = False
    if g_map_mem["regions"] is not None and len(g_map_mem["regions"]) > 0:
        for reg in g_map_mem["regions"]:
            if reg["reg_uid"] == ref:
                g_map_mem["regions"].remove(reg)
                updt_ok = True
                break

        if updt_ok:
            jstr = json.dumps(g_map_mem, indent=4)
            save_regions()
            with g_map_mem_lock:
                q.save_file_to_nested_folder(g.g_abs_path_map_memory, jstr)

        # print(g_map_mem["regions"]) # dbg

    return jsonify({"resp": updt_ok})


def get_proj_nodes_from_compile():
    ret_nodes = {
        "poles": [],
        "meters": [],
        "dads": [],
        "towers": [],
        "pops": []
    }  # this is a copy
    with pl.PlanLib(db_file=g.g_database_file) as p:
        with open(os.path.join(p.pdir, f"{g_map_mem['proj_folder']}/pdl.json")) as f:
            p.compilePDL(f, save=False)

            # make copy of specific p.nodes elements
            for key in ret_nodes:
                if p.nodes[key] is not None and not p.nodes[key].empty:
                    ret_nodes[key] = p.nodes[key].copy()
    return ret_nodes


@app.route('/remove_drop_tags')
def remove_drop_tags():
    global g_running
    if g_running is True:
        return jsonify({"status":"BUSY"})
    g_running = True

    # this spawns a progress dialog if no g.g_main_pbq is set
    retq = None  # queue to store resturn val when running in thread

    def job(pbq=None):
        try:
            proapi = wdp.APIProject(g_map_mem['proj_num'])
            updated_entries, total_poles_computed = proapi.remove_drop_tags()
            retobj = {"project_folder": g_map_mem['proj_folder'],
                      "status": "OK",
                      "desc": f"updated {updated_entries} of {total_poles_computed}"}
            global g_running
            g_running = False
        except Exception as ex:
            messagebox.showerror(f"Error on removing drop tags",
                                 "Error on removing drop tags\n\n {ex}")

        if retq is not None:
            retq.put(retobj)
            return
        return retobj

    if g.g_main_pbq == None:
        pb = wpb.ProgressBarDiag(
            g.g_main_window, "Removing tag regions", "", True)
        g.g_main_pbq = pb.queue
        retq = Queue()
        pb.start_thread(job)
        val = retq.get()
        g.g_main_pbq = None
        g.g_main_window.lower()
        return jsonify(val)
    else:
        return jsonify(job())


@app.route('/apply_reg_tags')
def apply_reg_tags():
    retq = None
    global g_running
    if g_running is True:
        return jsonify({"status":"BUSY"})
    g_running = True

    def job(pbq=None):
        if g_map_mem["regions"] is not None and len(g_map_mem["regions"]) > 0:
            print("has regions")
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message, "Fetching regions")
            nodes = get_proj_nodes_from_compile()
            print(nodes["poles"])
            full_poles = nodes["poles"]
            reg_poles = pd.DataFrame()  # poles inside regs
            for reg in g_map_mem["regions"]:
                print(reg)
                lat_min = min(reg['p1'][0], reg['p2'][0])
                lat_max = max(reg['p1'][0], reg['p2'][0])
                long_min = min(reg['p1'][1], reg['p2'][1])
                long_max = max(reg['p1'][1], reg['p2'][1])
                # FIXME: this only gets last region... to fix do a merge
                reg_poles = pd.concat([reg_poles, full_poles[(full_poles['lat'] >= lat_min) & (full_poles['lat'] <= lat_max) &
                                                             (full_poles['long'] >= long_min) & (full_poles['long'] <= long_max)]], ignore_index=True)
            print(reg_poles)

            msg = f"Updating {len(reg_poles)} poles entries on database"
            print(msg)
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message, msg)
            qry_data = []
            tsize = len(reg_poles)
            for index, pole in reg_poles.iterrows():
                wpb.do_if_has_pb(g.g_main_pbq, wpb.progress,
                                 wpb.lazy_prog_lerp(0, 99, index/tsize))
                p_uid = pole['uid']
                tags_str = pole['tags']
                tags_dict = ast.literal_eval(tags_str)
                tags_dict["drop"] = True
                tags_str = str(tags_dict)
                # do something with the row
                qry_data.append((tags_str, p_uid))

            batches = np.array_split(qry_data, 10)
            total_processes = 0
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message, f"Writing on Database")
            tsize = len(batches)
            # tmr = wpb.PBTimer(1.0)
            for i, batch in enumerate(batches):
                wpb.do_if_has_pb(g.g_main_pbq, wpb.progress,
                                 wpb.lazy_prog_lerp(0, 99, i/tsize))
                with dbw.MySQL() as db:
                    try:
                        db.executemany(
                            f"UPDATE poles SET tags = ? WHERE uid = ?;", batch)
                        total_processes += len(batch)
                    except Exception as e:
                        print(f'The t_EJ was not replaced', str(e))
            print(f"finish apply_Reg_Tags [TOTAL: {total_processes}]")
            
            global g_running
            g_running = False
            
            wpb.do_if_has_pb(g.g_main_pbq, wpb.progress, 100)
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message,
                             f"Regions tags applied {total_processes}")

        retobj = {"project_folder": g_map_mem['proj_folder'],
                  "resp": "OK", "regs": g_map_mem["regions"]}
        if retq is not None:
            retq.put(retobj)
            return
        return retobj

    if g.g_main_pbq == None:
        pb = wpb.ProgressBarDiag(
            g.g_main_window, "Applying tag regions", "", True)
        g.g_main_pbq = pb.queue
        retq = Queue()
        pb.start_thread(job)
        val = retq.get()
        g.g_main_pbq = None
        return jsonify(val)
    else:
        return jsonify(job())


@app.route('/reload')
def reload():
    global g_running
    if g_running is True:
        return jsonify({"status":"BUSY"})
    g_running = True
    
    if g.g_proj_num == -1:
        messagebox.showwarning("Attention", f"You must select a project first !")
        return jsonify({"status": "no_proj_selected"})
    
    # lmw._write() # old, no progress bar

    def th(pbq):
        try:
            lmwo = lmw.APLILiveMapWritter(g.g_proj_num)
            lmwo._write(pbq=pbq)
        except Exception as ex:
            messagebox.showerror("Error", f"Error while attempting to recompile/reload map: {ex}")
        global g_running
        g_running = False
    
    pbd = wpb.ProgressBarDiag(
        root=g.g_main_window, title=f"Reloading map for project {g.g_proj_num}", tail_file="", topmost=True)
    pbd.start_thread(targ=th)


@app.route('/pinpoint/<type>/<ref>')
def pinpoint(type, ref):
    print(f"tag-pinpoint {type} {ref}")
    ppoint.WindowPinpointTag(type=type, uid=ref)
    return jsonify({"status": "ok"})


@app.route('/memory')
def memory():
    print(f"{g_map_mem}")
    return jsonify(g_map_mem)


def start_flask_app():
    # app.run(debug=True, port=5000) # this updates
    serve(app, host="0.0.0.0", port=g.g_backend_port)


def load_json():
    temp_dict = {}
    try:
        with open(g.g_abs_path_map_memory, "r") as f:
            temp_dict = json.load(f)
    except Exception as e:
        print(f"RACING CONDITION WHILE READING MEMORY.JSON\n {e}")
    return temp_dict


class LiveMap():
    def __init__(self):
        self.state_queue = Queue()
        t = threading.Thread(target=watch_files, args=(self.state_queue,))
        t.start()

        global g_map_mem
        with g_map_mem_lock:
            print("(LiveMap  __init__ - Lock)")
            g_map_mem = load_json()
            print("LiveMap  __init__ - Release")

        flask_thread = threading.Thread(target=start_flask_app)
        flask_thread.start()


if __name__ == "__main__":
    lm = LiveMap()

    while True:
        if not lm.state_queue.empty():
            print(f"state_queue size: {lm.state_queue.qsize()}")
            state = lm.state_queue.get()
            print(f"raw object {state}")
        time.sleep(1)
