# The purpose of this is only to write valid JSONs that LIVEMAP can read


import os
import pandas as pd
import json
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import time
import shutil
import cisei_lib.cli.planner.PlanLib as pl
import cisei_lib.globals as g
import cisei_lib.cli.planner.DBWrapper as dbw
import cisei_lib.gui.tools.qol as q
import cisei_lib.gui.widgets.wg_progressbar as wpb


class APLILiveMapWritter():
    def __init__(self, proj_num):
        self.projs = self.get_projects_as_dicts()
        proj_dict = None
        for p in self.projs:
            if p['id'] == proj_num:
                proj_dict = p
                break
        if proj_dict == None:
            raise Exception(f"APLILiveMapWritter: Couldn't find project {proj_num}")
        
        self.pdl_file = os.path.join(proj_dict['folder'], 'pdl.json')
        self.proj_num = proj_dict["id"]
        self.proj_folder = proj_dict["folder"]
        self.proj_name = proj_dict["name"]
        self.proj_city = proj_dict["city"]
        self.proj_folder_abs = os.path.join(g.g_abs_path_projects, self.proj_folder)
        self.livemap_cache_path = os.path.join(self.proj_folder_abs, 'JSON', 'LIVEMAP', 'livemap.json')
        print(self.proj_folder_abs)
        # self._write()
    
    def has_livemap_cache(self):
        return os.path.exists(self.livemap_cache_path)

    def get_projects_as_dicts(self):
        if q.has_db_file() is True:
            with dbw.MySQL() as db:
                df = pd.read_sql(f"select * from projects;",
                                 db.connection)
                rslen = len(df)
                if rslen > 0:
                    return df.to_dict(orient='records')
                
    def _get_regions(self):
        if self.proj_folder == "":
            raise Exception("_get_regions> Fetch regions fail: No project folder found")
        
        regs_file = os.path.join(self.proj_folder_abs, 'JSON', 'LIVEMAP', 'regions.json')

        proj_regions_string = q.load_file_if_not_exitst_default(
            regs_file, "[]")
        proj_regions = json.loads(proj_regions_string)
        return proj_regions
    
    def _load(self, pbq=None):
        # copies file from folder to main dir, if doesn't exist,  runs the _write
        if self.has_livemap_cache():
            with g.g_memory_is_writing_lock:
                wpb.do_if_has_pb(pbq, wpb.message, "Loading livemap file...")
                
                # we must inser the regions when copying to main folder
                regs = self._get_regions()
                wpb.do_if_has_pb(pbq, wpb.progress, 50)
                memorydict = None
                with open(self.livemap_cache_path, "r") as f:
                    memorydict = json.load(f)
                wpb.do_if_has_pb(pbq, wpb.progress, 80)
                if memorydict is not None:
                    memorydict['regions'] = regs
                    with open(g.g_abs_path_map_memory, 'w') as f:
                        f.write(json.dumps(memorydict, indent=4)) 
                # shutil.copy(self.livemap_cache_path, "./memory.json")
                wpb.do_if_has_pb(pbq, wpb.progress, 100)
        else:
            msg = f"No previous livemap generated for project {self.proj_num}... Generating onw now."
            print(msg)
            wpb.do_if_has_pb(pbq, wpb.message, msg)
            self._write(pbq=pbq)

    def _write(self, pbq=None):
        try:
            wpb.do_if_has_pb(pbq, wpb.message, "Fetching project information")
            proj_regions = self._get_regions()

            with pl.PlanLib(db_file=g.g_database_file) as p:
                with open(os.path.join(p.pdir, self.pdl_file)) as f:
                    wpb.do_if_has_pb(pbq, wpb.message, "Recompiling project")
                    p.compilePDL(f, save=False)

                    # FIXME: just check for poles might be incorrect
                    if not p.nodes["poles"].empty:
                        poles_df = p.nodes["poles"]
                        meters_df = p.nodes["meters"]
                        pops_df = p.nodes["pops"]
                        towers_df = p.nodes["towers"]
                        dads_df = p.nodes["dads"]

                        def build_array(some_df, extra_cols=None, pb_context_desc="Updating", startp=0, endp=99):
                            ret_arr = []
                            if some_df is not None:
                                dflen = len(some_df)
                                tmr = wpb.PBTimer(1.0)
                                for i in range(0, dflen):
                                    # poles
                                    lat = some_df.iloc[i].lat
                                    long = some_df.iloc[i].long
                                    arr = [lat, long]

                                    if extra_cols is not None:
                                        for c in extra_cols:
                                            arr.append(some_df.iloc[i][c])
                                    ret_arr.append(arr)

                                    if tmr.has_elapsed(i/dflen):
                                        val = wpb.lazy_prog_lerp(
                                            startp, endp, i/dflen)
                                        wpb.do_if_has_pb(
                                            pbq, wpb.progress, val)
                                        wpb.do_if_has_pb(
                                            pbq, wpb.message, f"{pb_context_desc} - {val} %\n{tmr.eta()}")
                            return ret_arr

                        # aside from coordinates, we gather some special according to each element

                        poles = build_array(
                            poles_df, ['uid', 'pop', 'tags'], "Writing coords for poles", 0, 99)
                        meters = build_array(
                            meters_df, ['uid', 'pop', 'type'], "Writing coords for meters", 0, 99)
                        pops = build_array(
                            pops_df, ['uid', 'pole_uid', 'pop_name'], "Writing coords for pops", 0, 99)
                        towers = build_array(
                            towers_df, ['uid', 'pop', 'height'], "Writing coords for towers", 0, 99)
                        dads = build_array(
                            dads_df, ['uid', 'pop', 'pole_uid', 'type'], "Writing coords for dads", 0, 99)

                        wpb.do_if_has_pb(pbq, wpb.message, "Writting JSON")
                        jsonf = {
                            "proj_folder": self.proj_folder,
                            "proj_name": self.proj_name,
                            "proj_num": self.proj_num,
                            "proj_city": self.proj_city,
                            "markers": [],
                            "poles": poles,
                            "meters": meters,
                            "pops": pops,
                            "towers": towers,
                            "dads": dads,
                            "regions": proj_regions,
                            "serial": 0
                        }

                        gen_out_path = g.g_abs_path_map_memory 
                        with g.g_memory_is_writing_lock:
                            with open(gen_out_path, 'w') as f:
                                f.write(json.dumps(jsonf, indent=4))
                        print("finishlivemap memory updated")

                        
                        try:
                            directory = os.path.dirname(self.livemap_cache_path)
                            if not os.path.exists(directory):
                                os.makedirs(directory)
                            shutil.copy2(gen_out_path, self.livemap_cache_path)
                        except Exception as ex:
                            print(f"Error while trying to copy livemap cache for project {self.proj_num}")
                        
                        print(f"Saved copy to project {self.proj_num} folder")


                        wpb.do_if_has_pb(pbq, wpb.message,
                                         "Live map updated !")
                        wpb.do_if_has_pb(pbq, wpb.progress, 100)
                        time.sleep(1)  # give time for user to read

        except Exception as e:
            messagebox.showerror(
                "_write ERROR", f"LiveMapWritter>_write()>\n{e}")
            print(e)


class WidgetLiveMapWritter(ttk.Frame):
    def get_projects_as_dicts(self):
        if q.has_db_file() is True:
            with dbw.MySQL() as db:
                df = pd.read_sql(f"select * from projects;",
                                 db.connection)
                rslen = len(df)
                if rslen > 0:
                    self.projs = df.to_dict(orient='records')

    def write_memory(self):
        try:
            proj_dict = self.projs[g.g_proj_num]
            lmw = APLILiveMapWritter(proj_dict['id'])
            # lmw._write() # old, no progress bar
            pbd = wpb.ProgressBarDiag(
                root=self.master, title="Updating preplan map")
            pbd.start_thread(lmw._write, ())

        except Exception as e:
            messagebox.showerror("ERROR", f"AN ERROR>\nf{e}")
            print(f"ERROR: {e}")
        print("finish")

    def on_combobox_open(self):
        self.get_projects_as_dicts()  # update self.projs
        self.combo['values'] = [
            f"{item['id']} - {item['name']}" for item in self.projs]
        pass

    def __init__(self, master, **kwargs):
        self.projs = []
        self.master = master
        super().__init__(master=master, **kwargs)
        self.combo = ttk.Combobox(self)

        self.combo.bind("<Button-1>", lambda *args: self.on_combobox_open())
        self.get_projects_as_dicts()

        self.combo.pack(side='left', padx=2, pady=0, anchor='e')
        q.Tooltip(self.combo, "Select what project to show on preplan map (live)")

        btimg = tk.PhotoImage(file=os.path.join(g.g_abs_path_resources, 'icons', 'view-refresh.png'))
        ok_button = tk.Button(
            self, text="", compound="left", image=btimg, command=self.write_memory)
        ok_button.image = btimg  # prevent garbage colletion
        tooltiptext = """Recompile project and update preplan map\n\nAbout: This will recompile the selected project (selected in this toolbar) and generate the needed files to display in the preplan map (livemap)"""
        q.Tooltip(ok_button, tooltiptext)
        ok_button.pack(side="right")


class WindowLiveMapWritter():
    def __init__(self):
        self.projs = []

        def get_projects_as_dicts():
            projects = []
            with dbw.MySQL() as db:
                df = pd.read_sql(f"select * from projects;",
                                 db.connection)
                rslen = len(df)
                if rslen > 0:
                    projects = df.to_dict(orient='records')
            print(projects)
            return projects

        root = tk.Toplevel()
        root.title("Load live map project")
        label = ttk.Label(root, text="Select the project:")
        label.pack(pady=10)

        self.projs = get_projects_as_dicts()
        dropdown = ttk.Combobox(root)
        dropdown['values'] = [
            f"{item['id']} - {item['name']}" for item in self.projs]
        dropdown.pack()

        def write_memory():
            try:
                selection_index = dropdown.current()
                proj_dict = self.projs[selection_index]
                # TODO: check if compiled or has foder here
                lmw = APLILiveMapWritter(proj_dict)
                lmw._write()

            except Exception as e:
                messagebox.showerror("ERROR", f"AN ERROR>\nf{e}")
                print(f"ERROR: {e}")
            print("finish")

        ok_button = ttk.Button(root, text="OK", command=write_memory)
        ok_button.pack(pady=10)

        # test custom widget
        cwid = WidgetLiveMapWritter(root)
        cwid.pack(padx=10)


if __name__ == "__main__":
    root = tk.Tk()
    obj = WindowLiveMapWritter()
    root.mainloop()
