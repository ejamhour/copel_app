import tkinter as tk
from tkinter import ttk
import re
import os
import uuid
import globals as g
import subprocess  # openfile crossplat
from tkinter import messagebox


def generate_uid():
    return str(uuid.uuid4())


def sanitize_string_for_filename(input):
    s = input
    s = s.lower()
    s = s.replace(" ", "_")
    s = re.sub(r'[^a-zA-Z0-9_]+', '', s)
    return s


def set_window_icon(window, icon_path):
    icon = tk.PhotoImage(file=icon_path)
    window.iconphoto(True, icon)


class Tooltip:
    def __init__(self, widget, text, width=300):
        self.widget = widget
        self.text = text
        self.widget.bind("<Enter>", self.enter)
        self.widget.bind("<Leave>", self.leave)
        self.id = None
        self.tw = None
        self.width = width

    def enter(self, event=None):
        self.schedule()

    def leave(self, event=None):
        self.unschedule()
        self.hide()

    def schedule(self):
        self.unschedule()
        self.id = self.widget.after(300, self.show)

    def unschedule(self):
        id_ = self.id
        self.id = None
        if id_:
            self.widget.after_cancel(id_)

    def show(self, event=None):
        x, y = self.widget.winfo_pointerxy()
        x += 10
        y += 10
        self.tw = tk.Toplevel(self.widget)
        self.tw.wm_overrideredirect(True)
        self.tw.wm_geometry("+%d+%d" % (x, y))
        label = tk.Label(self.tw, text=self.text, justify='left', background="#ffffe0",
                         relief='solid', borderwidth=1, font=("tahoma", "10", "normal"), wraplength=self.width)
        label.pack(ipadx=1)

    def hide(self):
        tw = self.tw
        self.tw = None
        if tw:
            tw.destroy()


def center_window(window):
    if not hasattr(window, "title"):
        # user passed a non window to us, ignore
        print("center_window: element passed is not a window not a window")
        return
    window.update_idletasks()

    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()

    window_width = window.winfo_width()
    window_height = window.winfo_height()

    x = (screen_width - window_width) // 2
    y = (screen_height - window_height) // 2

    window.geometry('{}x{}+{}+{}'.format(window_width, window_height, x, y))


def center_to_parent(child, parent):
    """center child to parent window, on MS' Windows 11 this seems to be needed"""
    child.update()  # window might not be ready, and might be 1px 1px in size
    parent.update_idletasks()  # Update parent window info
    parent_width = parent.winfo_width()
    parent_height = parent.winfo_height()
    child_width = child.winfo_reqwidth()
    child_height = child.winfo_reqheight()
    x = parent.winfo_rootx() + (parent_width - child_width) // 2
    y = parent.winfo_rooty() + (parent_height - child_height) // 2
    child.geometry("+{}+{}".format(x, y))
    child.focus_set()  # Bring child window to the front


def move_under_mouse(window):
    x, y = window.winfo_pointerxy()
    window.geometry(f"+{x}+{y}")


def save_file_to_nested_folder(file_path, content):
    # Create the directory hierarchy if it doesn't exist
    directory = os.path.dirname(file_path)
    if not os.path.exists(directory):
        os.makedirs(directory)

    # Save the file
    with open(file_path, 'w') as f:
        f.write(content)


def load_file_if_not_exitst_default(file_path, default_value=None):
    if not os.path.exists(file_path):
        return default_value
    try:
        with open(file_path, 'r') as f:
            return f.read()
    except UnicodeDecodeError:
        return default_value


def delete_file_if_exists(file_path):
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
            print(f"File '{file_path}' deleted.")
        except Exception as ex:
            print(
                f"Error occurred while deleting the file '{file_path}': {ex}")
    else:
        print(f"File '{file_path}' does not exist.")


def has_db_file():
    if os.path.isfile( os.path.join(g.g_datadir, g.g_database_file ) ):
        return True
    return False


class IconButtom(ttk.Button):
    def __init__(self,  master, image=None, tooltip="", **kwargs):
        self.btimg = None
        if image is not None:
            self.btimg = tk.PhotoImage(file=image)
        super().__init__(master=master, image=self.btimg, **kwargs)
        if tooltip != "":
            Tooltip(self, tooltip)


def crossplat_open_file(filepath):
    try:
        if os.name == 'nt':  # For Windows
            os.startfile(filepath)
        elif os.name == 'posix':  # For Linux/Unix
            subprocess.run(['xdg-open', filepath])
    except Exception as ex:
        messagebox.showerror(
            "Error while opening", f"An error occurred while attempting to open the file:\n{ex}")


def crossplat_open_folder(folderpath):
    try:
        if os.name == 'nt':  # For Windows
            subprocess.Popen(f'explorer {folderpath}')
        elif os.name == 'posix':  # For Linux/Unix
            subprocess.run(['xdg-open', folderpath])
    except Exception as ex:
        messagebox.showerror(
            "Error while opening", f"An error occurred while attempting to open the folder:\n{ex}")


def hms_from_secs(secs):
    # Extract hours and minutes from the duration
    hours, remainder = divmod(secs, 3600)
    minutes, seconds = divmod(remainder, 60)
    return int(hours), int(minutes), int(seconds)


def kill_process_by_port(port):
    """Sometimes a port is left upen by us, this might help"""

    if os.name == 'nt':
        netstat_output = os.popen(
            f'netstat -ano | findstr :{port} | findstr LISTENING').read()
        if netstat_output:
            process_id = netstat_output.split()[-1]
            os.system(f'taskkill /F /PID {process_id}')
            print(f"Process with ID {process_id} killed.")
        else:
            print("No process found on the specified port.")
    else:
        lsof_output = os.popen(f'lsof -i :{port}').read()
        if lsof_output:
            process_id = lsof_output.split()[10]
            os.system(f'kill -9 {process_id}')
            print(f"Process with ID {process_id} killed.")
        else:
            print("No process found on the specified port.")


class CustomYesNoDialog(tk.Toplevel):
    def __init__(self, root, title="title", question="question", yestext="yes", notext="no"):
        super().__init__(root)
        self.root = root

        self.focus_set()
        self.grab_set()  # Set the window as modal
        if self.root is not None:
            self.transient(self.root)

        self.title(title)

        label = tk.Label(self, text=question, wraplength=300, anchor="w")
        label.pack(pady=10, padx=10)

        button_frame = tk.Frame(self)
        button_frame.pack(pady=10)

        yes_button = tk.Button(button_frame, text=yestext,
                               command=lambda: self.on_dialog_response(True))
        yes_button.pack(side=tk.LEFT, padx=5)

        no_button = tk.Button(button_frame, text=notext,
                              command=lambda: self.on_dialog_response(False))
        no_button.pack(side=tk.LEFT, padx=5)
        
        self.user_response = None
        center_to_parent(self, g.g_main_window)
        self.wait_window(self)

    def on_dialog_response(self, response):
        self.user_response = response
        self.destroy()


if __name__ == "__main__":

    root = tk.Tk()
    root.title("My App")
    root_width = 400
    root_height = 300

    label = tk.Label(root, text="Welcome to my app!")
    label.pack()

    button = tk.Button(root, text="Click me!")
    Tooltip(button, "This is a tooltip\nA multile\nTooltip")
    button.pack()

    center_window(root)
    root.mainloop()
