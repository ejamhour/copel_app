import tkinter as tk
import tkinter.ttk as ttk
import cisei_lib.gui.tools.qol as q
# import live_map_writter as lmw

class CustomButtonBar(ttk.Frame):
    def __init__(self, master, button_data):
        super().__init__(master)
        self.frame = ttk.Frame(self, relief='ridge', borderwidth=2)
        self.frame.pack(fill='x', padx=0, pady=0)
        self.button_data = button_data
        self.create_buttons()

    def create_buttons(self):
        for button_info in self.button_data:
            if  isinstance(button_info[0], str):
                button_name, button_callback, image_filepath, tooltip = button_info
                image = tk.PhotoImage(file=image_filepath)
                button = tk.Button(self.frame, text=button_name, image=image, command=button_callback, compound="left")
                button.image = image  # Keep a reference to the image to avoid garbage collection
                button.pack(side='left', padx=0, pady=0, anchor='e')
                if tooltip != "":
                    q.Tooltip(button, tooltip)



if __name__ == "__main__":
    def button1_callback():
        print("Button 1 clicked!")

    def button2_callback():
        print("Button 2 clicked!")

    def button3_callback():
        print("Button 3 clicked!")

    icon = "./icons/document-open.png"
    
    button_data = [
        ("Button 1", button1_callback, icon, "First button"),
        ("Button 2", button2_callback, icon, ""),
        ("Button 3", button3_callback, icon, "")
    ]
    root = tk.Tk()
    root.geometry('400x400')
    bar = CustomButtonBar(root, button_data)

    # combo = lmw.WidgetLiveMapWritter(bar.frame)
    # combo.pack(padx=10, pady=10)

    bar.pack(fill='x')
    root.mainloop()