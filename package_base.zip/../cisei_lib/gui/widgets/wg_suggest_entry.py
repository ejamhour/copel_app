import tkinter as tk

class SuggestEntry(tk.Entry):
    def __init__(self, master, valid_words, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.add_space = False # TODO: make configurable
        self.valid_words = valid_words
        self.current_suggestions = []
        self.menu = None
        self.bind('<KeyRelease>', self.show_suggestions)
        self.bind('<Escape>', self.hide_menu)
        self.bind('<Return>', self.select_suggestion)

    def show_suggestions(self, event):

        ignored_keys = ['Return', 'Left', 'Right', 'Shift_L', 'Shift_R', 'Control_L', 'Control_R']
        if event.keysym in ignored_keys:
            return # ignore
         
        input_text = self.get()
        matching_entries = [word for word in self.valid_words if input_text in word]

        if matching_entries == 1 and matching_entries == input_text:
            return # ignore exact match

        if not input_text:
            self.hide_menu()
            return
        words = input_text.split()
        if len(words) <= 0:
            return

        last_word = words[-1]
        self.current_suggestions = [word for word in self.valid_words if word.lower().startswith(last_word.lower())]
        if not self.current_suggestions:
            self.hide_menu()
            return

        
        if not self.menu:
            self.menu = tk.Toplevel(self)
            self.menu.overrideredirect(True)
            self.menu.bind('<FocusOut>', lambda event: self.menu.withdraw())
            self.menu_listbox = tk.Listbox(self.menu, width=self['width'])
            self.menu_listbox.pack(fill='both', expand=True)
            self.menu_listbox.bind('<Double-Button-1>', self.select_suggestion)
            self.menu_listbox.bind('<Return>', self.select_suggestion)
            self.bind('<Up>', lambda event: self.menu_listbox.focus_set())
            self.bind('<Down>', lambda event: self.menu_listbox.focus_set())
            self.bind('<Escape>', lambda event: self.hide_menu)

        self.menu_listbox.delete(0, tk.END)
        for word in self.current_suggestions:
            self.menu_listbox.insert(tk.END, word)
        self.menu_listbox.select_set(0)
        self.menu_listbox.see(0)

        x, y = self.winfo_rootx(), self.winfo_rooty() + self.winfo_height()
        width = self.winfo_width()
        self.menu.geometry(f'+{x}+{y}')
        self.menu.geometry(f'{width}x{self.menu_listbox.winfo_reqheight()}')
        self.menu.deiconify()
        # self.menu_listbox.focus_set()

    def hide_menu(self, event=None):
         if self.menu:
            self.menu.withdraw()

    def select_suggestion(self, event=None):
        if self.menu and self.current_suggestions:
            index = self.menu_listbox.curselection()[0]
            suggestion = self.current_suggestions[index]
            input_text = self.get()
            words = input_text.split()
            words[-1] = suggestion
            input_text = ' '.join(words)
            if self.add_space:
                input_text = input_text + ''
            self.delete(0, tk.END)
            self.insert(0, input_text)
            self.icursor(tk.END)

            self.focus_set()
            self.hide_menu()

if __name__ == "__main__":
    root = tk.Tk()
    valid_words = ["apple", "banana", "blue-berry", "apple gree",
                   "cherry", "date", "elderberry", "fig", "grape"]
    auto_complete_entry = SuggestEntry(root, valid_words, width=30)
    auto_complete_entry.pack(padx=0, pady=0)
    root.mainloop()
