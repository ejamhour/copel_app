import tkinter as tk
from tkinter import ttk


class TableWidget(ttk.Treeview):
    def __init__(self, master, cols, tdata, cb_func=None, context_commands=None, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        self.data = tdata
        self.cb_func = cb_func
        self.menu = None

        cols_string = [col if isinstance(
            col, str) else col[0] for col in cols if isinstance(col, (list, str))]

        self.configure(columns=cols_string)
        self.configure(show='headings')  # effectivelly hide the first col

        for header in cols:
            if type(header) == str:
                self.heading(header, anchor='w', text=f"{header.title()}")
                self.column(header)
            elif len(header) == 2:
                txt = header[0]
                self.heading(txt, anchor='w', text=f"{txt.title()}")
                self.column(header[0], width=header[1])
            else:
                raise ValueError("Wrong column specification")

        for row in self.data:
            self.insert("", "end", values=row)

        self.pack(fill="y", expand=True)
        self.bind("<Double-1>", self._on_double_click)
        self.bind("<Return>", self._on_double_click)

        # context menu
        if context_commands is not None:
            self.menu = self.create_menu()
            self.bind("<Button-3>", self.on_contmen_item_rightclick)
            self.bind("<Button-1>", self.on_contmen_parent_click)
            self.commands = context_commands

    def reload(self, tdata):
        self.data = tdata
        self.delete(*self.get_children())
        for row in self.data:
            self.insert("", "end", values=row)

    def _on_double_click(self, event):
        selc_id = self.selection()[0]
        selindex = int(self.index(selc_id))
        if self.cb_func:
            self.cb_func(selindex)

    def get_sel_index(self):
        selc_id = self.selection()[0]
        selindex = int(self.index(selc_id))
        return selindex

    # context menu
    def create_menu(self):
        menu = tk.Menu(self.master, tearoff=0)
        return menu
    
    def menu_update(self):
        self.menu.delete(0, 'end')
        for cmd, func in self.commands:
            self.menu.add_command(label=cmd, command=lambda index=self.index(
                self.selection()[0]), f=func: f(index))
        self.menu.add_separator()
        self.menu.add_command(label="Cancel", command=self.menu.unpost())

    def on_contmen_item_rightclick(self, event):
        item = self.identify_row(event.y)
        if item and self.menu is not None:
            self.selection_set(item)
            self.menu_update()
            self.menu.post(event.x_root, event.y_root)

    def on_contmen_parent_click(self, event):
        if self.menu and self.menu.winfo_ismapped():
            self.menu.unpost()

    def on_contmen_cancel_click(self):
        self.menu.unpost()


if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("600x200")
    root.update()

    def print_index(ind):
        print(ind)

    
    # Example context menu definitions
    def option1_func(index):
        print(f"Option 1 clicked for item {index}")
    def option2_func(index):
        print(f"Option 2 clicked for item {index}")
    commands = [("Option 1", option1_func), ("Option 2", option2_func)]
    # Example data
    headers = ["Name", "Age", "City"]
    data = [("Alice", 25, "New York"),
            ("Bob", 30, "San Francisco"),
            ("Charlie", 35, "Chicago")]

    # Create the table widgetz
    table = TableWidget(root, cols=headers, tdata=data, context_commands=commands, cb_func=print_index)

    # Pack the table widget into the root window
    table.pack(fill="both", expand=True)

    root.mainloop()
