import tkinter as tk
from tkinter import ttk
import wg_footer as footer


class Sidebar(ttk.Frame):
    def __init__(self, master=None, *args, **kwargs):
        super().__init__(master, *args, **kwargs)
        scrollbar = ttk.Scrollbar(self, orient="vertical")
        self.treeview = ttk.Treeview(self, yscrollcommand=scrollbar.set)
        self.treeview.heading("#0", text="Sidebar")
        self.treeview.column("#0", stretch=True)
        for i in range(10):
            self.treeview.insert("", "end", text=f"Item {i}")
        scrollbar.pack(side="right", fill="y")
        self.treeview.pack(side="left", fill="both", expand=True)

if __name__ == "__main__":

    root = tk.Tk()
    root.geometry("640x480")

    pw = tk.PanedWindow(root, orient=tk.HORIZONTAL)
    pw.pack(fill=tk.BOTH, expand=1)

    left_frame = sidebar = Sidebar(root, width=140)
    right_frame = tk.Frame(pw)

    pw.add(left_frame)
    pw.add(right_frame)

    footer.FooterWidget(root, {
        "version": "prototype"
    })

    root.mainloop()
