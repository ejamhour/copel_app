import tkinter as tk
from tkinter import ttk


class ScrollableFrame(tk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)
        self.canvas = tk.Canvas(self, highlightthickness=0)
        scrollbar = ttk.Scrollbar(
            self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.scrollable_frame = ttk.Frame(self.canvas)
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.canvas.bind("<Configure>", self.on_canvas_configure)
        self.canvas.create_window(
            (0, 0), window=self.scrollable_frame, anchor="nw")
        self.scrollable_frame.bind("<Configure>", self.on_frame_configure)

    def on_canvas_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def on_frame_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))


class TkVarTable(tk.Frame):
    def __init__(self, master, headers, colsizes=[]):
        super().__init__(master)
        self.headers = headers
        self.rows = []
        self.rows_data = []
        self.colsizes = colsizes
        self.lencolsizes = len(colsizes)
        # self.add_header()

    def add_header(self):
        for col, header in enumerate(self.headers):
            label = ttk.Label(self, text=header)
            label.grid(row=0, column=col, padx=1, pady=1)

    def remove(self, row, data):
        self.rows.remove(row)
        self.rows_data.remove(data)

        # so to no iterate and modify at same time
        rows_data_copy = self.rows_data.copy()
        self.rows.clear()
        self.rows_data.clear()

        for widget in self.winfo_children():
            widget.destroy()

        if len(self.rows) > 0:
            self.add_header()

        for data in rows_data_copy:
            self.add_row(data)

    def clear_rows(self):
        self.rows.clear()
        self.rows_data.clear()
        for widget in self.winfo_children():
            widget.destroy()
        # self.add_header()


    def add_row(self, data):
        if len(self.rows) == 0:
            self.add_header()

        row = []
        for col, item in enumerate(data):
            if isinstance(item, tk.StringVar):
                entry = ttk.Entry(self, textvariable=item)
                entry.grid(row=len(self.rows) + 1, column=col, padx=1, pady=1)
                if self.lencolsizes > 0 and self.lencolsizes >= col+1:
                    entry.configure(width=self.colsizes[col])
                row.append(entry)
            elif isinstance(item, tk.BooleanVar):
                checkbox = ttk.Checkbutton(self, variable=item)
                checkbox.grid(row=len(self.rows) + 1,
                              column=col, padx=1, pady=1)
                row.append(checkbox)
            elif isinstance(item, list):
                combo_var = tk.StringVar(value=item[0])
                combo = ttk.Combobox(self, textvariable=combo_var, values=item)
                combo.grid(row=len(self.rows) + 1, column=col, padx=1, pady=1)
                if self.lencolsizes > 0 and self.lencolsizes >= col+1:
                    combo.configure(width=self.colsizes[col])
                row.append(combo)
            else:
                label = ttk.Label(self, text=item)
                label.grid(row=len(self.rows) + 1, column=col, padx=1, pady=1)
                row.append(label)

        remove_button = tk.Button(
            self, text="Remove", command=lambda: self.remove(row, data))
        remove_button.grid(row=len(self.rows) + 1,
                           column=len(data)+1, padx=1, pady=1)
        row.append(remove_button)
        self.rows.append(row)
        self.rows_data.append(data)
        return row

    def get_vals(self):
        full_ret = []
        for r in self.rows:
            row_ret = []
            for col in r:
                if isinstance(col, ttk.Entry) or isinstance(col, ttk.Combobox):
                    row_ret.append(col.get())
                elif isinstance(col, ttk.Checkbutton):
                    row_ret.append(col.instate(['selected']))
                elif isinstance(col, ttk.Label):
                    row_ret.append(col.cget("text"))
            full_ret.append(row_ret)
        print(full_ret)
        return full_ret


if __name__ == "__main__":

    # Example usage
    root = tk.Tk()
    scroll_frame = ScrollableFrame(root)
    scroll_frame.pack(fill="both", expand=True)

    headers = ["Header 1", "2", "Header 3", "Another one"]
    table = TkVarTable(scroll_frame.scrollable_frame, headers, [0,10,5,10])

    row1_data = ["Fixed Text", tk.StringVar(), tk.BooleanVar(), [
        "Option 1", "Option 2", "Option 3"]]
    row2_data = ["Another Text", tk.StringVar(), tk.BooleanVar(), [
        "Choice 1", "Choice 2", "Choice 3"]]
    r = table.add_row(row1_data)

    combo = r[3]
    entry = r[1]

    def on_combo1_select(event):
        selected_option = combo.get()
        if selected_option == "Option 2":
            entry.configure(state="readonly")
        else:
            entry.configure(state="normal")
    combo.bind("<<ComboboxSelected>>", on_combo1_select)

    table.add_row(row2_data)

    tk.Button(root, text="Add", command=lambda: table.add_row(
        row1_data)).pack(pady=10, padx=10)
    
    tk.Button(root, text="Print vals", command=lambda: table.get_vals()).pack(pady=10, padx=10)

    table.pack(side="left")
    root.mainloop()
