# The purpose of this is only to write valid JSONs that LIVEMAP can read

import cisei_lib.cli.planner.PlanLib as pl
import os
import pandas as pd
import json
import globals as g
import wg_footer as footer
import wg_stringvar_from as svf
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import cisei_lib.cli.planner.DBWrapper as dbw
import cisei_lib.gui.tools.qol as q
import platform

# convert tags from str to dict
import ast


class WindowPinpointTag():

    def apply(self):
        str_tgs = ''
        if hasattr(self, "db_entry"):
            str_tgs = self.db_entry['tags']
            this_elm_tags = ast.literal_eval(str_tgs)

            if self.c1_var.get() == True:
                this_elm_tags['drop'] = True
            elif "drop" in this_elm_tags:
                del this_elm_tags['drop']
            str_tgs = str(this_elm_tags)
        else:
            messagebox.showerror("Save fail", f"No Database entry for element")

        with dbw.MySQL() as db:
            try:
                db.execute(
                    f"UPDATE poles SET tags = ? WHERE uid = ?;", vals=(str_tgs, self.uid))
            except Exception as e:
                messagebox.showerror(
                    "DB query fail", f"An error occurred:\n{e}")

    def fetch_db_info(self):
        with dbw.MySQL() as db:
            try:
                df = pd.read_sql(f"select * from poles where uid = '{self.uid}';",
                                 db.connection)
                if len(df) > 0:
                    self.db_entry = df.to_dict(orient='records')[
                        0]  # converts df to dict
            except Exception as e:
                messagebox.showerror(
                    "DB query fail", f"An error occurred:\n{e}")

    def load_data(self):
        self.sv_type.set(self.type)
        self.sv_uid.set(self.uid)
        self.sv_tags.set("Null")
        self.fetch_db_info()
        if hasattr(self, "db_entry"):
            str_tgs = self.db_entry['tags']
            self.sv_tags.set(str_tgs)
            this_elm_tags = ast.literal_eval(str_tgs)
            if "drop" in this_elm_tags:
                self.c1.select()
        print("loaded")

    def __init__(self, type, uid):
        

        self.window = tk.Toplevel()
        
        self.type = type
        self.uid = uid

        # footer
        footerdata = {
            "version": g.g_prog_version,
            "db": g.g_database_file
        }
        footer.FooterWidget(self.window, footerdata)

        self.window.minsize(400, 300)
        self.window.title(f"Pinpoint {self.uid} - {g.g_program_name}")

        # lbl_about = tk.Label(
        #     self.window, text="Here you can drop this element from planning.")
        # lbl_about.pack(anchor="w", padx=10, pady=2)

        center_frame = tk.LabelFrame(self.window, text="Element")
        center_frame.pack(side="top", padx=10, pady=10,
                          fill="both", expand=True)

        self.notebook = ttk.Notebook(center_frame)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)

        f1 = tk.Frame(self.notebook)  # json frame
        f1.pack(side="top", padx=10, pady=10, fill="both", expand=True)
        # f2 = tk.Frame(self.notebook)  # db frame
        # f2.pack(side="top", padx=10, pady=10, fill="both", expand=True)

        self.notebook.add(f1, text='General')
        # self.notebook.add(f2, text='Extra')

        self.c1_var = tk.BooleanVar()
        self.c1 = tk.Checkbutton(f1, text='DROP', variable=self.c1_var)
        self.c1.pack()
        q.Tooltip(
            self.c1, f"If you mark drop, and apply, this will add tag \"drop\" to this element. Next time you compile the project, this element wont be included for planning.")

        self.sv_type = tk.StringVar()
        self.sv_uid = tk.StringVar()
        self.sv_tags = tk.StringVar()
        form_params = [
            ("Type", "", self.sv_type),
            ("UID", "", self.sv_uid),
            ("TAGs", "", self.sv_tags)]
        self.form = svf.StringvarForm(f1, form_params, state="readonly")
        self.form.pack()
        self.load_data()

        bottom_frame = tk.Frame(f1, padx=10, pady=10)
        bottom_frame.pack(fill="x", side="bottom")
        self.form.pack()

        bt1 = tk.Button(bottom_frame, text="Apply", command=self.apply)
        bt1.pack(side="left", padx=10, pady=2)
        q.Tooltip(bt1, f"Apply the changes")

        bt2 = tk.Button(bottom_frame, text="Cancel", command=lambda: self.window.destroy())
        bt2.pack(side="left", padx=10, pady=2)
        q.Tooltip(bt2, f"Cancel operation")

        q.move_under_mouse(self.window)
        if platform.system() == 'Windows':
            self.window.wm_attributes('-topmost', 1)
        else:
            self.window.lift()
        # q.center_window(self.window)


if __name__ == "__main__":
    root = tk.Tk()

    obj = WindowPinpointTag(type="poles", uid="939334777")

    print("created window")
    root.mainloop()
