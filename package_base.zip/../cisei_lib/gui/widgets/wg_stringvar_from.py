import tkinter as tk
from collections import namedtuple
import cisei_lib.gui.tools.qol as q
class StringvarForm(tk.Frame):
    def __init__(self, master, entries=None, state="normal"):
        if entries == None:
            entries = [("String_Stringvar_Tuple",
                        tk.StringVar(value="StringVar"))]
        
        # define the length of left side (labels), by largest string
        largest_lbl_len = 0
        for etr in entries:
            ll = len(etr[0])
            if largest_lbl_len < ll:
                largest_lbl_len = ll 

        super().__init__(master)
        for nuple in entries:
            targ_fram = tk.Frame(master)
            targ_fram.pack(side=tk.TOP, anchor='w', padx=5, pady=1, fill="x")

            label = tk.Label(targ_fram, text=f"{nuple[0]}:", anchor='e', width=largest_lbl_len)
            label.grid(row=0, column=0, padx=5)

            wg_instnace = None
            if len(nuple) > 3:
                # print(nuple)
                entry_class = nuple[3]
                wg_instnace = entry_class(targ_fram, textvariable=nuple[2], valid_words=nuple[4])
            else:
                if isinstance(nuple[2], tk.StringVar): 
                    wg_instnace = tk.Entry(targ_fram, textvariable=nuple[2], state=state)
                elif isinstance(nuple[2], tk.BooleanVar): 
                    wg_instnace = tk.Checkbutton(targ_fram, text="", variable=nuple[2])
            if nuple[1] != "":
                q.Tooltip(wg_instnace,nuple[1])

            wg_instnace.grid(row=0, column=1, padx=5, sticky="ew")

