import tkinter as tk
from tkinter import ttk
import os
from tkinter import messagebox
import time
import pandas as pd
import tkinter.filedialog as filedialog
import wg_import_list as wil
import warnings
import wg_tkvar_table as tkvt
import wg_progressbar as wpb
import wg_simple_table as simpt
import wg_footer as footer
import wg_stringvar_from as svf
import cisei_lib.gui.tools.qol as q
import cisei_lib.cli.planner.CreateTables as ct
import cisei_lib.cli.planner.DataImporter as di
import cisei_lib.cli.planner.DBWrapper as dbw
import cisei_lib.globals as g


this_window_title = "Import"

import_types = ["cities", "pops", "towers",
                "dads", "poles", "meters"]  # aka tables
import_subtypes = ["MONO_2F", "MONO_3F", "BIFASICO",
                   "TRIFASICO", "TRI_IND", "TRI_30", "REMOTA"]
subtype_toggle = 'meters'
subentry_toggle = 'pops'

instructions = """RULES: CSV MUST BE IMPORTED FOLLOWING THIS ORDER:
    1)  cities: This table maps CODES TO city NAMES (OPTIONAL)
    2)  pops: MANDATORY (Notice you can also specify type on \"pop_type\" field)
    3)  towers (OPTIONAL)
    4)  poles: MANDATORY
    5)  all other tables: any order
"""


class APIImport():
    def fetch_proj_folder(self):
        pass

    def __init__(self):
        self.project_folder = ""
        self.fetch_proj_folder()


class WindowImport():

    def redraw_import(self, window, file_paths=[]):
        if file_paths == []:
            return
        for wid in window.winfo_children():  # clear
            wid.destroy()

    def check_init_db(self):
        def create_db():
            dbw.create_database(db_file=g.g_database_file)
            ct.createTables(db_file=g.g_database_file)
        if q.has_db_file() is not True:
            create_db()
            return
        # there might be a db file, but not tables... check one table
        with dbw.MySQL() as db:
            df = pd.read_sql(f"select name from sqlite_master where type='table' and name='projects';",
                             db.connection)
            rslen = len(df)
            if rslen == 0:
                create_db()

    def select_config_file(self):
        file = ""
        file = filedialog.askopenfilename(parent=self.window)
        if file != "":
            self.sv_conf_file.set(file)

    def open_file_dialog(self):
        files = filedialog.askopenfilenames(parent=self.window)
        if len(files) > 0:
            self.files = files
            self.table.clear_rows()
            for file in files:
                print(file)

                def add_row_behaviour(row):
                    combotable = row[1]
                    combotype = row[2]
                    entrypoptype = row[3]

                    def on_combo_select(event):
                        option = combotable.get()
                        entrypoptype.configure(
                            state="normal" if option == "pops" else "disabled")
                        combotype.configure(
                            state="readonly" if option == "meters" else "disabled")
                    combotable.bind("<<ComboboxSelected>>", on_combo_select)
                    combotype.configure(state="disabled")  # initial state
                    entrypoptype.configure(state="disabled")  # initial state

                rowdata = [tk.StringVar(
                    value=file), import_types, import_subtypes, tk.StringVar()]
                row = self.table.add_row(rowdata)
                add_row_behaviour(row)

    def start_import(self):
        def start_imp(pbq=None):
            if len(self.files) == 0:
                messagebox.showinfo(
                    "Attention", "You should select the files first.")
            else:
                wpb.do_if_has_pb(pbq, wpb.message, "Starting import")
                self.check_init_db()
                import_info_rows = self.table.get_vals()
                file_import_info = self.sv_info.get()
                try:
                    for filecount, elm in enumerate(import_info_rows):
                        # note name translation from here: type->type and subtype->type
                        filepath, table, metertype, poptype = elm[0], elm[1], elm[2], elm[3]
                        if table == "":
                            time.sleep(0.5)
                            raise Exception(
                                f"You must specify 'table' field for every CSV.. Missing infor for file #{filecount}")
                        file_name = os.path.basename(filepath)
                        directory = os.path.dirname(filepath)
                        wpb.do_if_has_pb(pbq, wpb.message,
                                         f"Importing {file_name}")
                        type = ""
                        if metertype != "" or poptype != "":
                            type = metertype if metertype != "" else poptype

                        if type == "" and table == 'meters':
                            wpb.do_if_has_pb(pbq, wpb.message, "Failed")
                            raise Exception(
                                f"You must fill type for #{filecount+1} '{file_name}'")

                        conf_file = self.sv_conf_file.get()
                        optargs = {}
                        if conf_file is not "":
                            optargs['config_file'] = conf_file

                        with di.DataImporter(db_file=g.g_database_file, csvdir=directory, **optargs) as d:
                            with warnings.catch_warnings(record=True) as w:

                                if type == "":
                                    d.import_csv(file_name, table,
                                                 file_import_info, pbq=pbq, **optargs)
                                else:
                                    d.import_csv(file_name, table,
                                                 file_import_info, type=type, pbq=pbq, **optargs)
                                for ww in w:
                                    print(ww.message.msg)
                                    print(ww.message.cat)
                                    print(ww.message.obj)
                    print("Import Success")
                except Exception as e:
                    messagebox.showerror("Import Error", f"{e}")
                    time.sleep(1)
                    return
                wpb.do_if_has_pb(pbq, wpb.message, "Finished")
                wpb.do_if_has_pb(pbq, wpb.progress, 100)
                time.sleep(1)
        pb = wpb.ProgressBarDiag(self.window, "Importing")
        pb.start_thread(targ=start_imp)

    def create(self, debug=False):
        footer.FooterWidget(self.window, {
            "version": g.g_prog_version,
            "db": g.g_database_file
        })

        if hasattr(self.window, "title"):
            self.window.minsize(630, 300)
            self.window.title(f"{this_window_title} - {g.g_program_name}")

        lbl_about = tk.Label(
            self.window, text=f"Import data from CSV's to database", justify='left')
        lbl_about.pack(anchor="w", padx=10, pady=2)

        center_frame = tk.LabelFrame(self.window, text="CSV")
        center_frame.pack(side="top", padx=10, pady=10,
                          fill="both", expand=True)

        textbox = tk.Text(center_frame, bg="#ffffe0", wrap="word")
        textbox.insert(tk.END, instructions)  # Insert new text
        textbox.config(height=len(instructions.splitlines()))
        textbox.pack(padx=10, pady=10, fill="both", side="top")

        f1 = tk.Frame(center_frame)
        f1.pack(side="top", padx=10, pady=10, fill="both", expand=True)

        frm_options = tk.Frame(f1)
        frm_options.pack(fill='x')

        self.sv_info = tk.StringVar()
        frm_impinfo = tk.Frame(frm_options)
        frm_impinfo.grid(row=0, column=0, sticky='w')

        form_params = [
            ("Import Info", "Import description for following files", self.sv_info)]
        self.form = svf.StringvarForm(frm_impinfo, form_params, state="normal")
        self.form.pack()

        # select import config
        self.sv_conf_file = tk.StringVar(value="")
        frm_conffile = tk.Frame(frm_options)
        frm_conffile.grid(row=0, column=1, sticky='w')
        lbl_cf = tk.Label(frm_conffile, text=f"Config file:", anchor='e')
        lbl_cf.grid(row=0, column=0, padx=0)
        entr_cf = tk.Entry(
            frm_conffile, textvariable=self.sv_conf_file, state='readonly')
        entr_cf.grid(row=0, column=1, padx=0)

        btn_cf_selec = tk.Button(
            frm_conffile, text="+", compound="left", command=self.select_config_file)
        q.Tooltip(btn_cf_selec, "Select a custom import configuration file")
        btn_cf_selec.grid(row=0, column=2, padx=0)
        # q.IconButtom(frm_conffile,
        #              text="",
        #              width=1,
        #              compound="left",
        #              image=g.g_img_searchfile,
        #              tooltip="Select a custom import configuration file",
        #              command=self.select_config_file).grid(row=0, column=2, padx=0)

        # list of files
        scroll_frame = tkvt.ScrollableFrame(f1)
        scroll_frame.pack(fill="both", expand=True)
        headers = ["File", "Table", "meter_type", "pop_type"]
        self.table = tkvt.TkVarTable(
            scroll_frame.scrollable_frame, headers, colsizes=[35, 5, 8, 12])
        self.table.pack(padx=10, pady=10)

        if debug is True:
            tk.Label(self.window, text="Debug").pack(padx=20, pady=20)
            main_opts = ["test1", "test2", "test3"]
            row1_data = ["Debug", tk.StringVar(), tk.BooleanVar(), [
                "Option 1", "Option 2", "Option 3"]]
            self.table.add_row(row1_data)
            for f in main_opts:
                row2_data = [f, tk.StringVar(), tk.BooleanVar(), [
                    "Choice 1", "Choice 2", "Choice 3"]]
                r = self.table.add_row(row2_data)

            add_row_button = ttk.Button(
                self.window, text="Add Row", command=lambda: self.table.add_row(row1_data))
            add_row_button2 = ttk.Button(
                self.window, text="Clear", command=lambda: self.table.clear_rows())
            add_row_button3 = ttk.Button(
                self.window, text="VALS", command=lambda: print(self.table.get_vals()))
            add_row_button.pack()
            add_row_button2.pack()
            add_row_button3.pack()

        bottom_frame = tk.Frame(f1, padx=10, pady=10)
        bottom_frame.pack(fill="x", side="bottom")

        bt2 = tk.Button(bottom_frame, text="Import",
                        bg=f"#{100:02x}{209:02x}{187:02x}",
                        command=self.start_import)
        bt2.pack(side="right", padx=10, pady=2)
        q.Tooltip(bt2, f"Start the import process for selected files")

        bt1 = tk.Button(bottom_frame, text="Select files",
                        bg=f"#{209:02x}{205:02x}{100:02x}",
                        command=self.open_file_dialog)
        bt1.pack(side="right", padx=10, pady=2)
        q.Tooltip(bt1, f"Select files to import to database")

        if hasattr(self.window, "title"):
            # q.center_window(self.window)
            self.window.protocol("WM_DELETE_WINDOW", self.on_close)
            q.center_to_parent(self.window, self.root)

    def __init__(self, root=None, debug=False):
        self.files = []
        try:
            self.window = tk.Toplevel()
            self.root = root

            self.window.focus_set()
            self.window.grab_set()  # Set the window as modal
            if self.root is not None:
                self.window.transient(self.root)

            self.api = APIImport()
            self.create(debug=debug)
        except Exception as e:
            messagebox.showerror(
                "Project Error", f"Project Window error:\n{e}")

    def on_close(self):
        self.window.grab_release()  # Release the modal state
        self.window.destroy()


if __name__ == "__main__":
    try:
        root = tk.Tk()
        WindowImport(root, debug=True)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("An error occurred", f"An error occurred:\n{e}")
