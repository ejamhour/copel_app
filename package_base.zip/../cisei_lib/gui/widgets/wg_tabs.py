import tkinter as tk
from tkinter import ttk

class MyNotebook:
    def __init__(self, master, tabs=None):
        self.tabs = tabs
        if self.tabs == None:
            frm1 = tk.Frame(master)
            lbl1 = tk.Label(frm1, "Helllo world")
            lbl1.pack()
            self.tabs = ("tab1", frm1)

        self.master = master
        self.create()

    def create(self):
        self.notebook = ttk.Notebook(self.master)
        self.notebook.pack(fill='both', expand=True)

        # Create two tabs
        tab1 = ttk.Frame(self.notebook)
        tab2 = ttk.Frame(self.notebook)

        # Add the tabs to the notebook
        for tab in self.tabs:
            self.notebook.add(tab, text='Tab 1')
            self.notebook.add(tab2, text='Tab 2')

        # Create a treeview widget in the first tab
        columns = ('Name', 'Age', 'Gender')
        self.treeview = ttk.Treeview(tab1, columns=columns, show='headings')
        self.treeview.pack(fill='both', expand=True)

        # Define column headings
        for col in columns:
            self.treeview.heading(col, text=col)

        # Insert data into the treeview
        data = [
            ('John', 25, 'Male'),
            ('Mary', 30, 'Female'),
            ('Bob', 18, 'Male'),
            ('Jane', 22, 'Female')
        ]
        for item in data:
            self.treeview.insert('', 'end', values=item)

        # Create a treeview widget in the second tab
        columns = ('Fruit', 'Quantity')
        self.treeview2 = ttk.Treeview(tab2, columns=columns, show='headings')
        self.treeview2.pack(fill='both', expand=True)

        # Define column headings
        for col in columns:
            self.treeview2.heading(col, text=col)

        # Insert data into the treeview
        data = [
            ('Apples', 10),
            ('Oranges', 20),
            ('Bananas', 15),
            ('Pears', 5)
        ]
        for item in data:
            self.treeview2.insert('', 'end', values=item)

if __name__ == '__main__':
    root = tk.Tk()
    app = MyNotebook(root)
    root.mainloop()