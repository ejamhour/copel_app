import tkinter as tk
import cisei_lib.globals as g
import cisei_lib.gui.tools.qol as q
from tkinter import messagebox
import json
import pandas as pd
import wg_progressbar as wpb
import wg_simple_table as simpt
import wg_suggest_entry as sg
import wg_stringvar_from as svf
import wg_footer as footer
import cisei_lib.cli.planner.PlanLib as pl
import cisei_lib.cli.planner.DBWrapper as dbw

class APINewProject():
    def __init__(self):
        self.ret = None # stores newly created project id

    def _gen_pdl(self):
        # about overwrite TODO, check if already exists as for use before hand about it.
        pdl_out = {
            "project": {
                "name": self.name,
                "overwrite": True,
                "description": self.desc,
                "radiomodel": "defaultmodel.json"
            },
            "city": self.city,
            "add pops": [{}
                         ],
            "add dads": [{}
                         ],
            "add towers": [{}
                           ],
            "add meters": [{}
                           ],
            "add poles": [{}
                          ],
            "drop poles": [
                {"tag_drop": True}
            ]
        }
        strjson = json.dumps(pdl_out, indent=4)
        out_fipath = f"{g.g_workdir}/{g.g_projects_folder}/{q.sanitize_string_for_filename(self.name)}.json"
        with open(out_fipath, "w", encoding="UTF-8") as f:
            f.write(strjson)
        return out_fipath

    def get_cities(self):
        ret = []
        with dbw.MySQL() as db:
            df = pd.read_sql(f"select distinct(city_name) from pops;",
                             db.connection)
            rslen = len(df)
            if rslen > 0:
                ret = df['city_name'].tolist()
        return ret

    def _compile(self, pdl_path):
        with pl.PlanLib(db_file=g.g_database_file) as p:
            with open(pdl_path) as f:
                try:
                    p.compilePDL(f, save=True)
                except Exception as e:
                    messagebox.showerror(
                        "Create fail", f"An error occurred while attempting compile project:\n{e}")

    def gen_project(self, name, desc, city, cb_dads, cb_meters, cb_towers):
        self.name = name
        self.desc = desc
        self.city = city
        self.cb_dads = cb_dads
        self.cb_meters = cb_meters
        self.cb_towers = cb_towers
        # check if entries filled
        required_fields = ['name', 'desc', 'city']
        if all(getattr(self, field) != "" for field in required_fields):
            pass
        else:
            missing_fields = [
                field for field in required_fields if getattr(self, field) == ""]
            error_message = f"Error: Missing fields {missing_fields}"
            print(error_message)
            messagebox.showerror(
                "Missing input", f"Please, complete the fields {missing_fields}")
            return missing_fields
        # -------------------------------

        # validate checkboxes
        if self.cb_dads is False and self.cb_meters is False:
            messagebox.showerror(
                "Type of plan", f"Either DADs, Meters, or both must be selected. Selecting neither option is not supported.")
            return

        self.pdl_path = self._gen_pdl()
        smsg = f"PDL generated at: {self.pdl_path}"
        print(smsg)

        try:
            self._compile(self.pdl_path)
        except Exception as e:
            messagebox.showerror("Compile fail", f"An error occurred:\n{e}")

        # attempt to get the id of newly created project
        with dbw.MySQL() as db:
            df = pd.read_sql(f"select id from projects where name = '{self.name}';",
                             db.connection)
            rslen = len(df)
            if rslen > 0:
                ret = df['id'].tolist()
                retint = int(ret[0])
                return retint
        return None


class WindowNewProject(tk.Toplevel):
    def __init__(self, root=None):
        self.root = root
        super().__init__()
        if q.has_db_file() is not True:
            messagebox.showerror(
                "No database", "You can't create a new project before importing data")
            return

        self.api = APINewProject()
        self.create()

    def _call_gen_proj(self):
        def thre(pbq=None):
            wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
            wpb.do_if_has_pb(pbq, wpb.message, "Compiling... standby")
           
            self.ret = self.api.gen_project(self.sv_name.get(),
                                self.sv_desc.get(), self.sv_city.get(), self.bv_dad.get(), self.bv_meter.get(), self.bv_tower.get())
            if self.ret == None:
                return # prevent closing, user might filled form wrong
            self.close()
            
        pb = wpb.ProgressBarDiag(self, "Creating project")
        pb.start_thread(thre)

        
    def close(self):
        self.grab_release()  # Set the window as modal
        self.destroy()
        return

    def create(self):

        self.focus_set()
        self.grab_set()  # Set the window as modal
        if self.root is not None:
            self.transient(self.root)
            # Disable close button
            self.protocol("WM_DELETE_WINDOW", self.close)

        # footer
        footerdata = {
            "version": g.g_prog_version
        }
        footer.FooterWidget(self, footerdata)

        self.minsize(370, 300)
        self.title(f"New Project - {g.g_program_name}")

        lbl_about = tk.Label(self, text="Create a new project")
        lbl_about.pack(anchor="w", padx=10, pady=2)

        center_frame = tk.LabelFrame(self, text="Project information")
        center_frame.pack(side="top", padx=10, pady=10,
                          fill="both", expand=True)

        self.sv_name = tk.StringVar()
        self.sv_desc = tk.StringVar()
        self.sv_city = tk.StringVar()
        self.bv_dad = tk.BooleanVar()
        self.bv_meter = tk.BooleanVar()
        self.bv_tower = tk.BooleanVar()

        self.valid_cities = self.api.get_cities()
        form_params = [
            ("Name", "", self.sv_name),
            ("Description", "", self.sv_desc),
            ("City", "", self.sv_city, sg.SuggestEntry, self.valid_cities),
            ("DADs", "Include DADs in this project", self.bv_dad),
            ("Meters", "Include meters in this project", self.bv_meter),
            ("Towers", "Include towers in this project", self.bv_tower)]
        form = svf.StringvarForm(center_frame, form_params)
        form.pack()

        # def tooltip_cb_text(
        #     asset): return f"Include {asset} into the new project"
        # q.Tooltip(self.cb_dad, tooltip_cb_text("DADs"))
        # q.Tooltip(self.cb_meter, tooltip_cb_text("Meters"))
        # q.Tooltip(self.cb_tower, tooltip_cb_text("Towers"))

        bottom_frame = tk.Frame(center_frame, padx=10, pady=10)
        bottom_frame.pack(fill="x", side="bottom")

        bt1 = tk.Button(bottom_frame, text="Create",
                        command=self._call_gen_proj)
        bt1.bind('<Return>', lambda event: self._call_gen_proj()) # qol

        bt1.pack(side="right", padx=2, pady=2)
        q.Tooltip(bt1, "Create the project")

        bt1 = tk.Button(bottom_frame, text="Cancel", command=self.close)
        bt1.pack(side="right", padx=2, pady=2)
        q.Tooltip(bt1, "Cancel and close")

        if self.root is not None:
            # q.center_window(window)
            q.center_to_parent(self, self.root)


if __name__ == "__main__":
    try:
        root = tk.Tk()
        WindowNewProject()
        root.mainloop()
    except Exception as e:
        messagebox.showerror("An error occurred", f"An error occurred:\n{e}")
