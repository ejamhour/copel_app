import tkinter as tk
from tkinter import ttk
import threading
import time
import queue
from tkinter import messagebox
import numpy as np
import cisei_lib.gui.tools.qol as q
import wg_logbox as wglb
import cisei_lib.gui.tools.tailer as tlr
import platform

# when calling a function with this widget, it adds a kwarg 'pbq' that allows you to send
# information for the progressbar window to display, look at the example below in __main__


class ProgressBarDiag(tk.Toplevel):
    def __init__(self, root=None, title="Progress Bar Example", tail_file="", topmost=False, log_cb_func=None, log_cb_params=None):
        self.title_text = title

        super().__init__()
        self.root = root
        self.queue = queue.Queue(maxsize=100)
        # self.root = root
        self.title(self.title_text)
        self.minsize(280, 100)
        
        self.sv_lbl = tk.StringVar()
        self.label = tk.Label(self, textvariable=self.sv_lbl)
        self.label.pack(side="top", pady=10, padx=10)

        # since we can hide/show with pack_forget we have a frame to save the place of pb
        self.pbframe = ttk.Frame(self)
        self.pbframe.pack()
        self.progressbar = ttk.Progressbar(
            self.pbframe, orient=tk.HORIZONTAL, length=300, mode='determinate')
        self.progressbar.pack(pady=10, padx=10)

        # logbox
        self.lboxframe = ttk.Frame(self)
        self.lboxframe.pack(padx=10, pady=10)
        self.logbox = wglb.Logbox(self.lboxframe)
        self.logqueue = self.logbox.get_queue()

        self.tailer = None
        if (tail_file != ""):
            self.tailer = tlr.LogFileTailer(tail_file)

        self.log_cb_func = log_cb_func # cb func that gets called every time a msg log is queued
        self.log_cb_params = log_cb_params

        self.update_idletasks()
        self.grab_set()  # Set the window as modal
        self.focus_set()

        if topmost:
            self.wm_attributes('-topmost', 1)

        closeinfo = "This process is not supposed to be stopped mid-execution\nYou will have to wait until it finishes."
        self.protocol("WM_DELETE_WINDOW", lambda: messagebox.showinfo(
            "Note", closeinfo))  # Disable close button

    def get_queue(self):
        return self.queue

    def queue_check_thread(self):
        

        # self.attributes("-topmost", True)
        while self.thread.is_alive():

            # check main queue for pb ----------------------
            while True:
                try: 
                    v = self.queue.get(timeout=0.1)
                    # print(v)
                    if 'p' in v:
                        self.progressbar['value'] = v['p']
                        self.title(f"({v['p']}%) {self.title_text}")
                    if 'm' in v:
                        self.sv_lbl.set(v['m'])
                    if 'ml' in v: # manual TODO: FIXME: this is duplicated (see below) and looks like not used!
                        self.logqueue.put({"m": v['ml']['m'], "l": v['ml']['l']})
                    if 'vb' in v:
                        if v['vb'] == True:
                            self.progressbar.pack(pady=10, padx=10)
                        else:
                            self.progressbar.pack_forget()
                    if 'vlb' in v:
                        if v['vlb'] == True:
                                self.logbox.pack(pady=10, padx=10)
                        if v['rct'] == True: # User might want to recenter when performing dialogbox show/hide
                                self.update_idletasks()
                                q.center_to_parent(self, self.root)
                        else:
                            self.logbox.pack_forget()
                except Exception as exq:
                    # print("queue check to too fast")
                    break  # ignore, problem on get  usually because empty, harmless
            
            # check second queue for file tailer ----------------------
            if self.tailer is not None:
                while True:
                    try:
                        v = self.tailer.log_queue.get(timeout=0.1)
                        self.logqueue.put({"m": v, "l": 'SUCCESS'})
                        if self.log_cb_func is not None:
                            self.log_cb_func(v, self.log_cb_params)
                    except Exception as exq:
                        break  # ignore, problem on get  usually because empty, harmless
            self.update()

        print("Thread finished, nothing to watch")

        if self.tailer is not None:
            self.tailer.stop()
            print("Stop log file tail")

        self.grab_release()  # Release the modal state
        self.destroy()

    def start_thread(self, targ, args=(), **kwargs):
        if self.root is not None:
            self.transient(self.root)
            q.center_to_parent(self, self.root)

        try:
            pass_kwargs = {'pbq': self.queue}
            if len(kwargs) > 0:
                pass_kwargs = {**kwargs, **pass_kwargs}
            if args is not None:
                self.thread = threading.Thread(
                    target=targ, args=args, kwargs=pass_kwargs)
            self.thread.start()
            
            if self.tailer is not None:
                self.tailer.start()

        except Exception as ex:
            messagebox.showerror(
                "PBAR Error", "Your function isn't compatbile\n{ex}")
        
        self.queuethread = threading.Thread(target=self.queue_check_thread)
        self.queuethread.start()

# here are some helpers you might find usefull


def progress(queue, prog):
    obj = {}
    obj['p'] = int(prog)
    queue.put(obj)


def message(queue, msg):
    obj = {}
    obj['m'] = str(msg)
    queue.put(obj)

def log(queue, msg, level='DEBUG'):
    obj = {
        'ml': {}
    }
    obj['ml']['m'] = str(msg)
    obj['ml']['l'] = str(level)
    queue.put(obj)


def visible_bar(queue, visible):
    obj = {}
    obj['vb'] = bool(visible)
    queue.put(obj)


def visible_logbox(queue, visible, recenter=False):
    obj = {}
    obj['vlb'] = bool(visible)
    obj['rct'] = bool(recenter)
    queue.put(obj)


def lazy_prog_lerp(start, end, interval):
    delta = (end - start)
    return int(start + (delta * interval))


def do_if_has_pb(queue, methode, *args):
    if queue is not None:
        methode(queue, *args)

# you might wnat to use a timer, in order to not update the pb too much and wast time
# with ui rather than actual processing of data
# This class also allows you to estimate progress, you need to inform the progress on
# has_elapsed for it to be able to calculate it for you


class PBTimer:  # helps check interval with minum possible lines for programmer
    def __init__(self, interval):
        self.interval = interval
        self.start_time = time.time()

        # time estimation
        self.last_progress = 0.0
        self.remaining_time = 0
        self.remaining_str = "..."

        self.times_size = 10  # hardcode teh size of records you want to keep
        self.times_head = 0
        self.times = []

        for i in range(self.times_size):
            self.times.append(0.0)

    def elapsed(self):
        return time.time() - self.start_time

    def save_time(self, time):
        self.times[self.times_head] = time
        self.times_head += 1
        if self.times_head >= self.times_size:  # circular
            self.times_head = 0

    def times_mean(self):
        non_zero_arr = []
        for element in self.times:
            if element != 0:
                non_zero_arr.append(element)

        mean_nonzero = np.mean(non_zero_arr)
        return mean_nonzero

    def has_elapsed(self, progress=None):
        if self.elapsed() >= self.interval:
            self.reset()
            if progress is not None and progress > 0.0:
                if self.last_progress is not 0.0:
                    remaining_progress = 1.0 - progress
                    den = (progress - self.last_progress)
                    self.remaining_time = self.interval / den * remaining_progress
                    # print(self.remaining_time)
                    if self.remaining_time > 3600:
                        self.save_time(self.remaining_time)
                        self.format_time(self.times_mean())
                    else:
                        self.format_time(self.remaining_time)
                self.last_progress = progress

            return True
        return False

    def reset(self):
        self.start_time = time.time()

    def format_time(self, seconds):
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        time_string = ""
        if hours > 0:
            time_string += f"{round(hours)} hour{'s' if hours != 1 else ''}, "
        if minutes > 0:
            time_string += f"{round(minutes)} minute{'s' if minutes != 1 else ''}, "
        time_string += f"{round(seconds)} second{'s' if seconds != 1 else ''}"
        self.remaining_str = time_string

    def eta(self):
        return self.remaining_str


if __name__ == '__main__':
    root = tk.Tk()

    # you must add 'pbq' kwarg so it does not break, and allow you to update progressbar
    def somefunc(param1, param2, pbq=None, testkwarg=None):
        print("testkwarg ", testkwarg)

        print(f"param1 {param1}")
        print(f"param2 {param2}")
        tmr = PBTimer(0.5)
        for i in range(100):
            if tmr.has_elapsed(i/100):
                progress(pbq, i)
                message(pbq, f"loading {i} ({tmr.eta()})")
                log(pbq,f'{i}', 'DEBUG')
            time.sleep(0.15)
        log(pbq,'TASK ENDED. closing in 2 secs', 'SUCCESS')
        time.sleep(1.5)
        visible_logbox(pbq, False)
        time.sleep(0.5)
        print("finish")

    def start():
        try:
            prg = ProgressBarDiag(root=root, title="Test", tail_file='./somefiletailtest.txt')
            prg.start_thread(somefunc, ("pa1", "pa2"), testkwarg="123123")
            visible_logbox(prg.queue, True)
        except Exception as ex:
            messagebox.showerror("Error", f"{ex}")

    start_button = ttk.Button(root, text="Start", command=start)
    start_button.pack(pady=10)

    root.mainloop()
