import tkinter as tk
import tkinter.ttk as ttk

class FooterWidget(ttk.Frame):
    def __init__(self, master, data):
        super().__init__(master)
        self.data = data
        footerframe = ttk.Frame(self, relief='ridge', borderwidth=2)
        footerframe.pack(fill='x', padx=0, pady=0)
        for key, value in self.data.items():
            if isinstance(value, str):

                frame = ttk.Frame(footerframe, relief='sunken', borderwidth=1)
                frame.pack(side='left', padx=0, pady=0, anchor='e')
                
                # key_label = ttk.Label(frame, text=key, font=('TkDefaultFont', 9))
                key_label = ttk.Label(frame, text=f"{key}:", font=('TkDefaultFont', 9))
                key_label.pack(side='left', padx=2, pady=2)
                
                value_label = ttk.Label(frame, text=value, font=('TkDefaultFont', 9))
                value_label.pack(side='left', padx=2, pady=2)
        self.pack(side='bottom', fill='x')
        

if __name__ == '__main__':
    root = tk.Tk()
    root.title('Footer Widget Example')
    root.geometry('400x400')
    root.data = {'Author': 'John Doe', 'Version': '1.0', 'Description': 'Example Application'}
    root.footer = FooterWidget(root, root.data)
    root.mainloop()