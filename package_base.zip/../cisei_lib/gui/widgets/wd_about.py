
import tkinter as tk
import cisei_lib.globals as g
import cisei_lib.gui.tools.qol as q

class AboutWindow:
    def __init__(self, root=None):
        self.window = tk.Toplevel()
        
        self.window.focus_set()
        self.window.grab_set()  # Set the window as modal
        self.window.transient(root)
        def close():
            self.window.grab_release
            self.window.destroy()
        self.window.protocol("WM_DELETE_WINDOW", lambda: close())  # Disable close button
        text = tk.Label(master=self.window, text=g.g_about,
                        pady=10, wraplength=320)
        text.pack(padx=30, pady=30, anchor="center")
        if hasattr(self.window, 'title'):
            self.window.minsize(370, 300)
            # q.center_window(self.window)
            if root is not None:
                q.center_to_parent(self.window, root)

if __name__ == "__main__":
    # create root window
    root = tk.Tk()
    AboutWindow(root)
    root.mainloop()