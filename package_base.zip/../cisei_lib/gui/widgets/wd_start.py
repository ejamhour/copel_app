import tkinter as tk
import globals as g
import wg_simple_table as simpt
import cisei_lib.gui.tools.qol as q
import cisei_lib.gui.tools.ui_splash as splash
import wg_footer as footer
import time
import os
from tkinter import messagebox
import wd_new_proj as wnp
import wd_project as wp

class WindowStart():
    def call_new_proje(self):
        wnp.WindowNewProject()

    def call_project(self, sel_item):
        values = self.proj_table.item(sel_item)["values"]
        # print(values[0])
        proj_num = int(values[0].split("_")[1])
        print(proj_num)
        wp.WindowProject(tk.Toplevel(),proj_num)

    def __init__(self):
        # ss = splash.SplashScreen(timer_ms=1100)
        # time.sleep(0.8)

        root = tk.Toplevel()
        root.minsize(400, 400)
        root.title(f"Welcome - {g.g_program_name}")

        button_frame = tk.Frame(root, padx=10, pady=10)
        button_frame.pack(side="top", fill="x")

        bt1 = tk.Button(button_frame, text="New", command=self.call_new_proje)
        bt1.pack(side="left", padx=2, pady=2)
        q.Tooltip(bt1, "Create a new project")

        bt2 = tk.Button(button_frame, text="Find", state="disabled")
        bt2.pack(side="left", padx=2, pady=2)
        q.Tooltip(bt2,
                "Find a folder that contains the project (WIP)")

        frm_recent = tk.LabelFrame(root, text="Recent")
        frm_recent.pack(side="top", padx=10, pady=10, fill="both", expand=True)

        # get list of projects
        def get_projs():
            projs = os.listdir("./PROJECTS")
            projs = [proj for proj in projs if proj.startswith("PROJECT_")]
            return projs
        
        prjcts = get_projs()
        columns = ["Project"]
        
        self.proj_tuples = [(prj,) for prj in prjcts] 
        table = simpt.TableWidget(frm_recent, columns, self.proj_tuples, self.call_project)
        self.proj_table = table
        table.pack(fill="both", padx=10, pady=5, expand=True)
        recent_button = tk.Button(frm_recent, text="Open")
        q.Tooltip(recent_button,
                "Click here to open selected project (from recents), or double click one from the list.")
        recent_button.pack(padx=10, pady=5, anchor='w')

        footerdata = {
            "version": g.g_prog_version,
            "db": g.g_database_file
        }
        footer.FooterWidget(root, footerdata)
        
        q.center_window(root)

if __name__ == "__main__":
    try:
        root = tk.Tk()
        WindowStart()
        root.mainloop()
    except Exception as e:
        messagebox.showerror("An error occurred", f"An error occurred:\n{e}")
