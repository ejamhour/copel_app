import tkinter as tk
from tkinter import ttk
import cisei_lib.gui.tools.qol as q

class ImportList:
    def __init__(self, parent, opt=["UNDEFINED"], subopt=["UNDEFINED"], submenu_toggle_val=None, subentry_toggle_val=None):
        self.parent = parent
        self.rows = []
        self.submenu_toggle_val = submenu_toggle_val
        self.subentry_toggle_val = subentry_toggle_val
        self.opt=opt
        self.subopt = subopt
        # Scrollable frame
        self.canvas = tk.Canvas(self.parent)
        self.scrollbar = ttk.Scrollbar(
            self.parent, orient="vertical", command=self.canvas.yview)
        self.frame = ttk.Frame(self.canvas)

        self.frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(
                scrollregion=self.canvas.bbox("all")
            )
        )

        self.canvas.create_window((0, 0), window=self.frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

    def add_row(self, text):
        row = Row(self.frame, self.remove_row, text, self.opt, self.subopt, self.submenu_toggle_val, self.subentry_toggle_val)
        self.rows.append(row)
        row.pack()

    def remove_row(self, row):
        print(f"Removing {row.get_row_vals()}")
        self.rows.remove(row)
        row.destroy()

    def clear_rows(self):
        for row in self.rows:
            row.destroy()
        self.rows.clear()

    def get_vals(self):
        ret = []
        for row in self.rows:
            ret.append(row.get_row_vals())
        return ret


class Row(ttk.Frame):
    def __init__(self, parent, remove_callback, text="UNDEFINED", opt=None, subopt=None, submenu_toggle_val=None, subentry_toggle_val=None):
        super().__init__(parent)
        self.opt = opt
        self.subopt = subopt
        self.submenu_toggle_val = submenu_toggle_val
        self.subentry_toggle_val = subentry_toggle_val
        self.text = text
        self.remove_callback = remove_callback
        self.sv_subentry = tk.StringVar()

        self.text_entry = ttk.Entry(self)
        self.text_entry.insert(0, text)
        self.text_entry.configure(state="readonly")
        self.text_entry.pack(side="left")

        self.combo1 = ttk.Combobox(self, values=self.opt, state="readonly", width=8)
        self.combo1.bind("<<ComboboxSelected>>", self.on_combo1_select)
        self.combo1.pack(side="left")

        if self.submenu_toggle_val is not None:
            self.combo2 = ttk.Combobox(
                self, values=self.subopt, state="disabled", width=8)
            self.combo2.pack(side="left")
        if self.subentry_toggle_val:
            self.text_entry2 = ttk.Entry(self, textvariable=self.sv_subentry)
            self.text_entry2.pack(side="left")
            self.text_entry2.configure(state="disabled")

        self.remove_button = tk.Button(
            self, text="Remove", command=self.remove)
        self.remove_button.pack(side="left")
        # q.Tooltip(self.remove_button,"Remove from list")

    def on_combo1_select(self, event): # TODO: make this class more generic
        if self.submenu_toggle_val is not None:
            selected_option = self.combo1.get()
            if selected_option == self.submenu_toggle_val:
                self.combo2.configure(state="readonly")
            else:
                self.combo2.configure(state="disabled")
            if selected_option == self.subentry_toggle_val:
                self.text_entry2.configure(state="enabled")
            else:
                self.text_entry2.configure(state="disabled") 

    def remove(self):
        self.remove_callback(self)

    def destroy(self):
        super().destroy()

    def get_row_vals(self):
        return [self.text, self.combo1.current(), self.combo2.current(), self.sv_subentry.get()]


if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("510x300")
    root.title = "Someform"

    opt = ["Type 1", "Type 2", "Type 3"]
    sub_opt = ["Sub-Type 1", "Sub-Type 2", "Sub-Type 3"]

    app = ImportList(root, opt, sub_opt, "Type 2", "Type 3")

    main_opts = ["apple", "banana", "Grape"]

    for f in main_opts:
        app.add_row(f)

    # Add row button
    add_row_button = ttk.Button(
        root, text="Add Row", command=lambda: app.add_row("Added"))
    add_row_button2 = ttk.Button(
        root, text="Clear", command=lambda: app.clear_rows())
    add_row_button3 = ttk.Button(
        root, text="VALS", command=lambda: print(app.get_vals()))
    add_row_button.pack()
    add_row_button2.pack()
    add_row_button3.pack()

    root.mainloop()
