from pyzabbix.api import ZabbixAPI
from datetime import datetime, timedelta
import re
import plotLib

# CTRL + K ALT + W
#host:key.func(param)

def toTimeStamp(**args):
    etime  = datetime.fromisoformat(args['to']) if 'to' in args.keys() else datetime.now()
    itime = etime - timedelta(hours=args.get('hours', 1)) 
    print(itime, etime)
    return int(datetime.timestamp(itime)), int(datetime.timestamp(etime))

class MyZabbix:
    def __init__(self):
        self.conn = ZabbixAPI(url='https://monitoramento.hexing.com.br/zabbix', user='ejamhour', password='INTJ@Copel#2022')
        #self.conn = ZabbixAPI('https://monitoramento.hexing.com.br/zabbix')
        #self.conn.login('ejamhour','INTJ@Copel#2022')
    
    def __enter__(self):
        return self
    
    def __exit__(self, ext_type, exc_value, traceback):
        self.conn.user.logout()

    # Find hostid corresponding to name 
    def hostID(self, name):
        res = self.conn.do_request( 'host.get', {'filter': {'name':name}, 'output':['hostid']} )     
        try:
            hostid = res['result'][0]['hostid']
        except:
            hostid = None
        return hostid  

    # Find itemid corresponding to hostid and item name (used for history and trend)
    def itemID(self, hostid, name):
        try:
            res = self.conn.do_request( 'item.get', {'filter': {'hostid': hostid , 'name': name}, 'output': ['key_']} )
            res = res['result'][0]
            res = res['itemid']
        except Exception as e:
            print(e)
            res = None
        return res

    # Get host inventory from name
    # Returns a dictionary with keys hostid and inventory
    def hostInventory(self, name, **args):
        itens = args.get('items', ['location_lat', 'location_lon'])
        try:
            res = self.conn.do_request( 'host.get', {'filter': {'name': name }, 'selectInventory':itens, 'output':'inventory'} )
            res = res['result']
            res =  res[0] if len(res) > 0 else {'hostid': None,'invetory': None}
        except Exception as e:
            print(e)
        return res

    # Get host groups and other information from name
    # Use args as boolean vars to control the return (items, groups, inventory, interfaces, output)
    # Returns a dictionary where the keys are the elements above
    def getHost(self, name, **args):
        try:
            dic = {'filter': {'name': name } }
            if args.get('items', False) : 
                dic['selectItems'] = ['name', 'itemid', 'key_']
            if args.get('groups',False) :
                dic['selectGroups'] = ['groupid','name']
            if args.get('inventory',True) :
                dic['selectInventory'] = ['location_lat', 'location_lon', 'host_router']
            if args.get('interfaces', True):
                dic['selectInterfaces'] = ['ip','port']
            if args.get('output', True):
                dic['output'] = ['host','hostid','name','description']

            res = self.conn.do_request( 'host.get', dic )
            res = res['result'][0]
        except Exception as e:
            print(e)
            res = None
        return res

    # Search host by wildcards
    # Returns a dictionary hostid = [HOST NAME, DESCRIPTION ]
    def searchHost(self, name):
        try:
            res = self.conn.do_request( 'host.get', {'search': {'name':name}, 'searchWildcardsEnabled':1, 'output':['name','hostid','description']} )
            res = res['result']
            data = {}
            for r in res:
                data[ r['hostid'] ] = [ r['name'], r['description'] ] 
        except Exception as e:
            print(e)
            data = None

        return data

    # Get itens from hostid. Itens are specified as items=[list of item names] and output=[list of item attributes ]
    # Return a dictionary with itemid and list specified in output
    def getItem(self, hostid, **args):
        info = args.get('items', ['Down Stream Avg LQI', 'Down Stream Avg RSSI', 'Down Stream Avg SNR'])
        output = args.get('output', ['hostid', 'name','lastvalue'])
        try:
            res = self.conn.do_request( 'item.get', {'filter': {'hostid': hostid , 'name': info}, 'output':output} )
            res = res['result']
        except Exception as e:
            print('Error:', e)
            res = None
        return res
 
    # Get topology info for a list of hosts
    def getTopology(self, host, **args):
        info = ['Name', 'GE Network Name', 'GE Device Mode', 'Nic ID', 'Gateway ID', 'Route', 'Connected Radios']  
        output = ['hostid', 'name', 'lastvalue']  
        try:
            if args.get('byID', False):
                res = self.conn.do_request( 'item.get', {'filter': {'hostid': host , 'name': info}, 'output':output} )
            else:
                res = self.conn.do_request( 'item.get', {'filter': {'host': host , 'name': info}, 'output':output} )
            res = res['result']
            data = {}
            for r in res:
                if r['hostid'] not in data.keys(): data[r['hostid']] = {}
                data[r['hostid']][r['name']] = r['lastvalue']

        except Exception as e:
            print(e)
            data = None
        return data

    # Get link quality info
    def getInfo(self, host, **args):
        info = args.get('info', ['Down Stream Avg LQI', 'Down Stream Avg RSSI', 'Down Stream Avg SNR', 'Rx Packets', 'Tx Packets'])
        output = ['hostid', 'name', 'lastvalue']  
        try:
            if args.get('byID', False):
                res = self.conn.do_request( 'item.get', {'filter': {'hostid': host , 'name': info}, 'output':output} )
            else:
                res = self.conn.do_request( 'item.get', {'filter': {'host': host , 'name': info}, 'output':output} )
            res = res['result']
            data = {}
            for r in res:
                if r['hostid'] not in data.keys(): data[r['hostid']] = {}
                data[r['hostid']][r['name']] = r['lastvalue']

        except Exception as e:
            print(e)
            data = None
        return data

    # Get all hosts in a group name
    def hostIDByGroup(self, name):
        try:
            res = self.conn.do_request( 'hostgroup.get', {'filter': {'name':name}} )
            gid = res['result'][0]['groupid']
            data = self.conn.do_request( 'host.get', {'groupids':gid, 'selectGroups':'extend', 'output':['hostid']} )
            res = [ d['hostid'] for d in data['result']]
        except Exception as e:
            print(e)
            res = None
        return res

    # Get item hystory - default mode retries only last entry in text
    # history: 0=float, 1=character, 2=log, 3=uint, 4=text
    def getHistory(self, itemid, **args): 

        limit = args.get('limit', 1)
        history = args.get('history', 4)
 
        try:
            if args.get('latest', True):
                res = self.conn.do_request( 'history.get', {'itemids': itemid, 'history': history, "sortfield": "clock", "sortorder": "DESC", 'limit': limit } )
            else:
                itime, etime = toTimeStamp(**args)
                print(itime,etime)
                res = self.conn.do_request( 'history.get', {'itemids': itemid, 'history': history, "sortfield": "clock", "sortorder": "DESC", 'time_from' : itime, 'time_till' : etime } )
            
            res = res['result']

            dates = []
            values = []
        
            for i in res:
                for k,v in i.items():
                    if k =='clock': dates.append((datetime.fromtimestamp(int(v))))
                    elif k == 'value': values.append(v)

            return dates, values
        
        except Exception as e:
            print(e)
            return None

    # Get item trend
    def getTrend(self, itemid, **args):  

        itime, etime = toTimeStamp(**args)

        try:
            res = z.conn.do_request( 'trend.get', {'itemids': itemid, 'time_from' : itime, 'time_till' : etime} )
            res = res['result']
        
            dates = []
            values = []
        
            for i in res:
                for k,v in i.items():
                    if k =='clock': dates.append((datetime.fromtimestamp(int(v))))
                    if k == 'value_avg' or k=='value': values.append(float(v))

            return dates, values
        
        except Exception as e:
            print(e)
            return None

class HLZabbix(MyZabbix):

    def demo(self, host):
        hid = self.hostID(host)
        print('hid=',hid)
        print(self.hostInventory(host))
        res = self.getHost(host, items=False, groups=True, output=True, inventory=True, interfaces=True)  
        for k,v in res.items() : print(k,'=',v)
        print(self.searchHost("*MRO-S-P*"))
        print(self.getItem(hid, items='In Unicast Pkts'))
        iid = self.itemID(hid, 'Last Rx packet Last Lqi')
        res = self.getHistory(iid)
        plotLib.datePlot(res[0], res[1])
        res = self.getTrend(iid)
        plotLib.datePlot(res[0], res[1])
        iid = self.itemID(hid, 'Rx Packets')
        print(self.getTrend(iid, hours=24*30*6))

    def getGEMonitor(self, host, **args):

        fields = args.get('fields', ['mac-addr','ip-address','nic-id','name','alarmed','down-stream-avg-rssi','down-stream-avg-lqi','routes'])
        hid = self.hostID(host)
        iid = self.itemID(hid, 'Ge Connected Remotes')
        res = self.getHistory(iid, limit=1, history=4)
        mon = eval(res[1][0])
        resdic = { k : mon.get(k,None) for k in fields}
        resdic['date'] = res[0][0].isoformat()
        return resdic 

    def getWSMonitor(self, host, **args):

        fields = args.get('fields', ['mac-addr','ip-address','remote-address','name','tx-packets','rx-packets','tx-error','rx-error'])
        hid = self.hostID(host)
        iid = self.itemID(hid, 'Ge Endpoints')
        res = self.getHistory(iid, limit=1, history=4)
        mon = eval(res[1][0])
        resdic = { k : mon.get(k,None) for k in fields}
        resdic['date'] = res[0][0].isoformat()
        return resdic 

    def getNxConfig(self, host, **args):

        fields = args.get('fields', ['network-name','device-mode','modem-mode','nic-id','gateway-id'])
        hid = self.hostID(host)
        iid = self.itemID(hid, 'Nx Config')

        res = self.getHistory(iid, limit=1, history=4)
        resdic = {'date':res[0][0].isoformat()}
        config = (res[1][0]).split('\r\n')
        for i in config: 
            res = re.search('|'.join(fields),i)
            if res is not None:  
                _ , e = res.span()           
                resdic[res.group()] = i[e+1:]             
        
        return resdic  


    def getGESLA(self, host, hours, **args):
        fields = args.get('fields', ['rx-packets','rx-bytes','tx-packets','tx-bytes', 'rx-error','tx-error'])
        hid = self.hostID(host)
        item = args.get('item', 'Ge Connected Remotes')
        iid = self.itemID(hid, item)
        res = self.getHistory(iid, hours=hours, history=4, latest=False)
          
        f = lambda b,a : [max(int(x) -int(y),0) for x,y in zip(b,a)]
        f1 = lambda b,a : [x + y for x,y in zip(b,a)]

        bres = None
        tres = [0] * len(fields)
        for d,v in zip(res[0],res[1]):
            mon = eval(v)
            ares = [ mon.get(k,None) for k in fields ]
            #resdic['date'] = d.isoformat()

            if bres is not None: tres = f1(tres,f(bres,ares))

            bres = ares
           
        resdic = { k:v for k,v in zip(fields,tres) }
        td = res[0][0] - res[0][-1]
        resdic['time'] = {'days':td.days, 'hours':td.seconds//3600, 'min': (td.seconds//60)%60 }
        return resdic

    def getSLA(self, host, hours, **args):
        if args.get('mode','noap') == 'ap':
            fields = ['tx-success','tx-retry','tx-fail','rx-success']
            res1 = self.getGESLA(host, hours, fields=fields, item='Mac Stats')
            fields = ['in-octets','in-unicast-pkts','in-discards','out-octets','out-unicast-pkts','out-discards','out-errors']
            res2 = self.getGESLA(host, hours, fields=fields, item='Statistics')
            return res1 | res2
        else:
            fields = ['rx-packets','rx-bytes','tx-packets','tx-bytes', 'rx-error','tx-error']
            return self.getGESLA(host, hours, fields=fields, item='Ge Connected Remotes')

if __name__ == "__main__":
    wsname = 'PTO-S-GE-081'
    gename = 'MRO-S-GE-012'
    apname = 'MRO-S-P7-001'

    with MyZabbix() as z:          
        # res = z.conn.do_request( 'host.get', {'filter': {'name':wsname, 'selectInventory' : ['location_lat','location_lon'], 'output' : 'inventory' } } ) 
        res = z.searchHost(wsname)
        print(res)
        res = z.getInfo(wsname)
        print(res)












