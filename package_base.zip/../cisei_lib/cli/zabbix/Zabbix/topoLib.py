import zabbixLib
import os

# Built Topology
class TopoZabbix:
    def __init__(self, city, **args):
        dir = os.path.dirname(os.path.realpath(__file__))
        self.dir = os.path.join(dir, 'TOPOLOGY')
        self.city = city

        if not os.path.isdir(self.dir):
            os.makedirs(self.dir)

        refresh = args.get("refresh", False)

        with zabbixLib.MyZabbix() as z:        
            self.hosts = self.getHosts(z, refresh)
            self.topo = self.getTopo(z, refresh)
            self.pos = self.getPos(z,refresh)
  
    # Get all hosts correponding to self.city (located by search *xxx*)
    # Get host list from file HOSTS_xxx.txt if exists, creates otherwise
    # Returns a dictionary {hostid:[name, description]}
    def getHosts(self, z, refresh=False):
        path = os.path.join(self.dir, f'HOSTS_{self.city}.txt')

        if refresh or not os.path.isfile(path):
            res = z.searchHost(f'*{self.city}*')    
            with open(path,'w') as f: 
                f.write(str(res))
        else:
            print('hosts from file')
            res = eval(open(path,'r').read())
        
        return res

    # Get conection information corresponding to self.hosts
    # Get connection info from file TOPO_xxx.txt if exists, creates otherwise
    # Returns a dictionary: {hostid:{Gateway ID, NIC ID, Connected Radios, Route}}
    def getTopo(self, z, refresh=False):
        path = os.path.join(self.dir, f'TOPO_{self.city}.txt')
    
        if refresh or not os.path.isfile(path):
            res =z.getTopology(list(self.hosts.keys()), byID=True)    
            with open(path,'w') as f: 
                f.write(str(res))
        else:
            print('topo from file')
            res = eval(open(path,'r').read())

        return res

    # Get [lat,lon] information corresponding to self.hosts
    # Get position info from file POS_xxx.txt if exists, creates otherwise
    # Returns a dictionary: {hostid:[lat, lon]} => OBS. coordinates are strings
    def getPos(self, z, refresh=False):
        path = os.path.join(self.dir, f'POS_{self.city}.txt')
    
        if refresh or not os.path.isfile(path):
            res = [ r[0] for r in self.hosts.keys() ]                       
            pos = {}
            for h in self.hosts.values():
                r = z.hostInventory(h[0])
                ri = r['inventory']
                pos[r['hostid']]=[ ri['location_lat'], ri['location_lon'] ]
                with open(path,'w') as f: 
                    f.write(str(pos))
        else:
            print('pos from file')
            pos = eval(open(path,'r').read())

        return pos

    def __enter__(self):
        return self

    def __exit__(self, ext_type, exc_value, traceback):
        pass

    # Get project information corresponding to self.hosts
    # Retrive information from file PROJ_xxx.txt if exists, creates otherwise
    # Returns a dictionary: {hostid:[name:value, etc.]} => OBS. all values are strings
    
    def getInfo(self, **args):
        path = os.path.join(self.dir, f'INFO_{self.city}.txt')

        if args.get('refresh', False) or not os.path.isfile(path):          
            hids = args.get('hosts', [ r[0] for r in self.hosts.values() ] )
                                  
            with zabbixLib.MyZabbix() as z: 
                info = z.getInfo(hids, 
                info=[ 'Name', 'GE Device Mode', 'GE Network Name', 'Down Stream Avg RSSI', 'Parent Node Avg Rssi',
                'Down Stream Avg LQI', 'Rx Packets', 'Rx Error'])   

            with open(path,'w') as f: 
                f.write(str(info))

        else:
            print('info from file')
            info = eval(open(path,'r').read())
        
        return(info)

def demo():
    print('You dont need a demo!')
    return None

if __name__ == "__main__":
    z = TopoZabbix('PTO-S', refresh=False)
    z.getInfo(refresh=True)
