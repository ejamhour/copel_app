from tkinter import *
from wolframclient.evaluation import WolframLanguageSession
from wolframclient.language import wl, wlexpr
from PIL import Image, ImageTk
import io, os


class ZabbixGUI:

    def __init__(self, root, **args):

        self.geo = (1280,800)
        root.geometry(str(self.geo[0]) + 'x' + str(self.geo[1]))
        root.title("Voltage and Current Trend Analysis")
        root.protocol("WM_DELETE_WINDOW", lambda: (root.quit(), root.destroy(), self.endWE()))

        self.root = root

        self.bh = 0.03

        if args.get('WE',False):
            print('Starting Wolfram Engine')
            self.startWE()

    def startWE(self):
        dir = os.path.dirname(os.path.realpath(__file__))
        #"C:\\Program Files\\Wolfram Research\\Mathematica\\12.0\\wolfram.exe"
        self.session = WolframLanguageSession()
        path = os.path.join(dir, 'myLib.wl')
        self.session.evaluate(wl.Get(path)) 

    def createToolbar(self):

        button = Button(self.root, text='PLOT', command=self.plotGraph )
        button.place(relheight=self.bh, relwidth= 0.1)

    def ready(self):
        self.createToolbar()
        self.root.mainloop()

    def plotGraph(self):
        #res = self.session.evaluate(wlexpr('MyLib`Banana[50, 100]'))
        edges = '{{1,2},{2,3},{3,4},{2,4},{4,1},{2,5}}'
        data = self.session.evaluate(wlexpr(f'MyLib`GeoBanana[{edges}]'))
        img = Image.open(io.BytesIO(data))
        img.show()


    def endWE(self):
        self.session.terminate()
        print('Goodbye')

#-----------------------------------------------------------------
# Used to test the code not used as a Python module
if __name__ == "__main__":
    root = Tk()
    x = ZabbixGUI(root, WE=True)
    #x.startWE()
    x.ready()
    






