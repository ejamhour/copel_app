import matplotlib.pyplot as plt
import matplotlib.dates as mdates

def datePlot(dates, values):
    #.strftime('%Y-%m-%d %H:%M:%S')
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M:%S'))
    plt.gca().xaxis.set_major_locator(mdates.DayLocator())
    plt.gca().xaxis.set_major_locator(plt.MaxNLocator(20))
    plt.plot(dates, values)
    plt.gcf().autofmt_xdate()
    plt.show()
