import DBWrapper as dbw
import os

class ZabbixImporter(object):
    def __init__(self, **args):
        basedir = os.path.dirname(os.path.realpath(__file__))   
        zdir = os.path.join('..', 'Zabbix', 'TOPOLOGY')
        self.zin_dir = os.path.join(basedir, zdir)
        self.zout_dir = os.path.join(basedir, 'IMPORTED')                 
        self.db = dbw.MySQL(db_file=args['db_file']) if "db_file" in args else dbw.MySQL()  
    
        if not os.path.isdir(self.zout_dir):
            os.makedirs(self.zout_dir)
        
    def __str__(self):
        return 'BASEDIR: ' + self.pid

    def __enter__(self):
        return self
    
    def __exit__(self, t, v, tr):
        self.db.close()

    def import_data(self, city):
        
        try:
            path = os.path.join(self.zin_dir, f'TOPO_{city}.txt')
            with open(path,'r') as f: 
                self.topo = f.read()
            path = os.path.join(self.zin_dir, f'HOSTS_{city}.txt')
            with open(path,'r') as f: 
                self.hosts = f.read()
            path = os.path.join(self.zin_dir, f'POS_{city}.txt')
            with open(path,'r') as f: 
                self.pos = f.read()

        except Exception as e:
            print(e)

    def export_poles():
        pass

#-----------------------------------------------------------------
# Used to test the code not used as a Python module
if __name__ == "__main__":

    with ZabbixImporter() as z:
        z.import_data('JAC-')
        print(z.topo)
        print(z.hosts)
        print(z.pos)
