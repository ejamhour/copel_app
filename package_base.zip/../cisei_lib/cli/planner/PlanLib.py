# CISEI, E.J., COPEL DIS ANEEL

import WSwrapper
import os
import shutil
from glob import glob
from threading import Thread
import pandas as pd
import datetime
from urllib.parse import quote
import json
import DBWrapper
import CSVExporter
import warnings
import cisei_lib.globals as g


# PlanLib warning
class PlanLibWarning(Warning):
    def __init__(self, msg, cat, obj=None):
        super().__init__(f'{cat} : {msg}')
        self.msg, self.obj, self.cat = msg, obj, cat

# warnings.warn(PlanLibWarning(f'Warning message', 'function_name',  object))  
    

'''
This class is a wrapper for calling Wolfram Language Scripts
types of project:
- all elements in a city (all pops in a city)
- all elements near to a pop
- subset of elements near a pop
'''
class PlanLib:

    def __init__(self, **args):
        #basedir = os.path.dirname(os.path.realpath(__file__))   
        basedir = g.g_basedir     
        self.wdir = os.path.join( basedir, g.g_wolfram ) # Wolfram Scripts
        self.config = os.path.join(basedir, g.g_config_folder)
        self.pdir = os.path.join( g.g_basedir, g.g_projects_folder )
        self.rundir = None

        if not os.path.isdir(self.pdir): os.makedirs(self.pdir)

        self.pid = None
        self.city = None
        self.saved = None
        self.nodes = {'cities' : None, 'pops': None, 'towers':None, 'dads': None, 'meters': None, 'poles': None, 'amigs' : None, 'bhns': None }
        self.count = {'meters' : 0, 'amigs' :0, 'dads' : 0, 'bhns' : 0 }
        self.db = DBWrapper.MySQL(db_file=args['db_file']) if "db_file" in args else DBWrapper.MySQL()    
        self.pdl = {}

    def __str__(self):
        return 'PROJECT ID: ' + self.pid

    def __enter__(self):
        return self
    
    def __exit__(self, t, v, tr):
        self.db.close()

    # Clears a project from memory (does not remove from DB)
    def clearproject(self):
        self.pid = None
        self.rundir = None
        self.city = None
        self.pdl = {}
        for k in self.nodes.keys():
            self.nodes[k] = None
        return
    
    # Removes a project from DB
    def removeproject(self, pid, **args):

        print(f'Project {pid} will be removed!')
        sql = f"SELECT * FROM projects WHERE dependency LIKE '%{pid}%'"
        dep = self.db.pdquery(sql)
        if not dep.empty:
            dpids = dep['id'].values
            print(f'WARNING: projects {dpids} will also be deleted')
            if not args.get('dependency', False):
                raise Exception('Cannot remove the project because option dependency is not set' )

        # sql = f'''UPDATE dads SET bhn_node=null WHERE bhn_node IN (SELECT uid FROM bhn_nodes WHERE project_id={pid})'''
        sql = f'''UPDATE dads SET bhn_node=null WHERE bhn_node LIKE "%_{pid}"'''
        self.db.execute(sql)
        self.db.commit()

        sql = f'''UPDATE meters SET ami_node=null WHERE ami_node LIKE "%_{pid}"'''
        self.db.execute(sql)
        self.db.commit()

        sql = f"DELETE FROM bhn_nodes WHERE project_id={pid}"
        self.db.execute(sql)
        self.db.commit()

        sql = f"DELETE FROM ami_nodes WHERE project_id={pid}"
        self.db.execute(sql)
        self.db.commit()

        sql = f"DELETE FROM projects WHERE id={pid}"
        self.db.execute(f"DELETE FROM projects WHERE id={pid}")
        self.db.commit()

        if not dep.empty:
            for dpid in dpids:
                self.removeproject(dpid, dependency=True)

    # Imports planning from JSON bhn nodes into the DB
    def import_bhnodes(self, **args):

        file = args.get('file', os.path.join(self.rundir, 'JSON', 'bhnodes.json'))
        if not os.path.isfile(file):
            raise Exception('ERROR import_bhnodes: This project has no bhnodes.json' )

        df = pd.read_json(file) 
        dep = [ int(l.split('_')[-1]) for l in df['label'].values if len( l.split('_')) > 1 ] # duplicates?
        dfdb = pd.DataFrame()

        dfdb['uid'] = [ f'{l}_{self.pid}' for l in df['label'].values ]
        dfdb['label'] = df['label'].values
        dfdb['project_id'] = [self.pid] * df.shape[0]
        dfdb['city'] = [self.city] * df.shape[0]
        dfdb['pop'] = df['pop'].values
        dfdb['next_hop'] = df['next_hop'].values
        dfdb['hops'] = df['hops'].values
        dfdb['path'] = [ str(p) for p in df['path'].values ]
        dfdb['radios'] = df['radios'].values
        dfdb['pole_uid'] = df['pole_uid'].values
        dfdb['tags'] = ['{}'] * df.shape[0] 
        
        sql = "DELETE FROM bhn_nodes WHERE project_id=?"
        self.db.execute(sql, (self.pid,))    

        dfdb.to_sql('bhn_nodes', self.db.connection, if_exists='append', index=False)

        sql = "UPDATE dads SET bhn_node = bhn_nodes.uid FROM bhn_nodes WHERE dads.pole_uid=bhn_nodes.pole_uid"
        self.db.execute(sql)
        sql = "UPDATE ami_nodes SET bhn_node = bhn_nodes.uid FROM bhn_nodes WHERE ami_nodes.pole_uid=bhn_nodes.pole_uid"
        self.db.execute(sql)
        self.db.commit()

        sql = "UPDATE projects SET saved=?,dependency=? WHERE id=?"
        sql = f"UPDATE projects SET saved=1,dependency='{json.dumps(dep)}' WHERE id={self.pid}" 
        # self.db.execute(sql, (True,json.dumps(dep), self.pid))
        self.db.execute(sql)
        self.db.commit()

    # Imports planning from JSON bhn links into the DB
    def import_bhlinks(self, **args):
        file = args.get('file', os.path.join(self.rundir, 'JSON', 'bhlinks.json'))
        if not os.path.isfile(file):
            raise Exception('ERROR import_bhnodes: This project has no bhnodes.json' )
        
        df = pd.read_json(file) 

        dfdb = pd.DataFrame()
        dfdb['pop'] = df['pop'].values
        dfdb['project_id'] = [self.pid] * df.shape[0]
        dfdb['uid_parent'] = [ f'{l}_{self.pid}' for l in df['snode'].values ]
        dfdb['uid_child'] = [ f'{l}_{self.pid}' for l in df['dnode'].values ]
        dfdb['antennas'] = df['ant'].values
        dfdb['distance'] = df['distance'].values
        dfdb['rssi'] = df['rssi'].values
        dfdb['clearance'] = df['los'].values
        dfdb['tags'] = ['{}'] * df.shape[0] 

        sql = "DELETE FROM bhn_links WHERE project_id=?"
        self.db.execute(sql, (self.pid,))    

        dfdb.to_sql('bhn_links', self.db.connection, if_exists='append', index=False)
        
    # Imports planning from JSON bhn nodes into the DB
    def import_aminodes(self, **args):

        file = args.get('file', os.path.join(self.rundir, 'JSON', 'aminodes.json'))
        if not os.path.isfile(file):
            raise Exception('ERROR import_aminodes: This project has no aminodes.json' )

        df = pd.read_json(file) 
        dfdb = pd.DataFrame()

        df["meters"] = df["meters"].fillna('[]')

        dfdb['uid'] = [ f'{l}_{self.pid}' for l in df['label'].values ]
        dfdb['label'] = df['label'].values
        dfdb['project_id'] = [self.pid] * df.shape[0]
        dfdb['city'] = [self.city] * df.shape[0]
        dfdb['type'] = df['type'].values
        dfdb['config_uid'] =  df['radio'].values
        dfdb['gateway'] = df['gateway'].values
        dfdb['pole_uid'] = df['pole_uid'].values
        dfdb['meters'] = [ len(x) for x in df['meters'] ]
        dfdb['tags'] = ['{}'] * df.shape[0] 

        sql = "DELETE FROM ami_nodes WHERE project_id=?"
        self.db.execute(sql, (self.pid,))    

        dfdb.to_sql('ami_nodes', self.db.connection, if_exists='append', index=False)
        
        # TODO: create a status for saved AMI, verify AMI expansion

        sql = f"SELECT * FROM meters WHERE pop IN (SELECT uid FROM pops WHERE city_name ='{self.city}')"
        dfdb = self.db.pdquery(sql)

        meters = {}
        for r in df.index:
            for m in df['meters'][r]:
                meters[m] = df['label'][r] + f'_{self.pid}'       

        dfdb['ami_node'] = [ meters.get(dfdb['uid'][i],'') for i in  dfdb.index ]

        sql = f"DELETE FROM meters WHERE pop IN (SELECT uid FROM pops WHERE city_name ='{self.city}')"
        self.db.execute(sql)   

        dfdb.to_sql("meters", self.db.connection, if_exists="append", index=False)

    # Filters a pandas dataframe using table columns (fields) and tags
    # tags: starts with prefix tag_, otherwise it is considered a field
    # constraints are combined with AND within {} and OR within []    
    def tagfilter(self, df, args, op='add'):

            def fi(row):
                if row.tags is None: return False
                rtags = eval(row.tags)
                flag = [True if v == rtags.get(k, None) else False for k,v in tags.items()]
                return not False in flag
           
            def fe(row):
                if row.tags is None: return True
                rtags = eval(row.tags)
                flag = [True if v == rtags.get(k, None) else False for k,v in tags.items()]
                return False in flag        

            fields = { k:v for k,v in args.items() if not k.startswith('tag_')}

            lfields = { k:v for k,v in fields.items() if type(v) == list }

            tags = { k.removeprefix('tag_'):v for k,v in args.items() if k.startswith('tag_')}

            if op == 'add': 
                res = df
                for k,v in lfields.items(): res = res[res[k].isin(v)]  
                if len(fields) > 0:                   
                    myquery = [ f'{k} == {v}' for k,v in fields.items() ]
                    res = res.query( "&".join(myquery) )
                if len(tags) > 0: 
                    res = res[ res.apply( fi , axis=1) ]  

            if op == 'drop': 
                res = df
                for k,v in lfields.items(): res = res[~res[k].isin(v)]  
                if len(fields) > 0:                   
                    myquery = [ f'{k} != {v}' for k,v in fields.items() ]
                    res = res.query( "&".join(myquery) )
                if len(tags) > 0: 
                    res = res[ res.apply( fe , axis=1) ] 

            return res

    # Merges dataframes with overlapping rows
    def merge_df(self, old_df, new_df):
        idx = new_df.index.difference(old_df.index)
        return pd.concat( [old_df, new_df.loc[idx, :] ], axis= 0)        

    # Selects the country and verifies if it exists: only one per project
    def setcity(self, name):
        sql = f"SELECT * FROM cities WHERE  name='{name}' LIMIT 1"    
        df = self.db.pdquery(sql)
        if df.empty: 
            raise Exception('city not found') 
        else: 
            self.nodes['cities'] = df
            self.city = name
            self.pdl['city'] = name
    
    # Adds nodes to the project 
    # OBS. _type_ cannot appear in args!!!
    def addnodes(self, _type_, **args):
        if _type_ not in self.nodes:
            raise Exception(f'invalid node type - must be: {self.nodes.keys()}')        
        if _type_ == 'pops':
            sql = f"SELECT * FROM pops WHERE city_name='{self.city}'"            
        elif _type_ == 'dads':
            sql = f"SELECT * FROM {_type_} WHERE pop IN (SELECT uid FROM pops WHERE city_name ='{self.city}') and bhn_node IS NULL"
        elif _type_ == 'meters':
            sql = f"SELECT * FROM {_type_} WHERE pop IN (SELECT uid FROM pops WHERE city_name ='{self.city}') and ami_node IS NULL"  
        elif _type_ == 'bhns':
            if self.nodes['pops'] is None: raise Exception('must add pops before bhns')
            pops = self.nodes['pops'].pop_name.values
            sql = DBWrapper.MyQUeries().qry_bhns_by_pop(pops, drop_pops=True )
        elif _type_ == 'amigs':
            sql = DBWrapper.MyQUeries().qry_amigs_by_city( self.city )
        else:
            sql = f"SELECT * FROM {_type_} WHERE pop IN (SELECT uid FROM pops WHERE city_name ='{self.city}')"            
        
        print("Compiling:", _type_)
        df = self.db.pdquery(sql)
   
        if not df.empty: 
            df = self.tagfilter(df, args)
        
        if self.nodes[_type_] is None:       
            self.nodes[_type_] = df                          
        else:
            self.nodes[_type_] = self.merge_df(self.nodes[_type_], df)

        key = f'add {_type_}'
        if key not in self.pdl: self.pdl[key] = []
        self.pdl[key].append(args)

    # Removes nodes from the project
    # args : {k,v} where k is a column name ou a tag (with prefix tag_)
    # OBS. _type_ cannot appear in args!!!   
    def dropnodes(self, _type_, **args):
        if _type_ not in self.nodes:
            raise Exception(f'invalid node type - must be: {self.nodes.keys()}')

        if self.nodes[_type_] is None: 
            print(f'WARNING dropnode: {_type_} list is empty')
        else:
            if 'uids' in args:
                try: self.nodes[type] = self.nodes[type].drop(args['uids'])         
                except: pass

            self.nodes[_type_] = self.tagfilter(self.nodes[_type_], args, op='drop')

            if self.nodes[_type_].empty: 
                self.nodes[_type_] = None

        key = f'drop {_type_}'
        if key not in self.pdl: self.pdl[key] = []
        self.pdl[key].append(args)
              
    # Exports dataframes to FOLDER project in CSV format
    def exportCSV(self, folder):

        for n in ['cities', 'pops', 'poles']:
            if self.nodes[n] is None: raise Exception(f'ERROR: {n} is missing')

        csv = CSVExporter.CSVExporter(folder, fullpath=True) 
        csv.export_cities('cidades.csv', self.nodes['cities'])    
        csv.export_pops('subestacoes.csv', self.nodes['pops'])
        csv.export_poles('polesnearsub.csv', self.nodes['poles'])
        if self.nodes['towers'] is not None:
            csv.export_towers('torresnearsub.csv', self.nodes['towers'])
        if self.nodes['dads'] is not None:
            csv.export_dads('automacaonearsub.csv', self.nodes['dads'])
        if self.nodes['meters'] is not None:
            csv.export_meters('allmetersnearsub.csv', self.nodes['meters'])
        if self.nodes['bhns'] is not None:
            csv.export_bhnodes('backhaul_nodes.csv', self.nodes['bhns'])
        if self.nodes['amigs'] is not None:
            csv.export_amigs('ami_gateways.csv', self.nodes['amigs'])

    # Check CSV files project dir
    def checkCSV(self):
        if self.rundir is None:
            raise "Project is empty"

        # "uc"->False, "poles"->True, "tower"->True, "dads"->True,  "ami"->False, "bhn"->False, "amigs"->False

        csvs = {'cities':'cidades.csv', 'pops':'subestacoes.csv', 'poles':'polesnearsub.csv', 'tower':'towersnearsub.csv', 
                'dads':'automacaonearsub.csv', 'uc':'allmetersnearsub.csv', 'bhn': 'backhaul_nodes.csv', 'amigs': 'ami_gateways.csv'}
        
        for k,v in csvs.items():
            csvs[k] = os.path.isfile( os.path.join(self.rundir,'Latlong', v))

        return csvs

    # Creates a project: database and project folder
    def createproject(self, name, **args):

        self.count['meters'] = 0 if self.nodes['meters'] is None else self.nodes['meters'].shape[0]
        self.count['dads'] = 0 if self.nodes['dads'] is None else self.nodes['dads'].shape[0]
        self.count['amigs'] = 0 if self.nodes['amigs'] is None else self.nodes['amigs'].shape[0]
        self.count['bhns'] = 0 if self.nodes['bhns'] is None else self.nodes['bhns'].shape[0]

        if self.count['meters'] + self.count['dads'] == 0: raise Exception('ERROR: there is nothing to plan!!!')

        df = self.db.pdquery(f"SELECT * FROM projects WHERE name='{name}'")
        if not df.empty:
            id = df['id'].values[0]
            if not args.get('overwrite', False):
                raise Exception('ERROR: there is a project with same name and overwrite is not set')
            else:
                self.removeproject(id)

        df = self.db.pdquery('SELECT MAX(id) FROM projects')
        id = df.iloc[0][0]
        id = 1 if id is None else id + 1

        print(f'This project id is: {id}')
        folder = f'PROJECT_{id}'

        df = { 
            'name': name, 
            'description' : [args.get('description', 'not available')],
            'city' : [self.city],
            'folder': [folder],
            'date': [datetime.datetime.now()],
            'meters' : [self.count['meters']],
            'amigs' : [self.count['amigs']],
            'bhns' : [self.count['bhns']],
            'dads' : [self.count['dads']],
            'tags': [args.get('tags', '{}')],
            'dependency' : '[]'
        }

        df = pd.DataFrame(data=df)
        df.to_sql('projects', self.db.connection, if_exists='append', index=False)

        pdir = os.path.join(self.pdir, folder)
        if os.path.isdir(pdir):            
            print('WARNING: an old folder project will be removed')
            shutil.rmtree(pdir)
        csvdir = os.path.join(pdir,'Latlong')
        os.makedirs(pdir)
        os.makedirs(csvdir)        
        
        with open(os.path.join(pdir, 'pdl.json'), 'w') as f: 
            f.write(json.dumps(self.pdl, indent = 5))

        filename = self.pdl['project']['radiomodel'] if 'radiomodel' in self.pdl['project'] else 'defaultmodel.json'
        shutil.copyfile(os.path.join(self.config, filename), os.path.join(pdir, 'radiomodel.json'))

        self.exportCSV(csvdir)
        self.rundir = pdir
        self.pid = id
        return id

    # Creates a project from a PDL file (JSON)
    def compilePDL(self, file, **args):

        res = json.load(file)

        for k in res.keys():
            try:
                if k == "project":
                    if 'name' not in  res[k].keys():
                        raise Exception('ERROR: name attribute is missing in the project definition!')
                    self.pdl[k] = res[k]
                elif k == "city":
                    self.setcity(res[k])
                elif k.startswith('add'):
                    if len(res[k]) == 0:
                        self.addnodes(k.removeprefix('add ') ) 
                    else:
                        for l in res[k]: self.addnodes(k.removeprefix('add '), **l )     
                elif k.startswith('drop'):
                    if len(res[k]) == 0:
                        self.addnodes(k.removeprefix('drop ') ) 
                    else:
                        for l in res[k]: self.dropnodes(k.removeprefix('drop '), **l ) 
                else:
                    raise Exception(f'Unknown command {k}')

            except Exception as e:
                print(e)
                raise Exception(f'check PDL key {k}')

        if args.get('save', True):
            self.createproject( **res['project'])

    # Loads project from DB: it does not create a project folder
    def loadproject(self, id):
        sql = f"SELECT * FROM projects WHERE id={id}"
        df = self.db.pdquery(sql)
        if df.empty:
            raise Exception('ERROR: this project does not exist!')
        
        self.city = df.at[0,'city']
        self.saved = df.at[0,'saved']
        self.count['meters'] = df.at[0,'meters']
        self.count['amigs'] = df.at[0,'amigs']
        self.count['dads'] = df.at[0,'dads']       
        self.count['bhns'] = df.at[0,'bhns']  
        self.rundir = os.path.join(self.pdir, df.at[0,'folder'] )
        self.pid = id

        print('Project Folder:', self.rundir)
       
    # Plans AMI 
    def planAMI(self, **args):

        if self.rundir is None : 
            raise Exception("ERROR: Project is not ready!!!")
        
        if self.count['meters'] == 0 : 
            raise Exception("ERROR: There is no meters in this project!!!")

        log = args.get('log', os.path.join(self.rundir, "logAMI.txt"))

        if os.path.isfile(log) : os.remove(log)
        t = Thread(target=WSwrapper.WSprintLog, args=(log,))
        t.start()
        with WSwrapper.WSwrapper('cliInterface.wls', 
            args=['planAMI', quote(self.city), 'dir='+self.rundir, "config_file=radiomodel.json" ]) as ws:
            if ws.run(log=log): print(ws.wsout)
            else: print(ws.wserr)
        t.join()
        print('AMI Planning terminated!')

    # Plans BHN 
    def planBHN(self, **args):

        if self.rundir is None : 
            raise Exception("ERROR: Project is not ready!!!")
        
        if self.count['dads'] + self.count['amigs'] == 0 : 
            raise Exception("ERROR: There is no element to connect!!!")

        csvs = self.checkCSV() # check Latlong files

        if not csvs['poles'] or not csvs['pops']: 
            raise Exception("ERROR: Can't plan without poles or pops!!!")

        bhn = 'True%%b' if csvs['bhn'] else 'False%%b'
        ami = 'True%%b' if csvs['uc'] else 'False%%b'
        amigs = 'True%%b' if csvs['amigs']  else 'False%%b'
        dads = 'True%%b' if csvs['dads'] else 'False%%b'
        tower = 'True%%b' if csvs['tower'] else 'False%%b'

        log = args.get('log', os.path.join(self.rundir, "logBHN.txt"))

        if os.path.isfile(log) : os.remove(log)
        Thread(target=WSwrapper.WSprintLog, args=(log,)).start()
        with WSwrapper.WSwrapper('cliInterface.wls', 
            args=['planBHN', quote(self.city), 'dir='+self.rundir, "config_file=radiomodel.json", 'dads='+dads, 'bhn='+bhn, 'amigs='+amigs, 'ami='+ami, 'tower='+tower]) as ws:
            if ws.run(log=log): print(ws.wsout)
            else: print(ws.wserr)

    # Imports Wolfram Planning from JSON to DB
    # 0: Not saved, 1: ami saved, 2: bhn saved, 3: both saved
    def savePlanning(self, **args):
        saved = 0
        if args.get('ami', False):
            try:
                self.import_aminodes() 
                saved += 1
            except Exception as e:
                print('Error savePlanning: ', e)     

        if args.get('bhn', False):
            try:
                self.import_bhnodes()
                self.import_bhlinks()
                saved += 2
            except Exception as e:
                print('Error savePlanning: ', e) 

        sql = f"UPDATE projects SET saved={saved} WHERE id={self.pid}"
        self.db.execute(sql)
        self.db.commit()
        self.saved = saved
      
    # Generates HTML/KML Report
    def genReport(self, **args):
        ami = True if len(glob(os.path.join( self.rundir, 'Results', '*_AMI.txt') ) ) > 0 else False
        bhn = True if len(glob(os.path.join( self.rundir, 'Results', '*_BHN.txt') ) ) > 0 else False
        log = args.get('log', os.path.join(self.rundir, "logreport.txt"))
        if os.path.isfile(log) : os.remove(log)
        Thread(target=WSwrapper.WSprintLog, args=(log,)).start()
        with WSwrapper.WSwrapper('cliInterface.wls', 
            args=['genReport', quote(self.city), 'dir='+self.rundir, f'pid={self.pid}%%i', f'AMI={ami}%%b', f'BHN={bhn}%%b' ] ) as ws:
            if ws.run(log=log): print(ws.wsout)
            else: print(ws.wserr)


#---------------------------------------------------------------------
if __name__ == '__main__':
    try:
        with PlanLib(db_file='teste.db') as p:            
            #with open(os.path.join(p.pdir, 'guairatinga.json')) as f: p.compilePDL(f, save=True)   
            p.loadproject(5)
            #p.planAMI()
            # p.savePlanning(ami=True)
            #p.planBHN()
            p.genReport()
            #p.savePlanning(bhn=True, ami=True)
            #p.removeproject(5, dependency=True)
            pass
            

    except Exception as e:
        print('ERROR', e)














