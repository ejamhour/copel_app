from multiprocessing.resource_sharer import stop
from re import RegexFlag
import time
from unicodedata import decimal
import pandas as pd
import DBWrapper as dbw
import hashlib
import json
import datetime
import logging
import os

# FIXME: recast by col name rather than index, when loading csvs
# FIXME: deal with update or fresh-new insert
# FIXME: deal with missing cols


class CSVImporter(object):
    def __init__(self):
        data = None  # stub

    def get_file_hash_sig(self, file):
        hash_md5 = hashlib.md5()
        with open(file, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        full_hash = hash_md5.hexdigest()
        signature = f"{full_hash[0:3]}{full_hash[-4:]}"
        print(f"{file}\nFull hash:{full_hash}\nSignature: {signature}\n\n")
        return full_hash, signature

    def save_import_hash(self, file):
        fhash, _ = self.get_file_hash_sig(file)
        with dbw.MySQL() as db:
            now = datetime.datetime.now()
            df = pd.DataFrame(
                {'file_hash': fhash, 'file_name': os.path.basename(file), 'date': now}, [0])
            df.to_sql('imported_files', db.connection,
                      if_exists='append', index=False)
            insert_id = pd.read_sql(f"select id from imported_files where file_hash = '{fhash}';",
                                    db.connection)
            return int(insert_id["id"])

    def check_already_imported(self, file):
        """checks if file has already been imported"""
        fhash, _ = self.get_file_hash_sig(file)
        with dbw.MySQL() as db:
            df = pd.read_sql(
                f"select * from imported_files where file_hash = '{fhash}';", db.connection)
            print(df)
            if df.empty:
                return False
        return True

    def import_poles2(self, file):

        if self.check_already_imported(file) == True:
            print(f"File {file} has already been imported")
            return
        import_id = self.save_import_hash(file)

        print("Loading poles", file)
        st = time.time()
        df = pd.read_csv(file, delimiter=";", index_col=False,
                         decimal=".",
                         dtype={
                             0: 'float',
                             1: 'float',
                             2: 'float',
                             3: 'Int64',
                             4: 'Int64',
                             5: 'str',
                             6: 'str',
                             7: 'float',
                             8: 'float',
                             9: 'str',
                             10: 'str'})
        et = time.time()
        task_elapsed = et-st

        summem = df.memory_usage(deep=True).sum()
        print(f"Size in memory {(summem/1000000): .2f} MB")
        print(f"CSV reading took: {task_elapsed:.2f} seconds")

        df.columns = ["height", "coordx", "coordy", "county",
                      "seq_geo", "county_name", "region", "lat",
                      "long", "pop_county", "pop", "remove1"]

        ret = df.head()
        print(ret)

        df = df.drop('remove1', axis=1)
        df = df.drop('pop_county', axis=1)
        df["file_id"] = int(import_id)
        df["voltage_class"] = ""  # FIXME:r

        print("Generating uids and stub for tags")
        # uids = []
        coltags = []
        for index, row in df.iterrows():
            # uids.append(f"P{index}")

            # stub tag as example
            tags = {"seq_geo": str(df['seq_geo'].values[index])}
            coltags.append(str(tags))

        df["uid"] = df["seq_geo"]
        df["tags"] = coltags

        st_db = time.time()
        with dbw.MySQL() as db:
            print("Saving to SQL please wait...")
            df.to_sql('poles', db.connection,
                      if_exists='append', index=False)

        et_db = time.time()
        db_save_elapsed = et_db-st_db
        print(f"DB saving took: {db_save_elapsed:.2f} seconds\n")

    def import_meters2(self, file, region):

        if self.check_already_imported(file) == True:
            print(f"File {file} has already been imported")
            return
        import_id = self.save_import_hash(file)

        print("importing meters")

        st = time.time()
        df = pd.read_csv(file, delimiter=";", index_col=False,
                         #  thousands=".",
                         decimal=".",
                         dtype={
                             0: 'Int64',
                             1: 'float',
                             2: 'float',
                             3: 'float',
                             4: 'float',
                             5: 'str',
                             6: 'str',
                             7: 'str'})
        et = time.time()
        task_elapsed = et-st
        ret = df.head()
        summem = df.memory_usage(deep=True).sum()
        print(ret)
        print(f"Size in memory {(summem/1000000): .2f} MB")
        print(f"CSV reading took: {task_elapsed:.2f} seconds")

        fields = ["seq", "coordx", "coordy", "lat", "long",
                  "type", "pop_county", "pop"]

        # rename dataframe columns
        df.columns = fields

        # add columns that dont come from import
        df["region"] = region
        df["file_id"] = import_id

        # for each row, fill data for missing coloumns
        orig_seg = df["seq"].copy()  # original sequential field from csv
        # remove old-seq, to make our own (containing original)
        df = df.drop('seq', axis=1)
        df = df.drop('pop_county', axis=1)
        uids = []
        coltags = []
        for index, row in df.iterrows():  # FIXME: what if sizes arent the same?
            uids.append(f"{df['type'].values[index]}-{orig_seg[index]}")

            # tag example
            tags = {"type": str(df['type'].values[index])}
            coltags.append(str(tags))

        df["uid"] = uids
        df["tags"] = coltags

        st_db = time.time()
        with dbw.MySQL() as db:
            print("Saving to SQL please wait...")
            df.to_sql('meters', db.connection,
                      if_exists='append', index=False)

        et_db = time.time()
        db_save_elapsed = et_db-st_db
        print(f"DB saving took: {db_save_elapsed:.2f} seconds")

    #E.J. Added bhn_node column
    def import_dads2(self, file, region):

        if self.check_already_imported(file) == True:
            print(f"File {file} has already been imported")
            return
        import_id = self.save_import_hash(file)

        print("Loading automation (v2)", file)
        st = time.time()
        df = pd.read_csv(file, delimiter=";", index_col=False,
                         #  thousands=".",
                         decimal=".",
                         dtype={
                             0: 'Int64',
                             1: 'str',
                             2: 'float',
                             3: 'float',
                             4: 'float',
                             5: 'float',
                             6: 'str',
                             7: 'str',
                             8: 'str'})
        et = time.time()
        task_elapsed = et-st
        ret = df.head()
        summem = df.memory_usage(deep=True).sum()
        print(ret)
        print(f"Size in memory {(summem/1000000): .2f} MB")
        print(f"CSV reading took: {task_elapsed:.2f} seconds")

        fields = ["county", "type", "coordx", "coordy",
                  "lat", "long", "pop_county", "pop", "seq_geo"]

        # rename datimport_popsaframe columns
        df.columns = fields

        # remove unwanted columns
        df = df.drop('pop_county', axis=1)
        # add columns that dont come from import
        df["file_id"] = import_id
        df["region"] = str(region)

        # for each row, fill data for missing coloumns
        uids = []
        coltags = []
        for index, row in df.iterrows():
            uids.append(f"{index}")

            # tag example
            tags = {"seq_geo": str(df['seq_geo'].values[index])}
            coltags.append(str(tags))

        df["uid"] = uids
        df["tags"] = coltags
        df['bhn_node'] = ['']*df.shape[0]

        st_db = time.time()
        with dbw.MySQL() as db:
            print("Saving to SQL please wait...")
            df.to_sql('dads', db.connection,
                      if_exists='append', index=False)

        et_db = time.time()
        db_save_elapsed = et_db-st_db
        print(f"DB saving took: {db_save_elapsed:.2f} seconds")

    def import_counties(self, file):

        if self.check_already_imported(file) == True:
            print(f"File {file} has already been imported")
            return
        import_id = self.save_import_hash(file)

        print("Loading counties", file)
        st = time.time()
        df = pd.read_csv(file, delimiter=";", index_col=False,
                         #  thousands=".",
                         decimal=".",
                         dtype={
                             0: 'Int64',
                             1: 'str',
                             2: 'str',
                             3: 'str',
                             4: 'str',
                             5: 'Int64',
                             6: 'str'})
        et = time.time()
        task_elapsed = et-st
        ret = df.head()
        summem = df.memory_usage(deep=True).sum()
        print(ret)
        print(f"Size in memory {(summem/1000000): .2f} MB")
        print(f"CSV reading took: {task_elapsed:.2f} seconds")

        fields = ["code", "name", "reg", "dist",
                  "sec", "uc_count", "region"]
        df.columns = fields

        df["file_id"] = import_id

        st_db = time.time()
        with dbw.MySQL() as db:
            print("Saving to SQL please wait...")
            df.to_sql('counties', db.connection,
                      if_exists='append', index=False)

        et_db = time.time()
        db_save_elapsed = et_db-st_db
        print(f"DB saving took: {db_save_elapsed:.2f} seconds")

    def import_pops2(self, file, region, is_substation=True):
        print("importing pops (v2)")

        if self.check_already_imported(file) == True:
            print(f"File {file} has already been imported")
            return
        import_id = self.save_import_hash(file)


        df = pd.read_csv(file, delimiter=";", index_col=False,
                         decimal=".",
                         encoding='latin1',  # FIXME: does not help, file is beyond broken
                         dtype={
                             0: 'str',
                             1: 'str',
                             2: 'str',
                             3: 'float',
                             4: 'str',
                             5: 'str',
                             6: 'float',
                             7: 'float',
                             8: 'Int64'})


        fields = ["county_name", "pop_name", "has_tower", "height",
                  "coordx", "coordy", "lat", "long", "seq_geo"]
        df.columns = fields

        # patch broken yes/no field
        # lower string, then pick first char
        df["has_tower"] = df["has_tower"].str.lower().str[0:1]

        dumph = df["has_tower"].head()
        print(dumph)
        df["has_tower"] = df["has_tower"].map(
            {'s': True, 'n': False},)
        dumph = df["has_tower"].head()
        print(dumph)

        # patch degenerated col
        df['coordx'] = df['coordx'].str.replace(',', '.').astype(float)
        df['coordy'] = df['coordy'].str.replace(',', '.').astype(float)
        df["region"] = str(region)
        df["is_substation"] = is_substation

        coltags = []
        for index, row in df.iterrows():
            tags = {"seq_geo": str(df['seq_geo'].values[index])}
            coltags.append(str(tags))
        df["uid"] = df["pop_name"]
        df["tags"] = coltags

        # debug
        ret = df.head()
        print(ret)

        df["file_id"] = import_id

        st_db = time.time()
        with dbw.MySQL() as db:
            print("Saving to SQL please wait...")
            df.to_sql('pops', db.connection,
                      if_exists='append', index=False)

        et_db = time.time()
        db_save_elapsed = et_db-st_db
        print(f"DB saving took: {db_save_elapsed:.2f} seconds")

    #E.J. Added county column (4) - missing?
    def import_towers(self, file, region):
        print("importing towers")

        if self.check_already_imported(file) == True:
            print(f"File {file} has already been imported")
            return

        import_id = self.save_import_hash(file)


        df = pd.read_csv(file, delimiter=";", index_col=False,
                         decimal=".",
                         encoding='latin1',  # FIXME: does not help, file is beyond broken
                         dtype={
                             0: 'Int64',
                             1: 'str',
                             2: 'float',
                             3: 'float',
                             4: 'str', # csv has an extra county column
                             5: 'float',
                             6: 'float',
                             7: 'str',
                             8: 'str'})

        fields = ["height", "fiber", "coordx", "coordy",
                  "lat", "long", "pop_county", "pop"]
        df.drop(df.columns[[4]],axis=1,inplace=True) # remove the county column
        df.columns = fields

        # patch broken yes/no field
        # lower string, then pick first char
        df["fiber"] = df["fiber"].str.lower().str[0:1]
        dumph = df["fiber"].head()
        print(dumph)



        df["fiber"] = df["fiber"].map(
            {'s': True, 'n': False},)
        dumph = df["fiber"].head()
        print(dumph)


        df = df.drop('pop_county', axis=1)
        df["region"] = str(region)

        uids = []
        coltags = []
        for index, row in df.iterrows():
            uids.append(f"{index}")

            # tag example
            tags = {"pop": str(df['pop'].values[index])}
            coltags.append(str(tags))
        df["uid"] = uids
        df["tags"] = coltags

        # debug
        ret = df.head()
        print(ret)

        df["file_id"] = import_id

        st_db = time.time()
        with dbw.MySQL() as db:
            print("Saving to SQL please wait...")
            df.to_sql('towers', db.connection,
                      if_exists='append', index=False)

        et_db = time.time()
        db_save_elapsed = et_db-st_db
        print(f"DB saving took: {db_save_elapsed:.2f} seconds")

    def poles_merge_tensiontype(self, raw_file):

        print("...Using seq_geo to merge tables and acquire tension_type for each pole. Please wait...")

        st = time.time()
        df2 = pd.read_csv(raw_file, delimiter=";", index_col=False,
                          thousands=".",
                          dtype={
                              0: 'Int64'})
        # 1 12 13 32 43 60 65
        # 57 is col about tension type AT BT ATBT
        filter1 = df2.iloc[:, [0, 11, 12, 31, 42, 59, 64, 57]]
        et = time.time()

        task_elapsed = et-st

        ret = filter1.head()
        print(ret)

        summem = df2.memory_usage(deep=True).sum()
        print(ret)
        print(f"Size in memory {(summem/1000000): .2f} MB")
        print(f"CSV reading took: {task_elapsed:.2f} seconds")

        with dbw.MySQL() as db:
            df = pd.read_sql_query("SELECT * FROM poles", db.connection)
            total = len(df.index)
            st = time.time()
            last_prog = 1.0
            wait_interval = 2.0

            logging.basicConfig(filename='merge_log.log', level=logging.DEBUG)

            for index, row in df.iterrows():
                now = time.time()
                if now - st > wait_interval:
                    st = now
                    prog = ((index/total)*100)
                    dprog = prog - last_prog
                    last_prog = prog
                    remaining = (((100-prog)/dprog)*wait_interval)
                    print(
                        f"Merging...{prog:.2f}% ({index}/{total}) ({int(remaining/60)}m{int(remaining%60)}s)")

                # testar indice seqgeo para mudar aqui
                vt = filter1[filter1["NUM_SEQ_GEO"] == int(row["seq_geo"])]

                if vt["TIPO_TENSAO"].empty:
                    note_msg = f"Skipping ({index}/{total}) (seq: {row['seq_geo']})"
                    print(note_msg)
                    logging.debug(note_msg)
                    continue

                df["voltage_class"].values[index] = vt["TIPO_TENSAO"].values[0]

            print(df.head())

            print("Saving to SQL please wait...")
            df.to_sql('poles', db.connection,
                      if_exists='replace', index=False)
            print("merge done")

    def import_radiomodel(self, file, **args):
        pass

#-----------------------------------------------------------------
# Used to test the code not used as a Python module
if __name__ == "__main__":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    dbw.set_default_DB('cisei_teste.db')
    os.chdir(os.path.join(BASE_DIR, '../Editais/Latlong_Fase3'))
    csv = CSVImporter()
    csv.import_counties('cidades.csv')
    #csv.import_pops2('subestacoes.csv','FASE 3')
    #csv.import_dads2('automacaonearsub.csv','FASE 2')
    #csv.import_towers('torresnearsub.csv','FASE 3')
    #csv.import_meters2('allmetersnearsub.csv','FASE 3')
    #csv.import_poles2('polesnearsub.csv')
