# Data: 25/12/2022

import DBWrapper

# "DROP TABLE cities"


imported_files = """CREATE TABLE IF NOT EXISTS "imported_files"
-- Imporeted files
-- Purpouse:
--  track imported files
--  help update/replace rows from imported data
(
    id              INTEGER,
    file_name       TEXT,
    file_type       TEXT,   -- dads, pops, etc ..
    file_info       TEXT,   -- FASE2, FASE3, etc.
    pos_type        TEXT,   -- Null, utm, lat, pole
    date            TEXT,
    file_hash       TEXT,
    tags            TEXT,
    PRIMARY KEY (id)
); """

cities = """CREATE TABLE IF NOT EXISTS cities
-- Municipios
(
    id INTEGER,
    code            INTEGER,
    name            TEXT,
    uc_count        INTEGER,   
    tags            TEXT,
    file_info       TEXT,
    file_id         INTEGER,
    PRIMARY KEY(id)
); """

pops = """CREATE TABLE IF NOT EXISTS pops
-- Tabela de pontos de presença (podendo ser em torres)
-- Não exclusivamente, podem ser torres em/ou subestacoes
(
    id              INTEGER,
    uid             TEXT,       -- may be a code
    pop_name        TEXT,       -- usually, same as uid
    type            TEXT,       -- substation, tower, other
    city	        INTEGER,    -- foreign key
    city_name	    TEXT,       -- foreign key
    lat             FLOAT,
	long            FLOAT,
    coordx          FLOAT,      -- utm
	coordy          FLOAT,      -- utm
    pole_uid        TEXT,       -- foreign key to poles table
    has_tower       BOOLEAN,    -- Se estiver em torre
    height          FLOAT,      -- Se estiver em torre
    tags            TEXT,
    file_info       TEXT,       -- edital/fase
    file_id         INTEGER,
    PRIMARY KEY(id)
); """

dads = """CREATE TABLE IF NOT EXISTS dads
-- Equipamentos de automação (Distribution Automation - DA(s))
(
    id              INTEGER,
    uid             TEXT,
    type            TEXT,   -- Tipo de automacao
    pop             TEXT,   -- "pop_uid"
    city	        INTEGER,
    city_name	    TEXT,
    lat             FLOAT,
	long            FLOAT,
    coordx          FLOAT,  -- utm
	coordy          FLOAT,  -- utm
    pole_uid        TEXT,   -- "nearsub"
    tags            TEXT,
    file_info       TEXT,   -- edital/fase
    file_id         INTEGER,
    bhn_node        TEXT,   -- uid from bhn_nodes table
    PRIMARY KEY(id)
); """


poles = """CREATE TABLE IF NOT EXISTS poles
-- Postes
(
    id              INTEGER,
    uid             TEXT,
    pole_uid        INTEGER,
    height	        INTEGER,
    pop             TEXT, -- "nearsub"
    city	        INTEGER,
    city_name	    TEXT,
	lat             FLOAT,
	long            FLOAT,
    coordx          FLOAT,
	coordy          FLOAT,
    tags            TEXT,
    file_info       TEXT,
    file_id         INTEGER,
    PRIMARY KEY (id)
); """


towers = """CREATE TABLE IF NOT EXISTS towers
-- Tabela de torres
(
    id              INTEGER,
    uid             TEXT,
    height          FLOAT,       -- presente apenas no primed
    pop             TEXT,       -- "nearsub"
    city	        INTEGER,
    city_name	    TEXT,
    fiber           TEXT,       -- if yes, it is a POP (must be removed)
    coordx          FLOAT,      -- utm
	coordy          FLOAT,      -- utm
    lat             FLOAT,
	long            FLOAT,
    tags            TEXT,
    file_info       TEXT,       -- edital/fase
    file_id         INTEGER,
    PRIMARY KEY(id)
); """


meters = """CREATE TABLE IF NOT EXISTS meters
-- Medidores
-- Tipos de medidores
--  1. monofasico 2f
--  2. monofasico 3f
--  3. bifasico
--  4. trifasico
--  5. trifasico indireto
--  6. trifasico 30(200)
--  7. remoto
(
    id INTEGER,
    uid             TEXT,
    type            TEXT,
    pop             TEXT,       -- "nearsub"
    city	        INTEGER,
    city_name	    TEXT,
    lat             FLOAT,
	long            FLOAT,
    coordx          FLOAT,
	coordy          FLOAT,
    tags            TEXT,
    file_info       TEXT, -- edital/fase
    file_id         INTEGER,
    ami_node        TEXT,   -- uid from ami_nodes table
    PRIMARY KEY(id)
); """



radios = """CREATE TABLE IF NOT EXISTS radios
-- Configurações de radio
(
    id              INTEGER,
    uid             TEXT,
    file_info       TEXT, -- free text description
    file_name       TEXT, -- CONFIGURATION folder
    PRIMARY KEY(id)
); """

projects = """CREATE TABLE IF NOT EXISTS "projects"
(
    id              INTEGER,
    name            TEXT, -- short name given by the user
    description     TEXT, -- free text given by the user
    city          TEXT, -- city is mandatory
    folder          TEXT, -- folder name created by the software
    date            TEXT,
    meters          INTEGER, -- number of meters
    amigs           INTEGER, -- number of ami gateways 
    dads            INTEGER, -- number of dads
    bhns            INTEGER, -- number of backhaul nodes
    saved           INTEGER, -- to db (0=no, 1:ami, 2:bhn, 3:both)
    dependency      TEXT, -- list of projects_ids 
    tags            TEXT,
    PRIMARY KEY (id)
); """

ami_nodes = """CREATE TABLE IF NOT EXISTS ami_nodes
(
    id              INTEGER, 
    uid             TEXT, -- wolfram label + project_id 
    label           TEXT, -- wolfram label
    project_id      INTEGER, -- id of the project that created the radio(s)
    city            TEXT, -- can be retrieved from project ...
    type            TEXT, -- gateway, extensor or meter
    config_uid      TEXT, -- foreign key to radios table
    gateway         TEXT, -- uid (this table) or pop name
    pole_uid        TEXT, -- for gateway and extensor only
    meters          INTEGER, -- number of meters in the same location
    tags            TEXT, -- anything else without a fixed column
    bhn_node        TEXT,   -- uid from bhn_nodes table
    PRIMARY KEY(id)
); """

''' Defines the backhaul topology per pop'''
bhn_nodes = """CREATE TABLE IF NOT EXISTS bhn_nodes
(
    id              INTEGER, 
    uid             TEXT, -- wolfram label + project_id
    label           TEXT, -- as exported by Wolfram 
    project_id      INTEGER, -- id of the project that created the radio(s)
    city          TEXT, -- city can be retrieve from pop, but anyway ...
    pop             TEXT, -- a backhaul belongs to a pop
    next_hop        INTEGER, -- uid of the next hop (parent node)
    path            TEXT, -- list of labels from pop to node
    hops            INTEGER, -- number of hops until the pop
    radios          TEXT, -- number of back-to-back radios in the same location
    pole_uid        TEXT, --  uid of the pole in this location 
    tags            TEXT, -- anything else without a fixed column
    PRIMARY KEY(id)
); """

''' Radio tecnology is related to a link '''
bhn_links = """CREATE TABLE IF NOT EXISTS bhn_links
(
    id              INTEGER, 
    pop             TEXT, -- backhaul is connected to a POP
    project_id      INTEGER, 
    uid_parent      TEXT, -- radio closer to the pop
    uid_child       TEXT, 
    config_uid      TEXT, -- foreign key to radios table
    antennas        TEXT, -- type string as defined by wolfram
    distance        FLOAT, 
    rssi            FLOAT, 
    clearance       FLOAT,
    tags            TEXT,
    PRIMARY KEY(id)
); """


def createTables(**args):
    tables = args.get('tables', ['poles', 'pops', 'dads',
                                 'meters', 'radios', 'imported_files', 
                                 'cities', 'towers', 'ami_nodes', 'bhn_nodes', 'bhn_links', 'projects'])

    with DBWrapper.MySQL(**args) as db:
        for t in tables:
            if args.get('drop', False):
                db.execute(f"DROP TABLE IF EXISTS {t}")   
            try:
                db.execute(eval(t))
            except Exception as e:
                print(f'The {t} was not replaced', str(e))


#-----------------------------------------------------------------
# Used to test the code not used as a Python module
if __name__ == "__main__":

    # DBWrapper.create_database(db_file='teste.db')
    createTables(db_file='teste.db', drop=True, tables={"projects"})
    #createTables(db_file='cisei_teste.db', drop=True, tables={"ami_nodes"})


        

