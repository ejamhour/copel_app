import pandas as pd
import json
import os
import platform
import utm
import CSVExporter
import json
from geopy.distance import geodesic

# Allows create project files from CSV instead of Database

class CSVTranslator(object):
    def __init__(self, **args):
        basedir = os.path.dirname(os.path.realpath(__file__))   
        config_file = os.path.join(os.path.join(basedir,'Configuration'), args.get('config_file', 'convert_csv.json'))

        with open(config_file) as f:
            self.config = json.load(f)
        
        self.csvdir = args.get('csvdir', self.config['folder'])
                   
        self.pid = None
        self.county = None
        self.nodes = {'counties' : None, 'pops': None, 'towers':None, 'dads': None, 'meters': None, 'poles': None, 'amigs' : None, 'bhns': None }
        
    def __str__(self):
        return 'CONFIG PATH: ' + self.config_file

    def __enter__(self):
        return self
    
    def __exit__(self, t, v, tr):
        print('CSVTranslator teminated')

    def import_csv(self, file, _type_, info, **args):
        
        path = os.path.join(self.csvdir, file) 
        if not os.path.isfile(path): raise Exception(f'File {path} not found')          
      
        config = self.config[_type_]
        data_type = { v[0] : v[1] for k,v in config['fields'].items() if v[0] >= 0 }

        fields = [ [v[0], k ] for k,v in config['fields'].items() if v[0] >= 0 ]
        fields.sort()
        fields = [f[1] for f in fields ]

        encoding = config['encoding_Linux'] if platform.system() == 'Linux' else config['encoding_Windows']
        df = pd.read_csv(path, 
            delimiter=config['separator'], index_col=False, 
            decimal=config['decimal'], 
            encoding=encoding,
            dtype= data_type,
            usecols = data_type.keys() )  
        
        print(f'CSV to dataframe completed: {_type_} {file}')

        df.columns = fields
        df['file_info'] = [info] * df.shape[0]
        for k,v in args.items(): 
            df[k] = [v] * df.shape[0]

        if ('uid' in config['fields']) and ('uid' not in fields): self.update_uid(df, config, _type_) 

        if config.get('coord', None) == 'utm': self.update_coord(df)

        if self.nodes[_type_] is None:       
            self.nodes[_type_] = df                          
        else:
            self.nodes[_type_] = self.merge_df(self.nodes[_type_], df)
    
    def merge_df(self, old_df, new_df):
        idx = new_df.index.difference(old_df.index)
        return pd.concat( [old_df, new_df.loc[idx, :] ], axis= 0) 
    
    def update_uid(self, df, config, table ):
        if config['uid'] is not None:
            df['uid'] = df[config['uid']].values
            if[table == 'poles']:
                df['seq_geo'] = df['uid'].values
        else:
            print('uid must be generated')
            ini_id = 0
            df['uid'] = [ f'{table[:3]}_{ini_id + i + 1}' for i in range(df.shape[0]) ] 
    
    def update_coord(self, df) :
        lat = [None]* df.shape[0]
        lon = [None]* df.shape[0]
        for i,row in df.iterrows():
            (lat[i], lon[i]) = utm.to_latlon(row['coordx'], row['coordy'], 22, 'J')
        df['lat'] = lat
        df['long'] = lon

    # Exports dataframes to FOLDER project in CSV format
    def exportCSV(self, folder):

        csv = CSVExporter.CSVExporter(folder, fullpath=True) 
        if self.nodes['counties'] is not None:
            csv.export_counties('cidades.csv', self.nodes['counties'])    
        if self.nodes['pops'] is not None:
            csv.export_pops('subestacoes.csv', self.nodes['pops'])
        if self.nodes['poles'] is not None:
            csv.export_poles('polesnearsub.csv', self.nodes['poles'])
        if self.nodes['towers'] is not None:
            csv.export_towers('torresnearsub.csv', self.nodes['towers'])
        if self.nodes['dads'] is not None:
            csv.export_dads('automacaonearsub.csv', self.nodes['dads'])
        if self.nodes['meters'] is not None:
            csv.export_meters('allmetersnearsub.csv', self.nodes['meters'])
        if self.nodes['bhns'] is not None:
            csv.export_bhnodes('backhaul_nodes.csv', self.nodes['bhns'])
        if self.nodes['amigs'] is not None:
            csv.export_amigs('ami_gateways.csv', self.nodes['amigs'])


# Import Projects from Zabbix TOPOLOGY: must select hosts by POP
class ImportProject():
    def __init__(self, pid, host_prefix ):
        basedir = os.path.dirname(os.path.realpath(__file__))        
        self.zdir = os.path.join( basedir, 'Zabbix', 'TOPOLOGY') 
        self.pdir = os.path.join( basedir, 'PROJECTS', f'PROJECT_{pid}' )

        if not os.path.isdir(self.pdir) : os.makedirs(self.pdir)
        
        self.prefix = host_prefix   
        self.bhnodes = {}
        self.bhlinks = {}    
        
    def __enter__(self):
        return self
    
    def __exit__(self, t, v, tr):
        print('Import Project teminated')

    def readFiles(self):
        path = os.path.join(self.zdir, f'HOSTS_{self.prefix}.txt')
        self.hosts = eval(open(path,'r').read())
        self.LID = { v[0] : k for k,v in p.hosts.items() }
        path = os.path.join(self.zdir, f'TOPO_{self.prefix}.txt')
        self.topo = eval(open(path,'r').read())
        path = os.path.join(self.zdir, f'POS_{self.prefix}.txt')
        self.pos = eval(open(path,'r').read())
        path = os.path.join(self.zdir, f'INFO_{self.prefix}.txt')
        self.info = eval(open(path,'r').read())        
        path = os.path.join(self.zdir, f'DEV_{self.prefix}.txt')
        self.dev = eval(open(path,'r').read())  
        self.net = self.buildTopo()

    def buildTopo(self):

        gemode = ['access-point', 'store-and-forward', 'remote']

        res = {}
        for k,v in self.topo.items():
            host = {}
            if v['GE Device Mode'] not in gemode: continue
            host['gemode'] = v['GE Device Mode']
            host['label'] = self.hosts[k][0]
            host['nic'] = '510' if host['gemode'] == 'access-point' else str(v['Nic ID'])
            host['next_hop'] = v['Gateway ID']
            host['path'] = v['Route'].split(',')
            host['net'] = v['GE Network Name']
            res[k] = host
        
        nic = { (res[k]['nic'],res[k]['net']) : res[k]['label'] for k in res.keys() }

        for k,v in res.items():
            res[k]['next_hop'] = nic.get((v['next_hop'],v['net']), None ) 
            res[k]['path'] = [ nic.get((p, v['net']), None )  for p in v['path'] ]

        return res
    
    def readDescription(self, text):

        f2 = lambda x : ''.join([ s for s in x if s.isdigit() ])
        res = {}
        t = text.replace('\r','')
        t = t.split('\n')
        res['type'] = t[0]
        res['antenna'] =  t[1] if len(t) > 1 else None
        res['pole_uid'] =  f2(t[2]) if len(t) > 2 else ''
        return res

    def buildBHnodes(self):

        topo = self.net

        gemode = ['access-point', 'store-and-forward', 'remote']

        self.bhnodes = []
        
        puid = 1

        for k,v in self.hosts.items(): 
            des = self.readDescription(v[1])           
            if des['type'] not in gemode: continue
            if k not in topo.keys() : continue
            host = {}
            host['id'] = k
            host['label'] = v[0]
            host['type'] = list(p.dev[v[0]].values())[0] if v[0] in p.dev.keys() else 'REP'
            host['alt'] = 7
            host['radio'] =  'GE'
            host['fiber'] = True if host['type'] == 'SUB' else False
            host['pop'] = self.prefix
            host['uid'] = list(p.dev.get(v[0],{}).keys())
            host['radios'] = 1
            host['pole_uid'] = puid if des['pole_uid'] == '' else int(des['pole_uid'])
            if host['pole_uid'] < 10000 : puid += 1
            host['lat'] = float(self.pos[k][0])
            host['lon'] = float(self.pos[k][1])
            host['next_hop'] = 'none' if not topo[k]['next_hop'] else topo[k]['next_hop']
            host['hops'] = len(topo[k]['path'])
            path = topo[k]['path']
            if path == [None] : path = []
            path.reverse() # Python is good, but has issues!!!
            host['path'] = path

            self.bhnodes.append(host)

    def buildBHlinks(self):

        self.bhlinks = []

        for k,v in self.net.items():         
            link = {}
            link['snode'] =  v['next_hop']
            link['dnode'] = v['label']
            s = self.LID[link['snode']] if link['snode'] is not None else None
            d = self.LID[link['dnode']]
            sa = self.readDescription(self.hosts[s][1])['antenna'] if s is not None else ''
            da = self.readDescription(self.hosts[d][1])['antenna'] 

            sa = 'd' if 'YAGI' in sa else 'o'
            da = 'd' if 'YAGI' in sa else 'o'

            ant = {('d','d') : 'dd', ('d','o') : 'd', ('d','o') : 'd', ('o','o') : 'o' }

            dist = round(geodesic( tuple(self.pos[s]), tuple(self.pos[d]) ).km, 3) if s is not None else 0             
            link['pop'] = self.prefix
            link['distance'] = dist
            link['rssi'] = 0
            link['ant'] =  ant[(sa,da)]
            link['los'] = 7
            z = [ self.info[d]['Down Stream Avg RSSI'], self.info[d]['Down Stream Avg LQI'], self.info[d]['Rx Packets'], self.info[d]['Rx Error'] ]
            link['zabbix'] = f'rssi:{z[0]} lqi:{z[1]}, rx:{z[2]} e:{z[3]}'

            self.bhlinks.append(link)

    def exportPoles(self):
        if self.bhnodes == {}:
            print('bhnodes is empty ')
            return
        
        hdic = {
            'uid' : 'UID',
            'height':'ALTURA', 
            'coordx': 'COORD_X', 
            'coordy' : 'COORD_Y', 
            'county':' COD_MUNICIPIO',
            'seq_geo' : 'NUM_SEQ_GEO',
            'county_name' : 'MUNICIPIO',
            'region' : 'FASE', 
            'lat' : 'LAT',
            'long' : 'LON',
            'pop' : 'SUBESTACAO'
            }


        poles  = []
        for h in self.bhnodes:
            pole = {}
            pole['uid']= h['pole_uid']
            pole['height']= 10 
            pole['county']= 1 
            pole['seq_geo']= h['pole_uid']
            pole['county_name']= self.prefix
            pole['lat']= h['lat']
            pole['long']= h['lon']
            pole['pop']= self.prefix
            poles.append(pole)

        df = pd.DataFrame(poles, columns = list(hdic.keys()) )   
        # df = pd.DataFrame(poles, columns = list(hdic.keys()) )   
        

        dir = os.path.join(self.pdir, 'Latlong' )
        if not os.path.isdir(dir) : os.makedirs(dir)

        path = os.path.join(dir, 'polesnearsub.csv' )

        df.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))


    def exportJSON(self):
        if self.bhnodes == {}:
            print('bhnodes is empty ')
            return
        
        dir = os.path.join(self.pdir, 'JSON' )
        if not os.path.isdir(dir) : os.makedirs(dir)

        path = os.path.join(dir, 'bhnodes.json' )
        with open(path, 'w') as f: 
            f.write(json.dumps(self.bhnodes, indent = 5))

        path = os.path.join(dir, 'bhlinks.json' )
        with open(path, 'w') as f: 
            f.write(json.dumps(self.bhlinks, indent = 5))




#-----------------------------------------------------------------     
# Used to test the code not used as a Python module

if __name__ == "__main__":

    # 53 = JAC, 54 = PTO-S, 55 = PTO-A, 56 = PTO-R
    with ImportProject( 56, 'PTO-R') as p:
        p.readFiles()
        p.buildBHnodes()
        p.buildBHlinks()
        p.exportJSON()
        p.exportPoles()





        


        



 


    exit()

    if platform.system() == 'Linux1':
        csvdir = '/media/self/ANIMA/Documentos/EDITAL/Postes_SG_F1'
    else:
        csvdir = '../EDITAL/JACUTINGA'

    pid = 51
    pdir = f'PROJECT_{pid}'

    try:
        with CSVTranslator(csvdir=csvdir) as d:

            d.import_csv('MANFRINOPOLIS.csv', 'poles', 'FASE 1', height=10, pop='P7-001',county=1, region=1)
            d.import_csv('FRANCISCO_BELTRAO.csv', 'poles', 'FASE 1', height=10, pop='P7-001',county=1, region=1)
            d.import_csv('AMPERE.csv', 'poles', 'FASE 1', height=10, pop='P7-001',county=1, region=1)
            d.import_csv('NOVA_ESPERANCA_DO_SUDOESTE.csv', 'poles', 'FASE 1', height=10, pop='P7-001',county=1, region=1)
            d.exportCSV(os.path.join('PROJECTS',pdir,'Latlong'))
    except Exception as e:
        print(e)


        