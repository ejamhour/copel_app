import os

class CSVExporter(object):
    def __init__(self, dir, **args):
        if args.get('fullpath', False) :
            self.dir = dir
        else :
            basedir = os.path.dirname(os.path.realpath(__file__)) 
            self.dir = os.path.join(basedir, dir)

    def export_cities(self, file, df):

        hdic = {
            'code' : 'COD MUNICIPIO',
            'name' : 'MUNICIPIO',
            'uc_count' : 'UC COUNT'
        }

        try:
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("cities exported to file:", file)
        except Exception as e:
            print(e)

    def export_pops(self, file, df):

        hdic = {
            'uid' : 'UID',
            'city_name':'MUNICIPIO', 
            'pop_name': 'SUBESTACAO', 
            'has_tower' : 'TORRE', 
            'height':'ALTURA',
            'coordx' : 'COORD_X',
            'coordy' : 'COORD_Y',
            'lat' : 'LAT',
            'long' : 'LON',
            'pole_uid' : 'NUM_SEQ_GEO' }

        try:
            df['has_tower'] = df['has_tower'].replace({1:'Sim',0:'Nao'})
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("Pops exported to file:", file)
        except Exception as e:
            print(e)

    def export_towers(self, file, df):

        # MUNICIPIO and SUB_MUNICIPIO ara missing (not required?)

        hdic = {
            'uid' : 'UID',
            'height':'ALTURA', 
            'fiber': 'FIBRA', 
            'coordx' : 'COORD_X', 
            'coordy':'COORD_Y',
            'lat' : 'LAT',
            'long' : 'LON',
            'pop' : 'SUBESTACAO' }

        #df2 = df.reset_index()

        try:
            df['fiber'] = df['fiber'].replace({1:'Sim',0:'Nao'})
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("Towers exported to file:", file)
        except Exception as e:
            print(e)

    def export_dads(self, file, df):

        # SUB_MUNICIPIO is missing (not required?)

        hdic = {
            'uid' : 'UID',
            'city':'MUNICIPIO', 
            'type': 'TIPO', 
            'coordx' : 'COORD_X', 
            'coordy':' COORD_Y',
            'lat' : 'LAT',
            'long' : 'LON',
            'pop' : 'SUBESTACAO', 
            'pole_uid' : 'NUM_SEQ_GEO'}

        try:
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("Dads exported to file:", file)
        except Exception as e:
            print(e)

    def export_meters(self, file, df):

        # SUB_MUNICIPIO is missing (not required?)

        hdic = {
            'uid':'UID', 
            'coordx' : 'COORD_X', 
            'coordy':' COORD_Y',
            'lat' : 'LAT',
            'long' : 'LON',
            'type' : 'TIPO',
            'pop' : 'SUBESTACAO' }

        try:
            #df2 = df.reset_index()
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("Meters exported to file:", file)
        except Exception as e:
            print(e)

    def export_poles(self, file, df):

        hdic = {
            'uid' : 'UID',
            'height':'ALTURA', 
            'coordx': 'COORD_X', 
            'coordy' : 'COORD_Y', 
            'city':' COD_MUNICIPIO',
            'pole_uid' : 'NUM_SEQ_GEO',
            'city_name' : 'MUNICIPIO',
            'file_info' : 'FASE', 
            'lat' : 'LAT',
            'long' : 'LON',
            'pop' : 'SUBESTACAO',
            'missing' : 'ELEVATION'
            }

        try:
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("Poles exported to file:", file)
        except Exception as e:
            print(e)

    def export_bhnodes(self, file, df):

        hdic = {
            'uid' : 'UID',
            'city':'MUNICIPIO', 
            'pop': 'SUBESTACAO', 
            'next_hop' : 'GATEWAY',
            'hops' : 'SALTOS',
            'lat' : 'LAT',
            'long' : 'LON',
            'pole_uid' : 'NUM_SEQ_GEO' 
            }

        try:
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("BHN nodes exported to file:", file)
        except Exception as e:
            print(e)

    def export_amigs(self, file, df):

        hdic = {
            'uid' : 'UID',
            'label': 'LABEL',
            'city':'MUNICIPIO', 
            'lat' : 'LAT',
            'long' : 'LON',
            'pole_uid' : 'NUM_SEQ_GEO' 
            }

        try:
            df2 = df.reindex(columns=list(hdic.keys()))
            path = os.path.join(self.dir, file)
            df2.to_csv(path, sep=";", index=False, decimal=".", header=list(hdic.values()))
            print("AMI gateways exported to file:", file)

        except Exception as e:
            pass


#-----------------------------------------------------------------
# Used to test the code not used as a Python module

if __name__ == "__main__":
        pass
