import cisei_lib.cli.planner.PlanLib as pl
import os
from shutil import rmtree

class PlanCLI:

    def __init__(self, **args):
        self.p = pl.PlanLib()
        self.state = {''}
        self.pdl = None

    def __str__(self):
        return 'PROJECT ID: ' + self.p.pid

    def __enter__(self):
        return self
    
    def __exit__(self, t, v, tr):
        print('CLI Planning has exit!')

    def list_projects(self):
         while True:
            aux = input('city name (fist letters): ')
            if not aux: break
            sql = f"SELECT * FROM projects WHERE city LIKE '{aux}%'"
            projs = self.p.db.pdquery(sql)
            if projs.empty:
                print('No project found with this city name')
            else:
                for i in projs.index:
                    print(f" id={projs['id'][i]} city={projs['city'][i]} name={projs['name'][i]}")
                input('\n<ENTER> to return ... ')
                break

    def load_project(self):
         while True:
            aux = input('project id : ')
            if not aux: break
            try:
                self.p.loadproject(aux)
                print(f'PROJECT LOADED:')
                info  = f'''CITY: {self.p.city}\nMETERS: {self.p.count['meters']}\n'''
                info += f'''DADS: {self.p.count['dads']}\nAMI GATEWAYS: {self.p.count['amigs']}\n''' 
                info += f'''BACKHAUL: {self.p.count['bhns']}'''
                print(info)
                input('\n<ENTER> to return ... ')
                break
            except Exception as e:
                print(e)

    def check_state(self):
        self.state = {''}
        try:
            if os.path.isfile( os.path.join(self.p.rundir, 'JSON', 'aminodes.json') ):
                self.state.add('A')
            if os.path.isfile( os.path.join(self.p.rundir, 'JSON', 'bhnodes.json') ):
                self.state.add('B')
            if os.path.isfile( os.path.join(self.p.rundir, 'Report', 'report.htm') ):
                self.state.add('R')  
            if self.p.saved > 0 :
                self.state.add('S')  
        except Exception as e:
            pass
        

    def compile_pdl(self):
        while True:
            print('<ENTER> to return')
            aux = input('filename: ')
            if not aux: break
            self.pdl = os.path.join(self.p.pdir, aux)
            if os.path.isfile(self.pdl):
                with open(self.pdl) as f:
                    try:
                        self.p.compilePDL(f, save=True) 
                        break
                    except Exception as e:
                        print(e)
            else:
                print(f'FILE NOT FOUND: {self.pdl}')
                print('pdl must be in PROJECTS folder')
                self.pdl = None
        
    def remove_project(self):
        if self.p.pid is None:
            print('Please, load a project to be removed first')
        else:
            res = input(f'Do you want to remove project {self.p.pid} (Y/N)?')
            if res.lower()[0] == 'y':
                self.p.removeproject(self.p.pid, dependency=True)
                self.state = {''}
                self.pdl = None
                res = input(f'Do you want to remove the project folder (Y/N)?')
                if res.lower()[0] == 'y':
                    rmtree(self.p.rundir)
                self.p.clearproject()

    # TODO: implement a hierachical menu
    # -- disable options without valid project
    # -- include map generation
    def menu(self):

        state = ''
        self.check_state()
        if 'A' in self.state: state += ' AMI'
        if 'B' in self.state: state += ' BNH'
        if 'R' in self.state: state += ' Report'
        if 'S' in self.state: state += ' Saved'

        print(f'Current projet: {self.p.pid} ({state} )')
        str = '''
            1: List projects by city 
            2: Load a project (using a project id)
            3: Compile PDL (new project from a JSON file)
            4: AMI planning 
            5: BHN planning 
            6: Generate report
            7: Save planning to database
            8: Remove current project (caution)
            9: Exit
        '''
        return str

#---------------------------------------------------------------------
if __name__ == '__main__':

    with PlanCLI() as pcli:
        while True:
            print(pcli.menu())            
            opt = input('CLI option?: ')
            try:
                if opt == '1': pcli.list_projects()
                elif opt == '2': pcli.load_project()
                elif opt == '3': pcli.compile_pdl()
                elif opt == '4': pcli.p.planAMI()
                elif opt == '5': pcli.p.planBHN()
                elif opt == '6': pcli.p.genReport()
                elif opt == '7': pcli.p.savePlanning(bhn=True, ami=True)
                elif opt == '8': pcli.remove_project()
                elif opt == '9': exit()
            except Exception as e:
                print('You need to load a project first!')
                input('\n<ENTER> to return ... ')
    

