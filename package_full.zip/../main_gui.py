from tkinter import messagebox
import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog
import os
import threading
import time
import requests
import webbrowser
import platform
import cisei_lib.globals as g
import cisei_lib.gui.tools.qol as q
import cisei_lib.gui.widgets.wd_new_proj as npw
import cisei_lib.gui.widgets.wd_project as wp
import cisei_lib.gui.widgets.wd_about as aw
import cisei_lib.gui.widgets.wd_import as wdi
import cisei_lib.gui.widgets.wg_footer as footer
import cisei_lib.gui.widgets.wg_simple_table as simpt
import cisei_lib.gui.widgets.wg_button_bar as wbb
import cisei_lib.gui.widgets.wg_progressbar as wpb
import cisei_lib.gui.tools.live_map as lm
import cisei_lib.gui.tools.static_server as ss
import cisei_lib.gui.tools.live_map_writter as lmw

import importlib
import sys

# check for app updates in github
def update_checker():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    if os.path.isdir('updates'):
        sys.path.append('updates')
        up =importlib.import_module('update_cli')
        with up.UpdateAPP() as uapp:
            uapp.check_update(ask=True)


class MainApp:

    def start_threads(self):
        # backend
        self.livemap = lm.LiveMap()

        # frontend
        sserv = ss.StaticServer()
        self.thread2 = threading.Thread(target=sserv.start)
        self.thread2.daemon = True
        self.thread2.start()

    def _on_close(self, event=None):
        resp = messagebox.askyesno(
            "Quit?", "Do you want to terminate the program?")
        if resp == True:
            self.window.destroy()
            os._exit(0)  # effectivelly kill all dependent threads

    def righ_frame_clear(self):
        for wid in self.right_frame.winfo_children():  # clear frame
            wid.destroy()

    def get_projs(self, **kwargs): # E.JESUS CHRIST!!!
        dir = kwargs.get('dir', g.g_abs_path_projects)
        if not os.path.exists(dir):
            os.mkdir(dir)
        projs = os.listdir(dir)
        projs = [proj for proj in projs if proj.startswith("PROJECT_")]
        ret_list = []
        for fold in projs:
            num = fold.split("_")[1]
            if num is not None:
                proj_info = wp.APIProject(int(num))
                if proj_info is not None and hasattr(proj_info, 'db_entry'):
                    db = proj_info.db_entry
                    ret_list.append([db['id'], db['name'], "DB"])
                # else:
                #     ret_list.append(['ext.', fold, "External"])
        self.prjcts = ret_list

    def open_livemap(self):
        webbrowser.open("http://localhost:8037/public")

    def apply_regions_livemap(self):
        def run_in_thread(pbq=None):
            g.g_main_pbq = pbq
            wpb.do_if_has_pb(pbq, wpb.message, "Applying regions")
            wpb.do_if_has_pb(pbq, wpb.progress, 50)
            retcode = requests.get(
                f"{g.g_livemap_api_server_url}apply_reg_tags")
            time.sleep(1.4)
            g.g_main_pbq = None

        pb = wpb.ProgressBarDiag(self.window, "Applying tag regions")
        pb.start_thread(run_in_thread)

    def remove_drop_tags(self):
        def run_in_thread(pbq=None):
            g.g_main_pbq = pbq
            requests.get(f"{g.g_livemap_api_server_url}remove_drop_tags")
            g.g_main_pbq = None
        pb = wpb.ProgressBarDiag(self.window, "Removing tag regions")
        pb.start_thread(run_in_thread)

    def set_proj(self, sel_item=None):
        if sel_item == None:
            messagebox.showerror("No project selected", "No project selected")
            return

        def threadjob(pbq=None):
            pinfo = self.prjcts[sel_item]
            popen_num = pinfo[0]
            self.proj_api = wp.APIProject(popen_num)
            if pinfo[2] != 'DB':
                popen_num = int(pinfo[1].split("_")[1])

            g.g_proj_num = popen_num

            # write the livemap json
            lmwapi = lmw.APLILiveMapWritter(g.g_proj_num)
            g.g_main_pbq = pb.queue
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message, "Copying livemap file")
            lmwapi._load(pbq)
            g.g_main_pbq = None

            # reload sideframe
            self.righ_frame_clear()
            wp.WindowProject(self.right_frame, popen_num)

            print(f"Project set to {g.g_proj_num}")

        pb = wpb.ProgressBarDiag(g.g_main_window, "Opening project")
        pb.start_thread(threadjob)

    def unset_proj(self):
        g.g_proj_num = -1
        self.proj_api = None
        self.table.selection_remove(self.table.focus())
        self.righ_frame_clear()

    def delete_proj(self, indx):
        projnum = self.prjcts[indx][0]
        confirm = messagebox.askyesno(
            "Delete", f"Delete project {projnum}?")
        if confirm:
            def run_in_thread(pbq=None):
                g.g_main_pbq = pbq
                proj_api = wp.APIProject(projnum)
                proj_api.delete()
                self.update_table()
                g.g_main_pbq = None
            pb = wpb.ProgressBarDiag(self.window, "Deleting project")
            pb.start_thread(run_in_thread)

    # Plans AMI
    def gen_report(self):
        if self.proj_api == None:
            messagebox.showinfo(
                "No project selected", "You must open a project before attempting to run this task.")
            return
        try:
            last_rep = self.proj_api.get_path_wolfmath_html_report()

            if last_rep != "":

                cyesno = q.CustomYesNoDialog(g.g_main_window, 'Regenerate or open',
                                             "There is already a report generated for this project, do you want to open it or regenerate/update the report? \n\nNote: if you replanned the project, you should regenerate the report, or else you would be looking at an old report.", "Open", "Regenerate/update")

                if cyesno.user_response:
                    # Open Previous Report button clicked
                    webbrowser.open("file://" + last_rep)
                    return  # skip rest of execution

            self.proj_api.gen_report(self.window)

        except Exception as ex:
            messagebox.showinfo("Info", f"{ex}")

    def map_gen_preplan(self):
        if self.proj_api == None:
            messagebox.showinfo(
                "No project selected", "You must open a project before attempting to run this task.")
            return

        def genamp(pbq=None):
            g.g_main_pbq = pbq
            wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
            try:
                msg = f"Generating pre-plan map for project {self.proj_api.num}..."
                wpb.do_if_has_pb(pbq, wpb.message, msg)
                mappath = self.proj_api.gen_unplanned_map()
                wpb.do_if_has_pb(pbq, wpb.message,
                                 f"Successfully generated map")
                if mappath != "":
                    webbrowser.open(mappath)
            except Exception as ex:
                wpb.do_if_has_pb(pbq, wpb.message, f"Genmap problem")
                messagebox.showerror("Genmap problem", f"{ex}")

        pb = wpb.ProgressBarDiag(root, "Generating pre-plan map")
        pb.start_thread(targ=genamp)

        time.sleep(1.0)  # give user time to read dialog final msg
        g.g_main_pbq = None

    def map_gen_plan(self, sepgateway=False):
        if self.proj_api == None:
            messagebox.showinfo(
                "No project selected", "You must open a project before attempting to run this task.")
            return

        sepgw = ''
        if sepgateway is True:
            sepgw = simpledialog.askstring(
                "Planned map (AMI)", "Planned map, with separated layers\nfor the following gateways (e.g. 'g1 g2'):", parent=g.g_main_window)
            if sepgw is None:
                return

        def genamp(pbq=None):
            g.g_main_pbq = pbq
            wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
            try:
                msg = f"Generating planned map for project {self.proj_api.num}..."
                wpb.do_if_has_pb(pbq, wpb.message, msg)

                self.proj_api.gen_planned_map(sepgw)
            except Exception as ex:
                wpb.do_if_has_pb(pbq, wpb.message, f"Genmap problem")
                messagebox.showerror("Genmap problem", f"{ex}")

        pb = wpb.ProgressBarDiag(root, "Generating planned map")
        pb.start_thread(targ=genamp)

        time.sleep(1.0)  # give user time to read dialog final msg
        g.g_main_pbq = None

    def __init__(self, window):
        # self.set_workdir()
        self.window = window
        g.g_main_window = window
        self.proj_api = None
        self.proj_data = {}
        self.start_threads()

        self.window.minsize(370, 300)
        self.window.geometry('800x600')
        self.window.title(g.g_program_name)
        self.createMenubar()

        # bbardata = [("", self.open_livemap, "./icons/preferences-desktop-locale.png", "Open preplan map"),
        #             ("", self.apply_regions_livemap,
        #              "./icons/dialog-apply.png", "Apply regions of livemap"),
        #             ("", self.remove_drop_tags, "./icons/edit-delete.png", "Remove all 'drop' tags for current project on livemap")]
        # topbar = wbb.CustomButtonBar(self.window, bbardata)
        # topbar.pack(fill='x')
        # self.topbar = topbar
        # lmwritter = lmw.WidgetLiveMapWritter(topbar.frame)
        # lmwritter.pack(side="left", padx=25)

        self.table = None
        self.prjcts = None
        self.get_projs()

        pw = tk.PanedWindow(self.window, orient=tk.HORIZONTAL)
        pw.pack(fill=tk.BOTH, expand=1)

        self.left_frame = tk.Frame(self.window, width=80)
        self.right_frame = tk.Frame(pw)

        self.proj_tuples = [tuple(prj) for prj in self.prjcts]

        context_cmds = [("Delete", self.delete_proj)]

        self.table = simpt.TableWidget(
            self.left_frame, [["ID", 30], ["name", 90], ["status", 60]], self.proj_tuples, cb_func=self.set_proj, context_commands=context_cmds)
        self.table.pack(fill="both", side="left", padx=10, pady=5, expand=True)

        scrollbar = ttk.Scrollbar(
            self.left_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")

        pw.add(self.left_frame)
        pw.add(self.right_frame)

        footer.FooterWidget(
            self.window, {"version": g.g_prog_version})

        self.window.protocol("WM_DELETE_WINDOW", self._on_close)

        if q.has_db_file() is not True:
            messagebox.showinfo(
                "No database", "No database found.\n Make sure to import data before attempting to create a new project.")
        # q.center_window(self.window)

    def update_table(self):
        self.righ_frame_clear()
        self.get_projs()
        self.table.reload(self.prjcts)

    def createMenubar(self):
        menubar = tk.Menu(self.window,
                          activebackground='white', activeforeground='black')

        # ---------------- import
        m_import = tk.Menu(menubar, tearoff=0, foreground='black')
        menubar.add_cascade(label="Import", menu=m_import)
        m_import.add_command(
            label="Import CSV", command=lambda: wdi.WindowImport(root=self.window), accelerator="Ctrl+I")

        m_import.add_command(
            label="Import Zabbix (Missing)", command=lambda: messagebox.showinfo("Under development", "TODO: missing implementation"))

        m_import.add_separator()
        # m_import.add_command(
        #     label="View Import configuration", command=lambda: q.crossplat_open_file(os.path.normpath("./Configuration/import_csv.json")))
        m_import.add_command(
            label="View configuration files", command=lambda: q.crossplat_open_folder(g.g_abs_path_configuration))
        m_import.add_separator()

        m_import.add_command(label="Exit", command=self._on_close,
                             accelerator="Ctrl+Q")

        # ---------------- project
        m_project = tk.Menu(menubar, tearoff=0, foreground='black')
        menubar.add_cascade(label="Project", menu=m_project)

        def newproj_seq():
            npwin = npw.WindowNewProject(self.window)
            npwin.wait_window()
            new_proj_id = npwin.ret
            self.update_table()

            for i, proj in enumerate(self.prjcts):
                if proj[0] == new_proj_id:
                    # self.table.selection_set()
                    self.table.selection_set(self.table.get_children()[i])
                    self.set_proj(i)
                    return

        def open_proj():
            try:
                indx = self.table.get_sel_index()
            except Exception as ex:
                messagebox.showinfo(
                    "No project selected", "To open a project, make sure to select one project on the left-side list. You can also double-click it to open.")
                return
            self.set_proj(indx)

        m_project.add_command(label="New", command=newproj_seq)
        m_project.add_command(label="Open", command=open_proj)
        m_project.add_command(
            label="Delete", command=lambda *args: self.delete_proj(self.table.get_sel_index()))
        m_project.add_command(label="Close", command=self.unset_proj)
        rep_submenu = tk.Menu(m_project, tearoff=False)
        m_project.add_cascade(label="Report", menu=rep_submenu)

        def todo():
            messagebox.showinfo("todo", "missing")

        rep_submenu.add_command(
            label="Export HTML Report", command=self.gen_report)
        # rep_submenu.add_command(label="Export HTML", command=todo)
        # rep_submenu.add_command(label="Export Pre-Planned", command=todo)

        # ---------------- map
        m_project = tk.Menu(menubar, tearoff=0, foreground='black')
        menubar.add_cascade(label="Maps", menu=m_project)
        m_project.add_command(label="Pre-Planned",
                              command=lambda: self.open_livemap())
        m_project.add_command(label="Pre-Planned (export)",
                              command=self.map_gen_preplan)
        m_project.add_command(label="Planned", command=self.map_gen_plan)
        m_project.add_command(label="Planned AMI",
                              command=lambda: self.map_gen_plan(True))

        # ---------------- about/help
        m_help = tk.Menu(menubar, tearoff=0)
        m_help.add_command(
            label="About", command=lambda: aw.AboutWindow(self.window))
        # m_help.add_checkbutton(label="Detachable")
        menubar.add_cascade(label="Help", menu=m_help)

        # ============= finish menu
        self.window.config(menu=menubar)

        self.window.bind("<Control-q>", self._on_close)
        self.window.bind(
            "<Control-i>", lambda *args: wdi.WindowImport(root=self.window))


try:

    # TODO: include update verification
    # clear processes with ports left open
    # q.kill_process_by_port(8037)
    update_checker()
    q.delete_file_if_exists(g.g_abs_path_map_memory)

    root = tk.Tk()
    # root.attributes("-fullscreen", True)

    if platform.system() == 'Linux':
        root.attributes('-zoomed', True)
    elif platform.system() == 'Windows':
        root.state('zoomed')

    app = MainApp(root)
    root.mainloop()

except Exception as e:
    messagebox.showerror("An error occurred", f"An error occurred:\n{e}")
    os._exit(0)  # must force exit, because of backend servers
