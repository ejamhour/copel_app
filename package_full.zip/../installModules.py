import pip
import sys
import subprocess as sp
import importlib

failed = []

def install(package):
    pip.main(['install', package])

def sp_install(package):
    try:
        res = sp.check_call([sys.executable, '-m', 'pip', 'install', package], stderr=sp.DEVNULL)
    except Exception as e:
        failed.append(package)
    
def install_all_packages(modules_to_try):
    for module in modules_to_try:
        try:
            importlib.import_module(module) 
            print(f'PACKAGE {module} OK')       
        except ImportError as e:
            print(e)
            sp_install(e.name)
        except Exception as e:
            print(e)



modules = { 'folium', 'flask', 'pandas', 'tkinter', 'plyer',  'whatchdog', 'waitress', 'pywin32', 'Pillow', 'utm', 'geopy'}
install_all_packages(modules)

if len(failed) > 0:
    print(f'ERROR: Some packet could not be installed!')
    for f in failed: 
        print(f'MUST install PACKAGE: {f} manually!')