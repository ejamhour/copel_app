import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import cisei_lib.globals as g
import wg_footer as footer
import wg_stringvar_from as svf
import wg_progressbar as wpb
import cisei_lib.gui.tools.qol as q
import time
import os
import webbrowser
import pandas as pd
import cisei_lib.gui.tools.Map as Map
import ast  # convert tags from str to dict
import numpy as np  # split batches for executemany
from plyer import notification
import re
import cisei_lib.cli.planner.DBWrapper as dbw
import cisei_lib.cli.planner.PlanLib as pl


class APIProject():
    def fetch_proj_folder(self):
        proj_folder = os.path.join(g.g_abs_path_projects, f'PROJECT_{self.num}')
        if os.path.exists(proj_folder):
            self.project_folder = proj_folder

    def gen_unplanned_map(self):
        if hasattr(self, "db_entry"):
            m = Map.Map()
            # TODO: only gen map if project is database
            with pl.PlanLib(db_file=g.g_database_file) as p:
                # p.loadproject(self.num)
                with open(self.pdl_path) as f:
                    p.compilePDL(f, save=False)
                # mostrar elementos nao planejados
                self.unp_map_path = m.plot_preplan(
                    p.nodes, self.num, p.db.connection)
                return self.unp_map_path
        return ""

    def gen_planned_map(self, str_sep_gateways):
        try:
            sep_gws = [gw.upper() for gw in str_sep_gateways.replace(
                ",", "").split()] if str_sep_gateways != "" else []
            m = Map.Map()
            m.plot_json_plan(self.num, True, sep_gws)
        except Exception as e:
            print(f"gen_planned_map> ERROR: {e}")
            messagebox.showerror("ERROR", f"ERROR:\n{e}")

    def check_has_planned_map(self):
        if self.project_folder != "":
            self.map_folder = os.path.join(self.project_folder, 'MAP')
            self.static_map_filepath = os.path.join(self.map_folder, f'MAP_PROJECT_{self.num}.html')
            if os.path.exists(self.map_folder):
                if os.path.isfile(self.static_map_filepath):
                    return True
        return False

    # def fetch_json_info(self):
    #     self.project_json_folder = f"{g.g_workdir}/{g.g_projects_folder}/PROJECT_{self.num}"
    #     if self.project_folder != "":
    #         pass
    #         # TODO

    def fetch_db_info(self):
        # qries = DBWrapper.MyQUeries()
        with dbw.MySQL() as db:

            if not os.path.isfile(g.g_abs_path_db): # E.J.
                messagebox.Message("There is no database.\nPlease, create a database using the import menu.")
                return
            try:
                df = pd.read_sql(f"select * from projects where id == {self.num};",
                                db.connection)
                rslen = len(df)
                if rslen > 0:
                    self.db_entry = df.to_dict(orient='records')[0]
            except:
                messagebox.Message("The database is empty.\nPlease, create a database using the import menu.")


    def fetch_pdl_file(self):
        if not hasattr(self, 'db_entry'):
            return
        pdl_path = os.path.normpath(
            f"{g.g_workdir}/{g.g_projects_folder}/{q.sanitize_string_for_filename(self.db_entry['name'])}.json")
        if os.path.isfile(pdl_path):
            self.pdl_path = pdl_path
        else:
            self.pdl_path = ""

    def remove_drop_tags(self):
        if not hasattr(self, "db_entry"):
            raise Exception(
                "Can't remove drop tags, no database attribute loaded for project object")
        updated_entries = 0
        full_poles = None
        with dbw.MySQL() as db:  # get poles by city's pop (by city, get pops, by pops get poles)
            sqlqry = f"select A.* from poles as A inner join (select uid from pops where city_name = '{self.db_entry['city']}') as B on A.pop = B.uid where A.tags like '%drop%';"
            full_poles = pd.read_sql(sqlqry,
                                     db.connection)
        if full_poles is None:
            print("no poles found to update")
            raise ValueError("no poles found to update")

        qry_data = []
        print(
            f"Removing drop tag... Checking {len(full_poles)} entries of poles...")
        ttotal = len(full_poles)
        for ti, pole in full_poles.iterrows():
            pr = wpb.lazy_prog_lerp(0, 99, ti/ttotal)
            wpb.do_if_has_pb(g.g_main_pbq, wpb.progress, pr)
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message,
                             f'Fetching tags on database\n({ti}/{ttotal}) {pr}...')

            p_uid = pole['uid']
            tags_str = pole['tags']
            tags_dict = ast.literal_eval(tags_str)
            if 'drop' in tags_dict:
                del tags_dict['drop']
                updated_entries += 1
            else:
                continue
            tags_str = str(tags_dict)
            qry_data.append((tags_str, p_uid))
        # divide into batches to allow progress estimation
        batches = np.array_split(qry_data, 10)
        total_processes = 0
        ttotal = len(batches)
        for ti, batch in enumerate(batches):
            pr = wpb.lazy_prog_lerp(0, 99, ti/ttotal)
            wpb.do_if_has_pb(g.g_main_pbq, wpb.progress, pr)
            wpb.do_if_has_pb(g.g_main_pbq, wpb.message,
                             f'Updating database\n({ti}/{ttotal}) {pr}...')

            with dbw.MySQL() as db:
                try:
                    db.executemany(
                        f"UPDATE poles SET tags = ? WHERE uid = ?;", batch)
                    total_processes += len(batch)
                except Exception as e:
                    print(f'Fail on batch of update qrys', str(e))
        print(f"finish apply_Reg_Tags [TOTAL: {total_processes}]")
        return total_processes, len(full_poles)

    def plan_ami(self, root=None):
        if not hasattr(self, "db_entry"):
            messagebox.showerror("Error",
                                 f"Can't proceed, no database entry for project {self.num}")
            return

        num = self.db_entry['id']

        def plan_ami_th(pbq=None):
            with pl.PlanLib(db_file=g.g_database_file) as p:
                g.g_main_pbq = pbq
                st = time.time()
                try:
                    wpb.do_if_has_pb(pbq, wpb.visible_logbox, True, True)
                    wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
                    wpb.do_if_has_pb(pbq, wpb.message,
                                     f"Planning AMI, standby.")
                    p.loadproject(num)
                    p.planAMI()
                    wpb.do_if_has_pb(pbq, wpb.message,
                                     f"AMI Planning finished")
                    duration = time.time() - st
                    dh, dm, ds = q.hms_from_secs(duration)
                    notification.notify(
                        title="Plan AMI completed",
                        message=f"AMI Planning for project {num} finished\nDuration {dh}h {dm}m {ds}s",
                        timeout=10
                    )
                    print("Finish plan AMI")
                    time.sleep(1.5)  # give user time to read dialog final msg
                    g.g_main_pbq = None
                except Exception as e:
                    messagebox.showerror(
                        "Fail", f"An error occurred while attempting to plan AMI for:\n{e}")
        logpath = os.path.normpath(f"{self.project_folder}/logAMI.txt")
        pb = wpb.ProgressBarDiag(root, "Planning AMI", tail_file=logpath)
        pb.start_thread(targ=plan_ami_th)

    def plan_bh(self, root=None):
        if not hasattr(self, "db_entry"):
            messagebox.showerror("Error",
                                 f"Can't proceed, no database entry for project {self.num}")
            return
        num = self.db_entry['id']

        optparams = {
            "unconnected_biggest": 0,
            "prog": 0,
            "pbqueue": None
        }

        def log_update_cb(log_line, args):
            match = re.search(r'Unconnected=(\d+)', log_line)
            if match:

                number = int(match.group(1))

                optnum = args["unconnected_biggest"]
                if optnum < number:
                    optnum = number
                    args["unconnected_biggest"] = number
                prog = int(((optnum-number)/optnum)*100)
                wpb.do_if_has_pb(args["pbqueue"], wpb.progress, prog)
                # print(f"BHN progress {prog}%")

        def plan_bh_th(pbq=None):
            with pl.PlanLib(db_file=g.g_database_file) as p:
                st = time.time()
                try:
                    wpb.do_if_has_pb(pbq, wpb.visible_logbox, True, True)
                    # wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
                    wpb.do_if_has_pb(pbq, wpb.message,
                                     f"Planning Backhaul, standby.")
                    p.loadproject(num)
                    p.planBHN()
                    print("Finish plan BH")
                    duration = time.time() - st
                    dh, dm, ds = q.hms_from_secs(duration)
                    notification.notify(
                        title="Plan Backhaul completed",
                        message=f"Backhaul Planning for project {num} finished\nDuration {dh}h {dm}m {ds}s",
                        timeout=10
                    )
                    wpb.do_if_has_pb(pbq, wpb.message,
                                     f"Backhaul Planning finished")
                    time.sleep(1.5)  # give user time to read dialog final msg

                except Exception as e:
                    messagebox.showerror(
                        "Fail", f"An error occurred while attempting to plan Backhaul for:\n{e}")
        logpath = os.path.normpath(f"{self.project_folder}/logBHN.txt")
        pb = wpb.ProgressBarDiag(root, "Planning BH", tail_file=logpath,
                                 log_cb_func=log_update_cb, log_cb_params=optparams)
        optparams["pbqueue"] = pb.queue
        pb.start_thread(targ=plan_bh_th)

    def gen_report(self, root=None):
        if not hasattr(self, "db_entry"):
            messagebox.showerror("Error",
                                 f"Can't proceed, no database entry for project {self.num}")
            return

        num = self.db_entry['id']

        # check if has any planning
        bhnpath = os.path.normpath(f'{self.project_folder}/JSON/bhnodes.json')
        amipath = os.path.normpath(f'{self.project_folder}/JSON/aminodes.json')

        existbhn = os.path.exists(bhnpath)
        existami = os.path.exists(amipath)

        if not existami and not existbhn:
            raise Exception(f"No planning found for project {self.num}")

        def gen_rep_th(pbq=None):
            with pl.PlanLib(db_file=g.g_database_file) as p:
                g.g_main_pbq = pbq
                st = time.time()
                try:
                    wpb.do_if_has_pb(pbq, wpb.visible_logbox, True, True)
                    wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
                    wpb.do_if_has_pb(pbq, wpb.message,
                                     f"Generating report, standby.")
                    p.loadproject(num)
                    p.genReport()
                    wpb.do_if_has_pb(pbq, wpb.message, f"Report finished")
                    duration = time.time() - st
                    dh, dm, ds = q.hms_from_secs(duration)
                    notification.notify(
                        title="Report completed",
                        message=f"Report for project {num} finished\nDuration {dh}h {dm}m {ds}s",
                        timeout=10
                    )
                    print("Finish Report")
                    time.sleep(1.0)  # give user time to read dialog final msg
                    g.g_main_pbq = None
                    rep_expec_path = f"{self.project_folder}/Report/report.htm"
                    self.fetch_wolfmath_hmtl_report()  # immediatly update api
                    webbrowser.open("file://" + rep_expec_path)
                except Exception as e:
                    messagebox.showerror(
                        "Fail", f"An error occurred while attempting to Gen report:\n{e}")
        logpath = os.path.normpath(f"{self.project_folder}/logreport.txt")
        pb = wpb.ProgressBarDiag(root, "Generating report", tail_file=logpath)
        pb.start_thread(targ=gen_rep_th)

    def compile_proj(self, root=None):
        def compile_th(pbq=None):
            g.g_main_pbq = pbq
            wpb.do_if_has_pb(pbq, wpb.visible_bar, False)
            try:
                msg = f"Compiling project {self.db_entry['id']} ({self.db_entry['city']})..."
                wpb.do_if_has_pb(pbq, wpb.message, msg)

                with pl.PlanLib(db_file=g.g_database_file) as p:
                    with open(self.pdl_path) as f:
                        p.compilePDL(f, save=True)
                        wpb.do_if_has_pb(pbq, wpb.message,
                                         f"Successfully compiled")

            except Exception as ex:
                wpb.do_if_has_pb(pbq, wpb.message, f"Compile problem")
                messagebox.showerror("Compile error", f"{ex}")

        pb = wpb.ProgressBarDiag(root, "Compiling project")
        pb.start_thread(targ=compile_th)

        time.sleep(1.0)  # give user time to read dialog final msg
        g.g_main_pbq = None

        # with pl.PlanLib(db_file=g.g_database_file) as p:
        #     try:
        #         p.loadproject(num)
        #     except Exception as e:
        #         messagebox.showerror(
        #             "Fail", f"An error occurred while attempting to plan AMI for:\n{e}")

    def saveplan(self):
        try:
            with pl.PlanLib(db_file=g.g_database_file) as p:
                num = self.db_entry['id']
                p.loadproject(num)
                p.savePlanning(bhn=True, ami=True)
        except Exception as ex:
            print('Save error', ex)

    def delete(self):
        if not hasattr(self, "db_entry"):
            raise Exception(
                "Can't remove project, no database attribute loaded for project object")
        num = self.db_entry['id']
        with pl.PlanLib(db_file=g.g_database_file) as p:
            try:
                p.loadproject(num)
                p.removeproject(num, dependency=True)
                removed, total = self.remove_drop_tags()
                print(
                    f"[REGIONS] Removed {removed} regions (total analyzed poles {total})")
            except Exception as e:
                messagebox.showerror(
                    "Delete fail", f"An error occurred while attempting to delete a project on database:\n{e}")
        print(f"Project {num} removed")

    def fetch_wolfmath_hmtl_report(self):

        if self.project_folder != "":
            html_report = os.path.normpath(f"{self.project_folder}/Report/report.htm")
            if os.path.exists(html_report):
                self.html_report = html_report
                

    def get_path_wolfmath_html_report(self):
        if hasattr(self, "html_report"):
            return self.html_report
        return ""

    def __init__(self, proj_num):
        self.num = proj_num
        self.project_folder = ""
        self.fetch_proj_folder()
        # self.fetch_json_info()
        self.fetch_wolfmath_hmtl_report()
        self.fetch_db_info()
        self.fetch_pdl_file()
        self.has_static_map = self.check_has_planned_map()


class WindowProject():
    # def open_unplanned_static_map(self):
    #     mappath = self.api.gen_unplanned_map()
    #     if mappath != "":
    #         webbrowser.open(mappath)

    # def open_planned_static_map(self):
    #     if self.api.has_static_map:
    #         webbrowser.open(self.api.static_map_filepath)
    #     else:
    #         messagebox.showinfo(
    #             "Attention", "This project has no static map yet.")

    def open_pdl(self):
        if self.api.pdl_path != "":
            q.crossplat_open_file(self.api.pdl_path)
        else:
            messagebox.showinfo(
                "Attention", f"Can't find PDL for project {self.api.num}")

    def load_data(self):
        if hasattr(self.api, "db_entry"):
            self.sv_name.set(self.api.db_entry["name"])
            self.sv_desc.set(self.api.db_entry["description"])
            self.sv_city.set(self.api.db_entry["city"])
            self.sv_creation_date.set(str(self.api.db_entry["date"]))
            self.sv_meters.set(self.api.db_entry["meters"])
            self.sv_amigs.set(self.api.db_entry["amigs"])
            self.sv_dads.set(self.api.db_entry["dads"])
            self.sv_bhnodes.set(self.api.db_entry["bhns"])
            self.sv_saved.set(str(self.api.db_entry["saved"]))

    def create(self, prj_num, callback=None):
        # self.window = tk.Toplevel()

        footer.FooterWidget(self.window, {
            "version": g.g_prog_version,
            "db": g.g_database_file,
            "project": f"{prj_num}"
        })

        if hasattr(self.window, "title"):
            self.window.minsize(370, 300)
            self.window.title(f"Project {prj_num} - {g.g_program_name}")

        lbl_about = tk.Label(self.window, text="Planning")
        lbl_about.pack(anchor="w", padx=10, pady=2)

        center_frame = tk.LabelFrame(self.window, text="Project information")
        center_frame.pack(side="top", padx=10, pady=10,
                          fill="both", expand=True)

        self.notebook = ttk.Notebook(center_frame)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)

        f1 = tk.Frame(self.notebook)
        f1.pack(side="top", padx=10, pady=10, fill="both", expand=True)

        f2 = tk.Frame(self.notebook)
        f2.pack(side="top", padx=10, pady=10, fill="both", expand=True)

        self.notebook.add(f1, text='Actions')
        self.notebook.add(f2, text='Details')

        self.sv_name = tk.StringVar()
        self.sv_desc = tk.StringVar()
        self.sv_city = tk.StringVar()
        self.sv_creation_date = tk.StringVar()
        self.sv_meters = tk.StringVar()
        self.sv_amigs = tk.StringVar()
        self.sv_dads = tk.StringVar()
        self.sv_bhnodes = tk.StringVar()
        self.sv_saved = tk.StringVar()

        form_params = [
            ("Name", "", self.sv_name),
            ("Description", "", self.sv_desc),
            ("City", "", self.sv_city),
            ("Creation Date", "", self.sv_creation_date),
            ("Meters", "", self.sv_meters),
            ("AMI Gateways", "", self.sv_amigs),
            ("Aut. Devices", "", self.sv_dads),
            ("BH Nodes", "", self.sv_bhnodes),
            ("Saved", "", self.sv_saved)]
        self.form = svf.StringvarForm(f2, form_params, state="readonly")
        self.form.pack()
        self.load_data()

        bottom_frame = tk.Frame(f2, padx=10, pady=10)
        bottom_frame.pack(fill="x", side="bottom")
        self.form.pack()

        # bt1 = tk.Button(bottom_frame, text="Planned Map",
        #                 command=self.open_planned_static_map)
        # bt1.pack(side="left", padx=10, pady=2)
        # q.Tooltip(bt1, f"Open the planned map for project {prj_num}")

        # bt2 = tk.Button(bottom_frame, text="Export Pre-plan Map",
        #                 command=self.open_unplanned_static_map)
        # bt2.pack(side="left", padx=10, pady=2)
        # q.Tooltip(
        #     bt2, f"Exports and open the pre-plan map for project {prj_num}")

        # second form =========================================================
        # genmapframe = tk.LabelFrame(f1, text="Planned Map")
        # genmapframe.pack(padx=10, pady=10)
        # # TODO: add suggestion later
        # self.sv_groups = tk.StringVar()
        # genmapparams = [
        #     ("Separate AMI elem. by gateways", "Notice, if your project contains AMI elements, you may optionally specify in this field, gateways for visualizing separately.\n\ne.g. \"g1 G2 g3\"", self.sv_groups)]
        # self.genmaop_sf = svf.StringvarForm(
        #     genmapframe, genmapparams, state="normal")
        # self.genmaop_sf.pack()
        # # q.Tooltip(genmapframe, "")
        # ok_button = ttk.Button(genmapframe, text="Generate",
        #                        command=lambda: self.api.gen_planned_map(self.sv_groups.get()))
        # ok_button.pack(pady=10, padx=10, side="left")
        # q.Tooltip(ok_button, f"Generate the planned map for project {prj_num}")

        actionsframe = tk.LabelFrame(f1, text=f"Project {prj_num}")
        actionsframe.pack(padx=10, pady=10, fill='x')
        q.IconButtom(actionsframe,
                     text="Edit .PDL",
                     compound="left",
                     image=get_icon('draw-freehand'),
                     tooltip="Open text editor for the .PDL file of this project",
                     command=self.open_pdl).pack(pady=10, padx=5, side="left", anchor='n')

        btcompile = ttk.Button(actionsframe, text="Compile",
                               command=lambda: self.api.compile_proj(self.window))

        btcompile.pack(pady=10, padx=5, side="left")
        btplanami = ttk.Button(actionsframe, text="Plan AMI",
                               command=lambda: self.api.plan_ami(self.window))
        btplanami.pack(pady=10, padx=5, side="left")
        btplanbh = ttk.Button(actionsframe, text="Plan BHN",
                              command=lambda: self.api.plan_bh(self.window))
        btplanbh.pack(pady=10, padx=5, side="left")

        q.IconButtom(actionsframe,
                     text="Save",
                     compound="left",
                     image=get_icon('document-save'),
                     tooltip="Save the project in the database",
                     command=self.api.saveplan).pack(pady=10, padx=5, side="left")

        if hasattr(self.window, "title"):
            q.center_window(self.window)
            if callback != None:
                self.callback = callback
                self.window.protocol("WM_DELETE_WINDOW", self.on_close)

    def __init__(self, root, proj_num, callback=None):
        try:
            self.window = root
            self.api = APIProject(proj_num)
            self.create(proj_num, callback=callback)
        except Exception as e:
            messagebox.showerror(
                "Project Error", f"Project Window error:\n{e}")

    def on_close(self):
        self.callback()
        self.window.destroy()


def print_smth():
    print("Window exit, this function is called")

# These are resource icons (not mapres icons)
def get_icon(name, ext=True):
    if ext:
        return os.path.join(g.g_img_icons, name + '.png')
    else:
        return os.path.join(g.g_img_icons, name )

if __name__ == "__main__":
    try:
        root = tk.Tk()
        WindowProject(root, 777, callback=print_smth)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("An error occurred", f"An error occurred:\n{e}")
