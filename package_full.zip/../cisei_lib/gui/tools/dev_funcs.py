# delete all projects from database

import cisei_lib.cli.planner.DBWrapper as dbw
import cisei_lib.gui.tools.qol as q
import pandas as pd
from tkinter import messagebox
import globals as g
import cisei_lib.gui.widgets.wd_project as wp
import cisei_lib.gui.widgets.wg_progressbar as wpb
import tkinter as tk
import time
def delete_all_projs():
    try:
        if q.has_db_file() is True:
            confirm = messagebox.askyesno(
                "Delete all projects", f"Are you sure you wish to delete all projects from database?")
            if confirm:
                projects = {}
                with dbw.MySQL() as db:
                    df = pd.read_sql(f"select * from projects;",
                                    db.connection)
                    rslen = len(df)
                    if rslen > 0:
                        print(f"{rslen} projects found... Deleting")
                        projects = df.to_dict(orient='records')
                    else:
                        raise Exception("delete_all_projs> Project table already empty")

                

            
                def run_in_thread(pbq=None):
                    total = len(projects)
                    for i, p in enumerate(projects):
                        projnum = p['id']
                        wpb.do_if_has_pb(pbq, wpb.message, f"Deleting proj {projnum} ({i}/{total})")
                        wpb.do_if_has_pb(pbq, wpb.progress, i/total)
                        g.g_main_pbq = pbq
                        proj_api = wp.APIProject(projnum)
                        proj_api.delete()
                        g.g_main_pbq = None
                        time.sleep(0.2)
                pb = wpb.ProgressBarDiag(g.g_main_window, "Deleting all projects")
                pb.start_thread(run_in_thread)
    except Exception as ex:
        messagebox.showerror("Error", f"{ex}")
                     
root = tk.Tk()

bt = tk.Button(root,text="Dele all projs", command=delete_all_projs)
bt.pack(padx=10,pady=10)
root.title("Test dele all projects")
g.g_main_window = root
root.mainloop()