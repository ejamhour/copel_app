# CTRL + SHIFT + N
# Copyright (c) 2021, 2022, 2023, COPEL DIS.
# July 2023

import sqlite3
import os
import pandas as pd
from sqlite3 import Error
import os
import cisei_lib.globals as g

BASE_FILE = g.g_database_file
BASE_DIR = g.g_datadir
DB_LOCATION = os.path.join(BASE_DIR, BASE_FILE)


# Creates a new empty database
def set_default_DB(db_file):
    global DB_LOCATION 
    DB_LOCATION = os.path.join(BASE_DIR, db_file)

class MyQUeries:
    # def __init__:

    def qry_plan_elements_experimental(self):
        # its experimental because, its not our planning, its an imported planning from another tool
        qry = f"select * from elements;"
        return qry

    def qry_plan_element_by_nic_experimental(self, nic):
        # its experimental because, its not our planning, its an imported planning from another tool
        qry = f"select * from elements where nic = '{nic}';"
        return qry

    def qry_dads_by_city(self, city_name):
        qry = f"select * from dads as t1 inner join (select * from pops where city_name = '{city_name}') as t2 on t1.pop = t2.pop_name;"
        return qry

    def qry_meters_by_city(self, city_name):
        qry = f"select * from meters as t1 inner join (select * from pops where city_name = '{city_name}') as t2 on t1.pop = t2.pop_name;"
        return qry

    def qry_meters_by_city_STUB(self, city_name):
        # FIXME: remove? looks like it's doing nothing.
        qry = f"select * from meters where pop = '{city_name}';"
        return qry

    def qry_pop_by_city_STUB(self, city_name):
        # FIXME: This is misleading, the city_name is not always the substation name, this is a example_stub
        qry = f"select * from pops where city_name = '{city_name}';"
        return qry

    def qry_pole_info(self, pole_id):
        qry = f"select * from poles where id = {pole_id};"
        return qry

    def qry_cities_from_poles_table(self):
        qry = "select distinct city_name as cn from poles order by cn asc;"
        return qry

    # Return poles by city name.Optionally, you can refer to a rectangle to filter
    def qry_poles_by_city(self, city, ax=0, ay=0, bx=0, by=0):
        qry = f"""select coordx as x, coordy as y, pole_uid as sg, id from poles where city_name = '{city}'; """  # limit 100;
        if ax == 0 :
            return qry
        else:
            qry = f"""select coordx as x, coordy as y, pole_uid as sg from poles 
            where (x BETWEEN {ax} AND {bx} ) AND ( y BETWEEN {ay} AND {by}); """
        return qry

    # E.J. This query adds coordinates to the bhn_nodes 
    def qry_bhns_by_pop(self, pops, **args):
        plist =  ','.join([ f"'{p}'" for p in pops])
        qry = f'''
                SELECT bhn_nodes.uid, bhn_nodes.city, bhn_nodes.pop, bhn_nodes.next_hop, 
                bhn_nodes.hops, poles.lat, poles.long, poles.pole_uid 
                FROM bhn_nodes INNER JOIN poles 
                ON bhn_nodes.pop IN ({plist}) and poles.uid = bhn_nodes.pole_uid
                '''  
        if args.get('drop_pops', False): qry += ' and bhn_nodes.hops>0'

        return qry

    def qry_amigs_by_city(self, city, **args):
        qry = f'''
            SELECT ami_nodes.uid, ami_nodes.label, ami_nodes.city, 
            poles.lat, poles.long, poles.seq_geo 
            FROM ami_nodes INNER JOIN poles ON poles.uid = ami_nodes.pole_uid 
            where ami_nodes.city = "{city}" and ami_nodes.type = "ami_gw" and ami_nodes.bhn_node IS NULL 
            '''  
        return qry

    # E.J. Find all pops near dads or meters regarless the cities
    def qry_pops_by_city(self, city, **args):
        qry = f'''
               SELECT DISTINCT pop FROM dads WHERE city_name = "{city}"  UNION 
               SELECT DISTINCT pop FROM meters WHERE city_name = "{city}"
               '''  
        return qry


def create_database(db_file, **args):

    DB_LOCATION = os.path.join(BASE_DIR, db_file)
    conn = None
    try:
        conn = sqlite3.connect(DB_LOCATION)
        print(sqlite3.version)
    except Error as e:
        print(e)
    finally:
        if conn:
            conn.close()

    print(f'New database: {DB_LOCATION}')


class MySQL():
 
    def __init__(self, **args):

        mydb = os.path.join(BASE_DIR, args['db_file']) if 'db_file' in args else DB_LOCATION
            
        self.connection = sqlite3.connect(mydb)
        self.cur = self.connection.cursor()

    def __enter__(self): return self

    def __exit__(self, ext_type, exc_value, traceback):
        self.cur.close()
        if isinstance(exc_value, Exception):
            self.connection.rollback()
        else:
            self.connection.commit()
        self.connection.close()

    def close(self): self.connection.close()

    def commit(self, **args): 
        self.connection.commit()
        if args.get('debug', False): 
            print('rows affected: ', self.cur.rowcount)

    """ execute a command that affects a single row """
    def execute(self, command, vals=None):

        if vals is None:
            return self.cur.execute(command)
        else:
            return self.cur.execute(command, vals)

    """ execute a command that affect multiple rows """
    def executemany(self, command, vals):
        return self.cur.executemany(command, vals)

    """ pandas query - return as a dataframe"""
    def pdquery(self, command):
        return pd.read_sql_query(command, self.connection)
    
    """ Get information about the table columns """
    def tableinfo(self, table):
        cursor = self.cur.execute(f'PRAGMA TABLE_INFO({table})').fetchall()
        # key[name]=(index, type)
        return ({c[1]: (c[0], c[2]) for c in cursor})


"""---------------------------------------------------------------------
-- select * from dads where bhn_node like "%_4"
-- select * from dads where bhn_node != "" 
-- select * from dads where bhn_node in (select uid from bhn_nodes where project_id=5)
-- SELECT * FROM dads WHERE pop IN (SELECT uid FROM pops WHERE city_name ='CASCAVEL') and bhn_node == ''
--------------------------------------------------------------------"""

if __name__ == '__main__':

    q = MyQUeries()

    print(q.qry_bhns_by_pop({"OLIMPICO","CASCAVEL"}, exclude_pops=True))
    print(q.qry_bhns_by_pop({"CASCAVEL"}))

    exit()
    with MySQL() as db:
        sql = q.qry_dads_by_city('AGUDOS DO SUL')
        res = db.pdquery(sql)
        if res.empty: 
            print('Empty dataframe')
        else:
            print(res.head())
            print(res)

