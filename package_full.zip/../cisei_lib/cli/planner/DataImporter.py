import pandas as pd
import cisei_lib.cli.planner.DBWrapper as dbw
import hashlib
import json
import datetime
import os
import platform
import utm
from geopy.distance import geodesic
import warnings
import cisei_lib.globals as g
try: 
    import wg_progressbar as wpb # ARA    
except: 
    print('running without progress bar')


# DataImporter warning


class DataImporterWarning(Warning):
    def __init__(self, msg, cat, obj=None):
        super().__init__(f'{cat} : {msg}')
        self.msg, self.obj, self.cat = msg, obj, cat


# warnings.filterwarnings("ignore", category=DataImporterWarning)

# CSV MUST BE IMPORTED FOLLOWING THIS ORDER:
# 1) counties: This table maps CODES DO city NAMES (OPTIONAL)
# 2) pops: MANDATORY
# 3) towers: (OPTIONAL)
# 4) poles: MANDATORY
# 5) all other tables: any order

class DataImporter(object):
    def __init__(self, **args):
        # basedir = os.path.dirname(os.path.realpath(__file__))   
        config_file = os.path.join(g.g_abs_path_configuration, args.get('config_file', 'import_csv.json'))

        with open(config_file) as f:
            self.config = json.load(f)
        
        self.csvdir = args.get('csvdir', self.config['folder'])
                   
        self.db = dbw.MySQL(db_file=args['db_file']) if "db_file" in args else dbw.MySQL()  
        
    def __str__(self):
        return 'BASEDIR: ' + self.pid

    def __enter__(self):
        return self
    
    def __exit__(self, t, v, tr):
        self.db.close()

    def get_file_hash_sig(self, file):
        hash_md5 = hashlib.md5()
        with open(file, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        full_hash = hash_md5.hexdigest()
        signature = f"{full_hash[0:3]}{full_hash[-4:]}"
        return full_hash, signature

    def save_import_hash(self, file, table, **args):
        fhash, _ = self.get_file_hash_sig(file)
        now = datetime.datetime.now()
        df = pd.DataFrame(
                {
                'file_hash': fhash, 
                'file_name': os.path.basename(file), 
                'file_type' : table, 
                'file_info' : args.get('file_info', None),
                'pos_type' : args.get('pos_type', None),
                'date': now }, [0])
        df.to_sql('imported_files', self.db.connection, if_exists='append', index=False)
        insert_id = pd.read_sql(f"select MAX(id) from imported_files where file_hash = '{fhash}';", self.db.connection)
        return insert_id['MAX(id)'].iloc[0]

    def check_already_imported(self, file):
        """checks if file has already been imported"""
        fhash, _ = self.get_file_hash_sig(file)
        df = pd.read_sql( f"select * from imported_files where file_hash = '{fhash}';", self.db.connection)
        return not df.empty

    def delete_import(self, table, id_list, info=None):
        if len(id_list) > 0:
            flist = tuple(id_list + [-1] )
            sql = f"DELETE FROM {table} WHERE file_id IN {flist}"
            self.db.execute(sql)
            sql = f"DELETE FROM imported_files WHERE id IN {flist}"
            self.db.execute(sql)
            self.db.commit()
        else:
            print('WARNING: delete an import may violate DEPENDENCIES!')
            sql = f"DELETE FROM {table} where file_info = '{info}'"
            self.db.execute(sql)
            sql = f"DELETE FROM imported_files WHERE file_type='{table}' AND file_info='{info}'"
            self.db.execute(sql)
            self.db.commit()

    def import_csv(self, file, table, info, **args):
        
        pbq = None # ARA
        if 'pbq' in args: # ARA
            pbq = args['pbq'] # ARA

        path = os.path.join(self.csvdir, file) 
        if not os.path.isfile(path): 
            raise Exception(f'import_csv: File {path} not found')
    
        if self.check_already_imported(path): 
            print(f'File {file} has already been imported')
            return
        
        print(f'Importing {file} to table {table}')        

        config = self.config[table]
        data_type = { v[0] : v[1] for k,v in config['fields'].items() if v[0] >= 0 }

        # Extracts fields in the same order as in the CSV
        fields = [ [v[0], k ] for k,v in config['fields'].items() if v[0] >= 0 ]
        fields.sort()
        fields = [f[1] for f in fields ]

        # Reads CSV
        encoding = config['encoding_Linux'] if platform.system() == 'Linux' else config['encoding_Windows']
        df = pd.read_csv(path, 
            delimiter=config['separator'], index_col=False, 
            decimal=config['decimal'], 
            encoding=encoding,
            dtype= data_type,
            usecols = data_type.keys() )  
        
        print(f'CSV to dataframe completed: {table}')

        # Fills columns with fixed values
        df.columns = fields
        df['file_info'] = [info] * df.shape[0]
        if 'type' in args: df['type'] = [args['type']] * df.shape[0]

        # Updates city_name, uid and calculates lat, lon
        cfields = config['fields']
        if 'city_name' in cfields and cfields['city_name'][0] == -1 and cfields['city'][0] != -1: self.update_cityName(df)          
        if config.get('coord', None) == 'utm': self.update_coord(df, pbq=pbq) # ARA pbq

        # Updates pops (very slow for poles ...)
        if table not in ['cities', 'pops'] : self.update_pops(df, pbq=pbq) # ARA pbq

        # Generates uid
        if ('uid' in config['fields']) and ('uid' not in fields): self.update_uid(df, config, table) 

        # Update pole_uid
        if table not in ['poles','meters', 'pops']  and ('pole_uid' in config['fields']) and ('pole_uid' not in fields): self.update_pole_uid(df) 

        # Updates tags
        if len(config['tags']) > 0: self.update_tags(df, config, path, encoding)

        # Updates database

        if table == 'towers':
            df['fiber'] = df['fiber'].str.upper()
            f = lambda x : 'SIM' if x == 'SIM' else 'NAO'
            df['fiber'] = df['fiber'].map(f)
            df2 = df.query("fiber != 'SIM'")
            
            self.update_database(df2, config, table, path, info)

            df2 = df.query("fiber == 'SIM'")
            df2 = df2.drop(columns=['fiber','pop'])
            df2['type'] = ['tower'] * df2.shape[0]
            df2['has_tower'] = ['SIM'] * df2.shape[0]
            df2['pop_name'] = df2['uid']
            self.update_database(df2, config, 'pops', path, info)

        else:
            self.update_database(df, config, table, path, info)         
           
    def update_uid(self, df, config, table ):
        if config['uid'] is not None:
            df['uid'] = df[config['uid']].values
        else:
            print('uid must be generated')
            ini_id = pd.read_sql(f"select MAX(id) from {table}",self.db.connection)
            ini_id = ini_id['MAX(id)'].iloc[0]
            if ini_id == None: ini_id = 0
            # df['uid'] = [ f'{table[:3]}_{ini_id + i + 1}' for i in range(df.shape[0]) ] 
            for i,row in df.iterrows():
                city = '' if df.loc[i, 'city_name'] is None else df.loc[i, 'city_name']
                city = city.split(' ')
                pre = table[:3] + '_' + city[0][:3] + ''.join( c[0] for c in city[1:])
                df.loc[i, 'uid'] = f'{pre}{ini_id + i + 1}' 

    def update_coord(self, df, **kwargs) : # ARA - added **kwargs

        print('update coordinates')
        lat = [None]* df.shape[0]
        lon = [None]* df.shape[0]
        
        ptotal = int(df.shape[0]) # ARA
        tmr = wpb.PBTimer(1.0) # ARA
        pbq = kwargs.get('pbq', None) # ARA

        for i,row in df.iterrows():
            if pbq is not None and tmr.has_elapsed(i/ptotal): # ARA
                val = wpb.lazy_prog_lerp(0,30,i/ptotal) # ARA
                wpb.do_if_has_pb(pbq, wpb.progress, val) # ARA
                wpb.do_if_has_pb(pbq, wpb.message, f"Updating coords {val} %\n(ETA: {tmr.eta()})") # ARA
            (lat[i], lon[i]) = utm.to_latlon(row['coordx'], row['coordy'], 22, 'J')
        df['lat'] = lat
        df['long'] = lon

    # OBS. Cities are identified by city_name and not by city (code)
    # -- this function translates city to city_name when necessary
    def update_cityName(self, df):
        print('updating city_name')
        df2 = pd.read_sql( f"select code,name from cities", self.db.connection)
        dic = { row['code'] : row['name'] for _,row in df2.iterrows() }
        values = [ dic.get(row['city'], "MISSING") for _,row in df.iterrows() ]
        df['city_name'] = values

    # OBS. There must be an option for updating POPS after a pop has been added or deleted
    # -- City is intended to rebuild pops only for the selected city
    # -- If new pops are imported, update pops is mandatory for poles!!!
    def update_pops(self, df, City=None, **kwargs): # ARA - added **kwargs
        print('updating pops')            
        df2 = pd.read_sql( f"select * from pops", self.db.connection)
        if df2.empty:
            raise Exception('pops are empty')

        df['pop'] = [None] * df.shape[0]
        df['city_name'] = [None] * df.shape[0]

        pops = {} # 3 digits is 30 to 100 meters

        print(df.shape[0])
        ptotal = int(df.shape[0]) # ARA
        tmr = wpb.PBTimer(1.0) # ARA7
        pbq = kwargs.get('pbq', None) # ARA
        count = 0
        for i,row in df.iterrows():
            if pbq is not None and tmr.has_elapsed(i/ptotal): # ARA
                val = wpb.lazy_prog_lerp(30,99,i/ptotal) # ARA
                wpb.do_if_has_pb(pbq, wpb.message, f"updating pops... ({i}/{ptotal}) {val} %\n(ETA: {tmr.eta()})") # ARA
                wpb.do_if_has_pb(pbq, wpb.progress, val) # ARA

            count2 = round(i/1000)
            if count2 > count: 
                print(i)
                count = count2
            s = (round(row['lat'],3), round(row['long'],3))
            if s in pops.keys():
                pop = pops[s]
            else:
                ipop = min(range(df2.shape[0]), key=lambda x : geodesic(s,(df2.iloc[x]['lat'],df2.iloc[x]['long'])).km)
                pop = df2.iloc[ipop]['uid'] 
                pops[s] = pop
            df.loc[i,'pop'] = pop
            if 'city_name' not in df.columns or df.iloc[i]['city_name'] is None:
                df.loc[i,'city_name'] = df2.iloc[ipop]['city_name']
            else:
                df.iloc[i,'city_name'] = row['city_name']           
    
    #TODO: update pole UID based on pop classification
    # -- Remove pole_uid from POPS? 
    # -- NOTE: pole_uid = poles.uid (text) and not poles.pole_uid (number)
    def update_pole_uid(self, df, **args):
        pops = (list(set(df['pop'].tolist())))
        # df2 = pd.read_sql( f"select uid,lat,long from poles where pop IN {tuple(pops)}", self.db.connection  )
        df2 = pd.read_sql( f"select uid,lat,long from poles", self.db.connection  )       
        poles = {} # 4 digits is up to 11 meters and 5 up to 1.1 meter ( GPS stops in 4.4 meters radius )
            
        for i,row in df2.iterrows():
            s = (round(row['lat'], 4 ), round(row['long'], 4))
            poles[s] = row['uid']

        errors = []
        for i,row in df.iterrows():
            if 'pole_uid' not in row.keys() or row['pole_uid'] is None:
                s = (round(row['lat'], 4), round(row['long'], 4))
                uid = poles.get(s,None)
                if not uid: errors.append(row['uid'])
                df.loc[i,'pole_uid'] = uid
        
        if len(errors) > 0: warnings.warn(DataImporterWarning(f'There are {len(errors)} elements without poles', 'update_pole_uid',  errors))  
                  
    def update_tags(self, df, config, path, encoding ):
        print('Importing TAGS: take it easy ...')
        data_type = { v[0] : v[1] for k,v in config['tags'].items() if v[0] >= 0 }
        fields = [ [v[0], k ] for k,v in config['tags'].items() if v[0] >= 0 ]
        fields.sort()
        fields = [f[1] for f in fields ]
        df2 = pd.read_csv(path, 
            delimiter=config['separator'], index_col=False, 
            decimal=config['decimal'], 
            encoding=encoding,
            dtype= data_type,
            usecols = data_type.keys() ) 

        df2.columns = fields

        tags = [None] * df2.shape[0]
        for i,row in df2.iterrows():
            tag = {}
            for f in fields: tag[f] = row[f]
            tags[i] = json.dumps(tag)
        
        df['tags'] = tags

    def update_database(self, df, config, table, path, info):

        import_id = self.save_import_hash(path, table, pos_type=config.get('coord', None), file_info=info)
        
        df2 = df.copy() # because of the warning!!
        df2["file_id"] = [ import_id ] * df.shape[0]      

        if config['replace'] and config['uid'] is not None:
            flist = tuple(df[config['uid']].values )
            sql = f"DELETE from {table} where {config['uid']} in {flist}"
            self.db.execute(sql)
        try:    
            df2.to_sql(table, self.db.connection, if_exists='append', index=False)
            return True
        except Exception as e:
            print(f'ERROR: CSV import for {table}: ', e)
            self.delete_import(table, [import_id])
            return False

    def filter_raw_csv(self, file, table, filter, out_file):

        path = os.path.join(self.csvdir, file) 
        if not os.path.isfile(path): raise Exception(f'import_csv: File {path} not found')
    
        config = self.config[table]

        # Reads CSV
        encoding = config['encoding_Linux'] if platform.system() == 'Linux' else config['encoding_Windows']
        df = pd.read_csv(path, 
            delimiter=config['separator'], index_col=False, 
            decimal=config['decimal'], 
            encoding=encoding,
            low_memory=False )  
        
        f = lambda x : [ x[k]==v for k,v in filter.items() ].count(False) == 0
        df2 = df[df.apply( f, axis=1)]

        path = os.path.join(self.csvdir, out_file) 
        df2.to_csv(path, sep=config['separator'], index=False, decimal=config['decimal'], encoding=encoding )



#-----------------------------------------------------------------     
# Used to test the code not used as a Python module

if __name__ == "__main__":


    if platform.system() == 'Linux':
        csvdir = '/media/self/ANIMA/Documentos/EDITAL/Edital2/Coordenadas'
    else:
        csvdir = '../EDITAL/Edital2/Coordenadas/'
        # csvdir = '../EDITAL/Edital3/Coordenadas/'

    with DataImporter(db_file='teste.db', csvdir=csvdir) as d:
        with warnings.catch_warnings(record=True) as w:

            # d.delete_import('cities', [])
            #d.delete_import('pops', [22] ) 
            #d.delete_import('towers', [], 'FASE 2')
            #d.delete_import('pops', [], info='FASE 2')
            # d.delete_import('dads', [], info='FASE 3') 
            #d.delete_import('poles', [], 'FASES 2 e 3')    
            #d.delete_import('meters', [], info='FASE 2') 

            # d.import_csv('Cities.csv', 'cities', 'FASES 2 e 3')
            # d.import_csv('#02.01 FASE_3_SUBESTACOES.CSV', 'pops', 'FASE 3', type='subestacao')
            # d.import_csv('#03.01 FASE_3_TORRES_FORA_DE_SE.CSV', 'towers', 'FASE 3')    
            # d.import_csv('Postes_Geral.csv', 'poles', 'FASES 2 e 3')                    
            # d.import_csv('#04.01 FASE_3_EQUIPAMENTOS_DE_AUTOMACAO.CSV', 'dads', 'FASE 3')

                      
            
            
            #d.import_csv('#05.01 FASE_2_MONOFASICO_2F.csv','meters', 'FASE 2', type='MONO_2F')
            #d.import_csv('#05.02 FASE_2_MONOFASICO_3F.csv','meters', 'FASE 2', type='MONO_3F')
            #d.import_csv('#05.03 FASE_2_BIFASICO.CSV','meters', 'FASE 2', type='BIFASICO')
            #d.import_csv('#05.04 FASE_2_TRIFASICO.CSV','meters', 'FASE 2', type='TRIFASICO')
            #d.import_csv('#05.05 FASE_2_TRIFASICO_INDIRETO.CSV','meters', 'FASE 2', type='TRI_IND')
            #d.import_csv('#05.06 FASE_2_TRIFASICO_30(200).CSV','meters', 'FASE 2', type='TRI_30')
            #d.import_csv('#05.07 FASE_2_REMOTA.CSV','meters', 'FASE 2', type='REMOTA')

            d.filter_raw_csv('Postes_Geral.csv', 'poles', { "TIPO_TENSAO":'BT', "Fase do projeto":2 } , 'postes_bt_fase2.csv')

            for ww in w:
                print(ww.message)
