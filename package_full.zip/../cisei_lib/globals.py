import pathlib
import threading
import os

# text
g_program_name = "Smart Grid Planning Tool"
g_program_desc = ""
g_prog_version = "v0.1.0"
g_about = """
COPYRIGHT © CISEI | PUCPR | COPEL DIS 2021-2023

P&D-02866-0478/2017 FERRAMENTA DE PLANEJAMENTO ÓTIMO DE COMUNICAÇÃO

"""

# paths and folders
g_basedir = os.path.dirname(os.path.abspath(__file__))  # where globals.py is!
g_workdir = pathlib.Path(__file__).parent.resolve() # yes it is the same!
g_datadir = os.path.join(g_basedir, '..','Data')
g_projects_folder = os.path.join('..','Data','PROJECTS') # basedir
g_wolfram = os.path.join('..','Wolfram')  
g_config_folder = os.path.join('..','Configuration')
g_maps_folder = os.path.join('..','Data','MAPS')

# files location 
g_database_file = "teste.db" # datadir

# network
g_livemap_api_server_port = "5000"
g_livemap_api_server_url = f"http://127.0.0.1:{g_livemap_api_server_port}/"
g_frontend_port = 8037
g_backend_port = 5000

# global variables
g_main_window = None
g_main_pbq = None # queue for progressbar
g_proj_num = -1 # the selected project

# variables created by functions
g_memory_is_writing_lock = threading.Lock() # sometimes, writing memory.json takes some msecs
g_abs_path_db = os.path.join(g_datadir, g_database_file)
g_abs_path_projects = os.path.join(g_basedir, g_projects_folder)
g_abs_path_configuration = os.path.join(g_basedir, g_config_folder)
g_abs_path_maps = os.path.join(g_basedir, g_maps_folder)
g_abs_path_map_memory = os.path.join(g_abs_path_maps, 'memory.json')
g_abs_path_resouces = os.path.join(g_basedir, '..','public','resources')
g_img_icons = os.path.join(g_abs_path_resouces, "icons")
g_mapres = os.path.join(g_abs_path_resouces, "mapres")



